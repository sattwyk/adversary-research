// Copyright 2021 Datafuse Labs
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use std::fmt;
use std::fs;
use std::net::SocketAddr;
use std::sync::Arc;

use anyhow::Result;
use databend_base::testutil::next_port;
use databend_base::uniq_id::GlobalUniq;
use databend_meta::api::GrpcServer;
use databend_meta::configs;
use databend_meta::message::ForwardRequest;
use databend_meta::message::ForwardRequestBody;
use databend_meta::meta_node::meta_worker::MetaWorker;
use databend_meta::meta_service::MetaNode;
use databend_meta_runtime_api::RuntimeApi;
use databend_meta_types::protobuf::raft_service_client::RaftServiceClient;
use databend_meta_types::raft_types::NodeId;
use log::info;
use log::warn;
use tonic::transport::server::TcpIncoming;

/// Start one random service and get the session manager.
#[fastrace::trace]
pub async fn start_metasrv<R: RuntimeApi>() -> Result<(MetaSrvTestContext<R>, String)> {
    let mut tc = MetaSrvTestContext::new(0);

    start_metasrv_with_context(&mut tc).await?;

    let addr = tc
        .config
        .grpc
        .api_address()
        .expect("gRPC port should be assigned after server start");

    Ok((tc, addr))
}

pub async fn start_metasrv_with_context<R: RuntimeApi>(
    tc: &mut MetaSrvTestContext<R>,
) -> Result<()> {
    // Bind first to get the actual port before creating MetaWorker.
    // This ensures init_cluster (for single=true) uses the correct port.
    let port = tc.config.grpc.listen_port.unwrap_or(0);
    let addr: SocketAddr = format!("{}:{}", tc.config.grpc.listen_host, port).parse()?;
    let incoming = TcpIncoming::bind(addr)?.with_nodelay(Some(true));
    let actual_port = incoming.local_addr()?.port();
    tc.config.grpc.listen_port = Some(actual_port);

    // Now create MetaWorker with the correct config (including the actual port)
    let runtime = R::new_testing("meta-io-rt-ut");
    let mh = MetaWorker::create_meta_worker(tc.config.clone(), Arc::new(runtime)).await?;
    let mh = Arc::new(mh);

    // Join cluster if needed (for nodes joining an existing cluster)
    let c = tc.config.clone();
    let _ = mh
        .request(move |mn| {
            let fu = async move { mn.join_cluster(&c).await };
            Box::pin(fu)
        })
        .await??;

    let mut srv = GrpcServer::create(&tc.config, mh.clone());
    srv.do_start_with_incoming(incoming).await?;
    tc.grpc_srv = Some(Box::new(srv));

    Ok(())
}

/// Bring up a cluster of metasrv, the first one is the leader.
///
/// It returns a vec of test-context.
pub async fn start_metasrv_cluster<R: RuntimeApi>(
    node_ids: &[NodeId],
) -> anyhow::Result<Vec<MetaSrvTestContext<R>>> {
    let mut res = vec![];

    let leader_id = node_ids[0];

    let mut tc0 = MetaSrvTestContext::<R>::new(leader_id);
    start_metasrv_with_context(&mut tc0).await?;

    let leader_addr = tc0.config.raft_config.raft_api_addr::<R>().await?;
    res.push(tc0);

    for node_id in node_ids.iter().skip(1) {
        let mut tc = MetaSrvTestContext::<R>::new(*node_id);
        tc.config.raft_config.single = false;
        tc.config.raft_config.join = vec![leader_addr.to_string()];
        start_metasrv_with_context(&mut tc).await?;

        res.push(tc);
    }

    Ok(res)
}

/// It holds a reference to a MetaNode or a GrpcServer, for testing MetaNode or GrpcServer.
pub struct MetaSrvTestContext<R: RuntimeApi> {
    pub _temp_dir: tempfile::TempDir,

    pub config: configs::MetaServiceConfig,

    /// Admin API configuration for HTTP service tests.
    /// This is separate from the core `MetaServiceConfig` because admin config
    /// is a CLI-level concern, not a service-level concern.
    pub admin: configs::AdminConfig,

    pub meta_node: Option<Arc<MetaNode<R>>>,

    pub grpc_srv: Option<Box<GrpcServer<R>>>,
}

impl<R: RuntimeApi> Drop for MetaSrvTestContext<R> {
    fn drop(&mut self) {
        self.rm_raft_dir("Drop MetaSrvTestContext");
    }
}

impl<R: RuntimeApi> MetaSrvTestContext<R> {
    /// Create a new Config for test, with unique port assigned
    pub fn new(id: u64) -> MetaSrvTestContext<R> {
        let temp_dir = tempfile::tempdir().unwrap();

        let config_id = GlobalUniq::unique();

        let mut config = configs::MetaServiceConfig::default();

        config.raft_config.id = id;

        config.raft_config.config_id = config_id.clone();

        // Use a unique dir for each test case.
        config.raft_config.raft_dir =
            format!("{}/{}/raft_dir", temp_dir.path().display(), config_id);

        // By default, create a meta node instead of open an existent one.
        config.raft_config.single = true;

        config.raft_config.raft_api_port = next_port();

        // Reserved unconditionally, the same way the raft port is: the TLS
        // listener also needs a certificate and a key, so a test that sets
        // neither does not open this port and only pays for the reservation.
        config.raft_config.raft_tls_port = Some(next_port());

        // when running unit tests, set raft_listen_host to "127.0.0.1" and raft_advertise_host to localhost,
        // so if something wrong in raft meta nodes communication we will catch bug in unit tests.
        config.raft_config.raft_listen_host = "127.0.0.1".to_string();
        config.raft_config.raft_advertise_host = "localhost".to_string();

        // gRPC port will be assigned by OS when server starts
        config.grpc = configs::GrpcConfig::new_local("127.0.0.1");

        let admin = {
            let http_port = next_port();
            configs::AdminConfig {
                api_address: format!("127.0.0.1:{}", http_port),
                tls: configs::TlsConfig::default(),
            }
        };

        info!("new test context config: {:?}", config);

        let c = MetaSrvTestContext {
            config,
            admin,
            meta_node: None,
            grpc_srv: None,
            _temp_dir: temp_dir,
        };

        c.rm_raft_dir("new MetaSrvTestContext");

        c
    }

    pub fn rm_raft_dir(&self, msg: impl fmt::Display + Copy) {
        let raft_dir = &self.config.raft_config.raft_dir;

        info!("{}: about to remove raft_dir: {:?}", msg, raft_dir);

        let res = fs::remove_dir_all(raft_dir);
        if let Err(e) = res {
            warn!("{}: can not remove raft_dir {:?}, {:?}", msg, raft_dir, e);
        } else {
            info!("{}: OK removed raft_dir {:?}", msg, raft_dir)
        }
    }

    pub fn meta_node(&self) -> Arc<MetaNode<R>> {
        self.meta_node.clone().unwrap()
    }

    pub async fn raft_client(
        &self,
    ) -> anyhow::Result<RaftServiceClient<tonic::transport::Channel>> {
        let addr = self.config.raft_config.raft_api_addr::<R>().await?;

        let max_retries = 20;
        let interval = tokio::time::Duration::from_millis(200);
        let mut last_err = None;

        for attempt in 1..=max_retries {
            let client = RaftServiceClient::connect(format!("http://{}", addr)).await;
            match client {
                Ok(x) => return Ok(x),
                Err(err) => {
                    info!(
                        "can not yet connect to {} (attempt {}/{}): {}",
                        addr, attempt, max_retries, err
                    );
                    last_err = Some(err);
                    tokio::time::sleep(interval).await;
                }
            }
        }

        Err(anyhow::anyhow!(
            "can not connect to raft server at {} after {} attempts over {:.1}s: {}",
            addr,
            max_retries,
            max_retries as f64 * interval.as_secs_f64(),
            last_err.unwrap()
        ))
    }

    pub async fn assert_raft_server_connection(&self) -> anyhow::Result<()> {
        let mut client = self.raft_client().await?;

        let req = ForwardRequest {
            forward_to_leader: 0,
            body: ForwardRequestBody::Ping,
        };

        client.forward(req).await?;
        Ok(())
    }

    pub fn drop_meta_node(&mut self) {
        self.meta_node.take();
        self.grpc_srv.take();
    }
}
