// Copyright 2021 Datafuse Labs
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

//! Version information for databend-meta.
//!
//! # Minimum Compatible Versions
//!
//! [`MIN_CLIENT_VERSION`] and [`MIN_SERVER_VERSION`] are the authoritative
//! source of truth for version compatibility checks during handshake.
//!
//! These values are hardcoded because Rust cannot compute them at const
//! initialization time. The corresponding functions in [`grpc_spec::GrpcSpec`]
//! (`min_compatible_client_version()` and `min_compatible_server_version()`)
//! exist to verify these values are correct - unit tests assert they match.
//!
//! When feature changes affect compatibility:
//! - Update `MIN_CLIENT_VERSION` when server removes features
//! - Update `MIN_SERVER_VERSION` when client requires new features
//! - Run tests to verify the values match the computed results
//!
//! See [Compatibility Algorithm](./compatibility_algorithm.md) for details.

mod feature_span;
mod grpc_changelog;
mod grpc_feat;
mod grpc_spec;
mod raft_feat;
mod raft_spec;
mod version;

pub use self::feature_span::FeatureSet;
pub use self::feature_span::FeatureSpan;
pub use self::feature_span::FeatureSpec;
pub use self::grpc_changelog::GrpcVersionCompat;
pub use self::grpc_changelog::grpc_changelog;
pub use self::grpc_feat::GrpcFeature;
pub use self::grpc_spec::GrpcSpec;
pub use self::raft_feat::RaftFeature;
pub use self::raft_spec::RaftSpec;
pub use self::version::Version;

pub mod changelog {
    #![doc = include_str!("changes.md")]
}

/// Minimum compatible meta-client version.
///
/// See [module documentation](self) for details.
pub static MIN_CLIENT_VERSION: Version = Version::new(1, 2, 676);

/// Minimum compatible meta-server version.
///
/// See [module documentation](self) for details.
pub static MIN_SERVER_VERSION: Version = Version::new(260217, 0, 0);

/// Minimum compatible raft-server version (node receiving raft RPCs).
///
/// See [module documentation](self) for details.
pub static MIN_RAFT_SERVER_VERSION: Version = Version::new(1, 2, 818);

/// Minimum compatible raft-client version (node sending raft RPCs).
///
/// See [module documentation](self) for details.
pub static MIN_RAFT_CLIENT_VERSION: Version = Version::new(0, 0, 0);

use std::sync::LazyLock;

/// The version string of this build.
const VERSION_STR: &str = env!("CARGO_PKG_VERSION");

/// Current version and feature compatibility spec.
static SPEC: LazyLock<GrpcSpec> = LazyLock::new(GrpcSpec::load);

/// Raft inter-node version and feature compatibility spec.
static RAFT_SPEC: LazyLock<RaftSpec> = LazyLock::new(RaftSpec::load);

/// Returns the version string (e.g., "260205.0.0").
pub fn version_str() -> &'static str {
    VERSION_STR
}

/// Returns the parsed version.
pub fn version() -> &'static Version {
    SPEC.version()
}

/// Returns the full version and feature compatibility spec.
pub fn spec() -> &'static GrpcSpec {
    &SPEC
}

/// Returns the raft inter-node version and feature compatibility spec.
pub fn raft_spec() -> &'static RaftSpec {
    &RAFT_SPEC
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Convert semver::Version to tuple for comparison.
    fn semver_tuple(v: &Version) -> (u64, u64, u64) {
        (v.major(), v.minor(), v.patch())
    }

    /// Assert that a static version constant matches the computed value.
    fn assert_version_eq(name: &str, static_ver: &Version, computed: Version) {
        assert_eq!(
            semver_tuple(static_ver),
            computed.as_tuple(),
            "{} does not match computed value. Update {} in lib.rs.",
            name,
            name
        );
    }

    /// Read a version from `[package.metadata.compat]` in this crate's Cargo.toml.
    fn cargo_compat_version(key: &str) -> Version {
        let v: toml::Value = toml::from_str(include_str!(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/Cargo.toml"
        )))
        .unwrap();
        let s = v["package"]["metadata"]["compat"][key]
            .as_str()
            .unwrap_or_else(|| panic!("missing key `{key}` in [package.metadata.compat]"));
        Version::parse(s)
    }

    #[test]
    fn test_version_string() {
        let version = version_str();
        assert_eq!(version, "260629.7.0");
    }

    #[test]
    fn test_semver_components() {
        let version = version();
        let components = semver_tuple(version);
        assert_eq!(components, (260629, 7, 0));
    }

    #[test]
    fn test_semver_display() {
        let version = version();
        let semver = version.to_semver();
        let display = semver.to_string();
        assert_eq!(display, "260629.7.0");
    }

    #[test]
    fn test_min_client_version_matches_computed() {
        let spec = spec();
        assert_version_eq(
            "MIN_CLIENT_VERSION",
            &MIN_CLIENT_VERSION,
            spec.min_compatible_client_version(),
        );
    }

    #[test]
    fn test_min_server_version_matches_computed() {
        let spec = spec();
        assert_version_eq(
            "MIN_SERVER_VERSION",
            &MIN_SERVER_VERSION,
            spec.min_compatible_server_version(),
        );
    }

    #[test]
    fn test_min_raft_server_version_matches_computed() {
        let spec = raft_spec();
        assert_version_eq(
            "MIN_RAFT_SERVER_VERSION",
            &MIN_RAFT_SERVER_VERSION,
            spec.min_compatible_server_version(),
        );
    }

    #[test]
    fn test_min_raft_client_version_matches_computed() {
        let spec = raft_spec();
        assert_version_eq(
            "MIN_RAFT_CLIENT_VERSION",
            &MIN_RAFT_CLIENT_VERSION,
            spec.min_compatible_client_version(),
        );
    }

    #[test]
    fn test_min_client_version_matches_cargo_metadata() {
        assert_eq!(
            MIN_CLIENT_VERSION,
            cargo_compat_version("min-client-version")
        );
    }

    #[test]
    fn test_min_server_version_matches_cargo_metadata() {
        assert_eq!(
            MIN_SERVER_VERSION,
            cargo_compat_version("min-server-version")
        );
    }

    #[test]
    fn test_min_raft_server_version_matches_cargo_metadata() {
        assert_eq!(
            MIN_RAFT_SERVER_VERSION,
            cargo_compat_version("min-raft-server-version")
        );
    }

    #[test]
    fn test_min_raft_client_version_matches_cargo_metadata() {
        assert_eq!(
            MIN_RAFT_CLIENT_VERSION,
            cargo_compat_version("min-raft-client-version")
        );
    }
}
