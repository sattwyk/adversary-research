// Copyright 2021 Datafuse Labs
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use std::fmt;

use crate::protobuf as pb;

impl pb::TxnDeleteByPrefixResponse {
    pub fn new(prefix: impl ToString, count: u32) -> Self {
        Self {
            prefix: prefix.to_string(),
            count,
        }
    }
}

impl fmt::Display for pb::TxnDeleteByPrefixResponse {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        write!(
            f,
            "TxnDeleteByPrefixResponse prefix={},count={}",
            self.prefix, self.count
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_new() {
        let resp = pb::TxnDeleteByPrefixResponse::new("pfx/", 42);
        assert_eq!(resp.prefix, "pfx/");
        assert_eq!(resp.count, 42);
    }

    #[test]
    fn test_display() {
        let resp = pb::TxnDeleteByPrefixResponse::new("pfx/", 3);
        assert_eq!(
            resp.to_string(),
            "TxnDeleteByPrefixResponse prefix=pfx/,count=3"
        );
    }
}
