// Copyright 2021 Datafuse Labs
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use databend_meta_base::normalize_meta::NormalizeMeta;
use state_machine_api::SeqV;

use crate::protobuf as pb;
use crate::protobuf::StreamItem;

impl StreamItem {
    pub fn new(key: String, value: Option<pb::SeqV>) -> Self {
        StreamItem { key, value }
    }

    pub fn into_option_pair(self) -> (String, Option<SeqV>) {
        (self.key, self.value.map(SeqV::from))
    }

    pub fn into_pair(self) -> (String, SeqV) {
        (self.key, SeqV::from(self.value.unwrap()))
    }
}

impl From<(String, Option<pb::SeqV>)> for StreamItem {
    fn from(kv: (String, Option<pb::SeqV>)) -> Self {
        StreamItem::new(kv.0, kv.1)
    }
}

impl From<(String, Option<SeqV>)> for StreamItem {
    fn from(kv: (String, Option<SeqV>)) -> Self {
        StreamItem::new(kv.0, kv.1.map(pb::SeqV::from))
    }
}

impl From<(String, SeqV)> for StreamItem {
    fn from(kv: (String, SeqV)) -> Self {
        StreamItem::new(kv.0, Some(pb::SeqV::from(kv.1)))
    }
}

impl NormalizeMeta for pb::StreamItem {
    fn without_proposed_at(mut self) -> Self {
        if let Some(ref mut value) = self.value {
            if let Some(ref mut meta) = value.meta {
                meta.proposed_at_ms = None;
            }
        }
        self.normalize()
    }

    fn normalize(mut self) -> Self {
        if let Some(ref mut value) = self.value {
            if value.meta == Some(Default::default()) {
                value.meta = None;
            }
        }
        self
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_stream_item_new() {
        let item = pb::StreamItem::new(
            "test_key".to_string(),
            Some(pb::SeqV {
                seq: 1,
                data: b"test_data".to_vec(),
                meta: None,
            }),
        );
        assert_eq!(item.key, "test_key");
        assert_eq!(item.value.as_ref().unwrap().seq, 1);
    }

    #[test]
    fn test_stream_item_into_option_pair() {
        let item = pb::StreamItem::new(
            "key".to_string(),
            Some(pb::SeqV {
                seq: 1,
                data: b"data".to_vec(),
                meta: None,
            }),
        );
        let (key, value) = item.into_option_pair();
        assert_eq!(key, "key");
        assert_eq!(value.unwrap().seq, 1);
    }

    #[test]
    fn test_stream_item_into_pair() {
        let item = pb::StreamItem::new(
            "key".to_string(),
            Some(pb::SeqV {
                seq: 2,
                data: b"data".to_vec(),
                meta: None,
            }),
        );
        let (key, value) = item.into_pair();
        assert_eq!(key, "key");
        assert_eq!(value.seq, 2);
    }

    #[test]
    fn test_stream_item_from_tuple_with_pb_seqv() {
        let item = StreamItem::from((
            "key".to_string(),
            Some(pb::SeqV {
                seq: 3,
                data: b"val".to_vec(),
                meta: None,
            }),
        ));
        assert_eq!(item.key, "key");
        assert_eq!(item.value.as_ref().unwrap().seq, 3);
    }

    #[test]
    fn test_stream_item_from_tuple_with_seqv() {
        let item = StreamItem::from(("key".to_string(), Some(SeqV::new(4, b"val".to_vec()))));
        assert_eq!(item.key, "key");
        assert_eq!(item.value.as_ref().unwrap().seq, 4);
    }

    #[test]
    fn test_stream_item_from_tuple_non_optional() {
        let item = StreamItem::from(("key".to_string(), SeqV::new(5, b"val".to_vec())));
        assert_eq!(item.key, "key");
        assert_eq!(item.value.as_ref().unwrap().seq, 5);
    }

    #[test]
    fn test_stream_item_with_no_value() {
        let item = pb::StreamItem::new("key".to_string(), None);
        let (key, value) = item.into_option_pair();
        assert_eq!(key, "key");
        assert!(value.is_none());
    }

    #[test]
    fn test_stream_item_erase_proposed_at() {
        let item = pb::StreamItem::new(
            "test_key".to_string(),
            Some(pb::SeqV {
                seq: 1,
                data: b"test_data".to_vec(),
                meta: Some(pb::KvMeta {
                    expire_at: Some(1723102819),
                    proposed_at_ms: Some(1_723_102_800_000),
                }),
            }),
        );

        let erased = item.without_proposed_at();

        assert_eq!(erased.key, "test_key");
        let value = erased.value.as_ref().unwrap();
        assert_eq!(value.seq, 1);
        let meta = value.meta.as_ref().unwrap();
        assert_eq!(meta.expire_at, Some(1723102819));
        assert_eq!(meta.proposed_at_ms, None);
    }

    #[test]
    fn test_stream_item_erase_proposed_at_removes_default_meta() {
        let item = pb::StreamItem::new(
            "test_key".to_string(),
            Some(pb::SeqV {
                seq: 2,
                data: b"data".to_vec(),
                meta: Some(pb::KvMeta {
                    expire_at: None,
                    proposed_at_ms: Some(1_723_102_900_000),
                }),
            }),
        );

        let erased = item.without_proposed_at();
        assert_eq!(erased.value.as_ref().unwrap().meta, None);
    }

    #[test]
    fn test_stream_item_reduce_removes_default_meta() {
        let item = pb::StreamItem::new(
            "test_key".to_string(),
            Some(pb::SeqV {
                seq: 3,
                data: b"data".to_vec(),
                meta: Some(pb::KvMeta {
                    expire_at: None,
                    proposed_at_ms: None,
                }),
            }),
        );

        let reduced = item.normalize();
        assert_eq!(reduced.value.as_ref().unwrap().meta, None);
    }
}
