// Copyright 2021 Datafuse Labs
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

//! Prometheus metrics for a databend-meta node.

#![allow(clippy::collapsible_if)]

mod meta_metrics;
mod registry;

pub use meta_metrics::InFlightRead;
pub use meta_metrics::InFlightWrite;
pub use meta_metrics::ProposalPending;
pub use meta_metrics::SnapshotBuilding;
pub use meta_metrics::meta_metrics_to_metric_set;
pub use meta_metrics::meta_metrics_to_prometheus_string;
pub use meta_metrics::network_metrics;
pub use meta_metrics::raft_metrics;
pub use meta_metrics::server_metrics;
