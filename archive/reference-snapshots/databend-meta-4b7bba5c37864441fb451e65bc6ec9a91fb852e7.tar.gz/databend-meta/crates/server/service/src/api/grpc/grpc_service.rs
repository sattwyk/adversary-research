// Copyright 2021 Datafuse Labs
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use std::io;
use std::net::SocketAddr;
use std::pin::Pin;
use std::sync::Arc;
use std::sync::Weak;
use std::time::Instant;
use std::time::SystemTime;

use arrow_flight::BasicAuth;
use databend_base::counter::Counted;
use databend_base::counter::Counter;
use databend_base::futures::ElapsedFutureExt;
use databend_base::grpc_token::GrpcClaim;
use databend_base::grpc_token::GrpcToken;
use databend_meta_client::MetaGrpcReadReq;
use databend_meta_client::MetaGrpcReq;
use databend_meta_runtime_api::SpawnApi;
use databend_meta_runtime_api::TrackingData;
use databend_meta_types::Endpoint;
use databend_meta_types::GrpcHelper;
use databend_meta_types::TxnRequest;
use databend_meta_types::protobuf as pb;
use databend_meta_types::protobuf::ClientInfo;
use databend_meta_types::protobuf::ClusterStatus;
use databend_meta_types::protobuf::Empty;
use databend_meta_types::protobuf::ExportedChunk;
use databend_meta_types::protobuf::HandshakeRequest;
use databend_meta_types::protobuf::HandshakeResponse;
use databend_meta_types::protobuf::KeysCount;
use databend_meta_types::protobuf::KeysLayoutRequest;
use databend_meta_types::protobuf::KvGetManyRequest;
use databend_meta_types::protobuf::KvListRequest;
use databend_meta_types::protobuf::MemberListReply;
use databend_meta_types::protobuf::MemberListRequest;
use databend_meta_types::protobuf::RaftReply;
use databend_meta_types::protobuf::RaftRequest;
use databend_meta_types::protobuf::StreamItem;
use databend_meta_types::protobuf::TxnReply;
use databend_meta_types::protobuf::WatchRequest;
use databend_meta_types::protobuf::WatchResponse;
use databend_meta_types::protobuf::meta_service_server::MetaService;
use databend_meta_version::Version;
use display_more::DisplayOptionExt;
use fastrace::func_name;
use fastrace::func_path;
use futures::StreamExt;
use futures::TryStreamExt;
use futures::stream::TryChunksError;
use log::debug;
use log::info;
use log::warn;
use prost::Message;
use tokio_stream;
use tokio_stream::Stream;
use tonic::Request;
use tonic::Response;
use tonic::Status;
use tonic::Streaming;
use tonic::codegen::BoxStream;
use tonic::metadata::MetadataMap;
use tonic::server::NamedService;
use watcher::watch_stream::WatchStreamSender;

use super::grpc_authenticator::GrpcAuthenticator;
use super::grpc_authenticator::unknown_user;
use crate::configs::GrpcConfig;
use crate::meta_node::meta_handle::MetaHandle;
use crate::meta_service::watcher::DispatcherHandle;
use crate::meta_service::watcher::WatchTypes;
use crate::metrics::InFlightRead;
use crate::metrics::InFlightWrite;
use crate::metrics::network_metrics;
use crate::version::MIN_CLIENT_VERSION;

/// Guard type for in-flight read requests.
type InFlightReadGuard = Counted<InFlightRead, ()>;

/// A request that is currently being processed.
///
/// Created when request handling begins, dropped when stream completes.
/// Holds guards that should live for the entire streaming lifecycle.
struct InFlightRequest {
    /// Guard to track in-flight request count.
    _guard: InFlightReadGuard,
    /// Label for `incr_stream_sent_item` metrics.
    metrics_label: &'static str,
    /// Logs stream throughput stats when dropped.
    throughput_logger: ThroughputLogger,
}

impl InFlightRequest {
    /// Create from request reference (extracts thread tracking automatically).
    fn new(metrics_label: &'static str, log_label: String) -> Self {
        Self {
            _guard: InFlightRead::guard(),
            metrics_label,
            throughput_logger: ThroughputLogger::new(log_label),
        }
    }

    /// Wrap a stream with in-flight tracking; logs throughput when stream completes.
    fn track<S>(mut self, strm: S) -> impl Stream<Item = Result<StreamItem, Status>>
    where S: Stream<Item = Result<StreamItem, Status>> {
        let metrics_label = self.metrics_label;
        strm.map(move |item| {
            // Reference guards to keep them alive for stream lifetime.
            // Rust 2021 closures only capture fields that are used;
            // without these references, guards would be dropped when track() returns.
            let _guard = &self._guard;

            network_metrics::incr_stream_sent_item(metrics_label);
            self.throughput_logger.incr_count();
            item
        })
    }
}

/// Logs stream throughput stats (items/ms, latency) when dropped.
struct ThroughputLogger {
    count: u64,
    start: Instant,
    log_label: String,
}

impl ThroughputLogger {
    fn new(log_label: String) -> Self {
        Self {
            count: 0,
            start: Instant::now(),
            log_label,
        }
    }

    fn incr_count(&mut self) {
        self.count += 1;
    }
}

impl Drop for ThroughputLogger {
    fn drop(&mut self) {
        let total = self.start.elapsed();
        let total_items = self.count;
        let items_per_ms = total_items / (total.as_millis() as u64 + 1);
        let latency = total / (total_items.max(1) as u32);
        info!(
            "StreamElapsed: total: {:?}; items: {}, items/ms: {}, item_latency: {:?}; {}",
            total, total_items, items_per_ms, latency, self.log_label
        );
    }
}

const LEGACY_USERNAME: &str = "root";

pub struct MetaServiceImpl<SP: SpawnApi> {
    token: GrpcToken,
    version: Version,
    auth: Option<GrpcAuthenticator>,
    /// MetaServiceImpl is not dropped if there is an alive connection.
    ///
    /// Thus make the reference to [`MetaNode`] a Weak reference so that it does not prevent [`MetaNode`] to be dropped
    pub(crate) meta_handle: Weak<MetaHandle<SP>>,
}

impl<SP: SpawnApi> Drop for MetaServiceImpl<SP> {
    fn drop(&mut self) {
        if let Some(meta_node) = self.meta_handle.upgrade() {
            debug!("MetaServiceImpl::drop: id={}", meta_node.id);
        } else {
            debug!("MetaServiceImpl::drop: inner MetaNode already dropped");
        }
    }
}

impl<SP: SpawnApi> MetaServiceImpl<SP> {
    pub fn create(
        version: Version,
        meta_handle: Weak<MetaHandle<SP>>,
        grpc_config: &GrpcConfig,
    ) -> Self {
        let auth = grpc_config.auth.as_ref();
        let auth = auth.map(GrpcAuthenticator::from_config);

        Self {
            token: GrpcToken::create(),
            version,
            auth,
            meta_handle,
        }
    }

    fn authenticate(&self, auth: &BasicAuth) -> Result<Option<&'static str>, Status> {
        let Some(authenticator) = &self.auth else {
            if auth.username != LEGACY_USERNAME {
                return Err(unknown_user(&auth.username));
            }
            return Ok(None);
        };

        authenticator.authenticate(auth)
    }

    pub fn try_get_meta_handle(&self) -> Result<Arc<MetaHandle<SP>>, Status> {
        self.meta_handle.upgrade().ok_or_else(|| {
            Status::internal("MetaNode is already dropped, can not serve new requests")
        })
    }

    fn check_token(&self, metadata: &MetadataMap) -> Result<GrpcClaim, Status> {
        let token = metadata
            .get_bin("auth-token-bin")
            .and_then(|v| v.to_bytes().ok())
            .and_then(|b| String::from_utf8(b.to_vec()).ok())
            .ok_or_else(|| Status::unauthenticated("Error auth-token-bin is empty"))?;

        let claim = self
            .token
            .try_verify_token(&token)
            .map_err(|e| Status::unauthenticated(format!("token verify failed: {}", e)))?;
        Ok(claim)
    }

    #[fastrace::trace]
    async fn handle_kv_api(&self, request: Request<RaftRequest>) -> Result<RaftReply, Status> {
        let req: MetaGrpcReq = request.try_into()?;

        let meta_handle = self.try_get_meta_handle()?;
        let id = meta_handle.id;

        debug!(
            "id={} {}: Received MetaGrpcReq: {:?}",
            id,
            func_name!(),
            req
        );

        let reply = match &req {
            MetaGrpcReq::UpsertKV(a) => {
                let res = meta_handle.handle_upsert_kv(a.clone()).await;
                debug!(
                    "id={} MetaGrpcReq UpsertKV: request: {:?} res: {:?}",
                    id, req, res
                );
                let res = res?;
                network_metrics::incr_request_result(res.is_ok());
                let upsert_reply = res.map_err(GrpcHelper::internal_err)?;
                RaftReply::new(&upsert_reply)
            }
        };

        Ok(reply)
    }

    #[fastrace::trace]
    async fn handle_kv_read_v1(
        &self,
        req: MetaGrpcReadReq,
    ) -> Result<(Option<Endpoint>, BoxStream<StreamItem>), Status> {
        debug!("{}: Received ReadRequest: {:?}", func_name!(), req);

        let meta_handle = self.try_get_meta_handle()?;

        let res = meta_handle.handle_kv_read_v1(req.clone()).await?;

        network_metrics::incr_request_result(res.is_ok());
        res
    }

    #[fastrace::trace]
    async fn handle_kv_list(
        &self,
        prefix: String,
        limit: Option<u64>,
    ) -> Result<BoxStream<StreamItem>, Status> {
        debug!(
            "{}: Received KvListRequest: prefix={}, limit={}",
            func_name!(),
            prefix,
            limit.display()
        );

        let meta_handle = self.try_get_meta_handle()?;

        let res = meta_handle.handle_kv_list(prefix, limit).await;
        network_metrics::incr_request_result(res.is_ok());

        res
    }

    #[fastrace::trace]
    async fn handle_kv_get_many(
        &self,
        input: impl Stream<Item = Result<KvGetManyRequest, Status>> + Send + 'static,
    ) -> Result<BoxStream<StreamItem>, Status> {
        debug!("{}: Received KvGetMany stream", func_name!());

        let meta_handle = self.try_get_meta_handle()?;

        let res = meta_handle.handle_kv_get_many(input).await;
        network_metrics::incr_request_result(res.is_ok());

        res
    }

    #[fastrace::trace]
    async fn handle_kv_transaction(
        &self,
        request: Request<pb::KvTransactionRequest>,
    ) -> Result<pb::KvTransactionReply, Status> {
        let txn = request.into_inner();

        debug!("{}: Received KvTransactionRequest: {:?}", func_name!(), txn);

        let meta_handle = self.try_get_meta_handle()?;

        let res = meta_handle.handle_kv_transaction(txn).await;
        network_metrics::incr_request_result(res.is_ok());
        res
    }

    #[fastrace::trace]
    async fn handle_txn(
        &self,
        request: Request<TxnRequest>,
    ) -> Result<(Option<Endpoint>, TxnReply), Status> {
        let txn = request.into_inner();

        debug!("{}: Received TxnRequest: {}", func_name!(), txn);

        let meta_handle = self.try_get_meta_handle()?;

        let log_msg = format!("TxnRequest: {}", txn);

        let res = meta_handle
            .handle_transaction(txn)
            .log_elapsed_info(log_msg)
            .await?;

        network_metrics::incr_request_result(res.is_ok());
        res
    }
}

impl<SP: SpawnApi> NamedService for MetaServiceImpl<SP> {
    const NAME: &'static str = "meta_service";
}

#[async_trait::async_trait]
impl<SP: SpawnApi> MetaService for MetaServiceImpl<SP> {
    type HandshakeStream = BoxStream<HandshakeResponse>;

    // rpc handshake first
    #[fastrace::trace]
    async fn handshake(
        &self,
        request: Request<Streaming<HandshakeRequest>>,
    ) -> Result<Response<Self::HandshakeStream>, Status> {
        let remote_addr = request.remote_addr();
        let req = request
            .into_inner()
            .next()
            .await
            .ok_or_else(|| Status::internal("Error request next is None"))??;

        let HandshakeRequest {
            protocol_version,
            payload,
        } = req;

        debug!("handle handshake request, client ver: {}", protocol_version);

        let min_compatible = MIN_CLIENT_VERSION.to_digit();

        // backward compatibility: no version in handshake.
        if protocol_version > 0 && protocol_version < min_compatible {
            return Err(Status::invalid_argument(format!(
                "meta-client protocol_version({}) < metasrv min-compatible({})",
                Version::from_digit(protocol_version),
                MIN_CLIENT_VERSION,
            )));
        }

        let auth = BasicAuth::decode(&*payload).map_err(|e| Status::internal(e.to_string()))?;

        let permissive_reason = self.authenticate(&auth)?;
        if let Some(reason) = permissive_reason {
            network_metrics::incr_unauthenticated_passed(reason);
            warn_permissive_auth(reason, remote_addr);
        } else if self.auth.is_some() {
            network_metrics::incr_authenticated(&auth.username);
        }

        let claim = GrpcClaim {
            username: auth.username,
        };
        let token = self
            .token
            .try_create_token(claim)
            .map_err(|e| Status::internal(e.to_string()))?;

        let resp = HandshakeResponse {
            protocol_version: self.version.to_digit(),
            payload: token.into_bytes(),
        };
        let output = futures::stream::once(async { Ok(resp) });

        debug!("handshake OK");
        Ok(Response::new(Box::pin(output)))
    }

    async fn kv_api(&self, request: Request<RaftRequest>) -> Result<Response<RaftReply>, Status> {
        self.check_token(request.metadata())?;

        network_metrics::incr_recv_bytes(request.get_ref().encoded_len() as u64);
        let query_id = get_query_id(&request).map(|s| s.to_owned());

        SP::trace_request(func_path!(), request, |request| async move {
            let fu = async move {
                let _guard = InFlightWrite::guard();

                let reply = self.handle_kv_api(request).await?;

                network_metrics::incr_sent_bytes(reply.encoded_len() as u64);

                Ok(Response::new(reply))
            };

            SP::track_future(fu, vec![TrackingData::new_query_id(query_id)]).await
        })
        .await
    }

    type KvReadV1Stream = BoxStream<StreamItem>;

    async fn kv_read_v1(
        &self,
        request: Request<RaftRequest>,
    ) -> Result<Response<Self::KvReadV1Stream>, Status> {
        self.check_token(request.metadata())?;

        network_metrics::incr_recv_bytes(request.get_ref().encoded_len() as u64);
        let query_id = get_query_id(&request).map(|s| s.to_owned());

        SP::trace_request(func_path!(), request, |request| async move {
            let req: MetaGrpcReadReq = GrpcHelper::parse_req(request)?;
            let in_flight =
                InFlightRequest::new(req.type_name(), format!("ReadRequest: {:?}", req));

            let fut = async {
                let (endpoint, strm) = self.handle_kv_read_v1(req).await?;

                let strm = in_flight.track(strm);

                let mut resp = Response::new(strm.boxed());
                GrpcHelper::add_response_meta_leader(&mut resp, endpoint.as_ref());
                Ok(resp)
            };

            SP::track_future(fut, vec![TrackingData::new_query_id(query_id)]).await
        })
        .await
    }

    type KvListStream = BoxStream<StreamItem>;

    /// List key-value pairs by prefix.
    ///
    /// This RPC requires leadership. If this node is not the leader,
    /// it returns a `Status::unavailable` error with the leader's endpoint in metadata.
    /// Clients should retry with the leader directly.
    async fn kv_list(
        &self,
        request: Request<KvListRequest>,
    ) -> Result<Response<Self::KvListStream>, Status> {
        self.check_token(request.metadata())?;

        network_metrics::incr_recv_bytes(request.get_ref().encoded_len() as u64);
        let query_id = get_query_id(&request).map(|s| s.to_owned());

        SP::trace_request(func_path!(), request, |request| async move {
            let in_flight = InFlightRequest::new(
                "list",
                format!(
                    "KvList: prefix={}, limit={}",
                    request.get_ref().prefix,
                    request.get_ref().limit.display()
                ),
            );
            let req = request.into_inner();

            let fut = async {
                let strm = self.handle_kv_list(req.prefix, req.limit).await?;

                let strm = in_flight.track(strm);
                Ok(Response::new(strm.boxed()))
            };

            SP::track_future(fut, vec![TrackingData::new_query_id(query_id)]).await
        })
        .await
    }

    type KvGetManyStream = BoxStream<StreamItem>;

    /// Get multiple key-value pairs by streaming keys.
    ///
    /// This RPC requires leadership. If this node is not the leader,
    /// it returns a `Status::unavailable` error with the leader's endpoint in metadata.
    /// Clients should retry with the leader directly.
    async fn kv_get_many(
        &self,
        request: Request<Streaming<KvGetManyRequest>>,
    ) -> Result<Response<Self::KvGetManyStream>, Status> {
        self.check_token(request.metadata())?;

        let query_id = get_query_id(&request).map(|s| s.to_owned());

        SP::trace_request(func_path!(), request, |request| async move {
            let in_flight = InFlightRequest::new("mget", "KvGetMany".to_string());
            let input = request
                .into_inner()
                .inspect_ok(|req| network_metrics::incr_recv_bytes(req.encoded_len() as u64));

            let fut = async {
                let strm = self.handle_kv_get_many(input).await?;

                let strm = in_flight.track(strm);
                Ok(Response::new(strm.boxed()))
            };

            SP::track_future(fut, vec![TrackingData::new_query_id(query_id)]).await
        })
        .await
    }

    async fn transaction(
        &self,
        request: Request<TxnRequest>,
    ) -> Result<Response<TxnReply>, Status> {
        self.check_token(request.metadata())?;

        let query_id = get_query_id(&request).map(|s| s.to_owned());

        SP::trace_request(func_path!(), request, |request| async move {
            let fut = async move {
                network_metrics::incr_recv_bytes(request.get_ref().encoded_len() as u64);
                let _guard = InFlightWrite::guard();

                let (endpoint, reply) = self.handle_txn(request).await?;

                network_metrics::incr_sent_bytes(reply.encoded_len() as u64);

                let mut resp = Response::new(reply);
                GrpcHelper::add_response_meta_leader(&mut resp, endpoint.as_ref());

                Ok(resp)
            };

            SP::track_future(fut, vec![TrackingData::new_query_id(query_id)]).await
        })
        .await
    }

    async fn kv_transaction(
        &self,
        request: Request<pb::KvTransactionRequest>,
    ) -> Result<Response<pb::KvTransactionReply>, Status> {
        self.check_token(request.metadata())?;

        let query_id = get_query_id(&request).map(|s| s.to_owned());

        SP::trace_request(func_path!(), request, |request| async move {
            let fut = async move {
                network_metrics::incr_recv_bytes(request.get_ref().encoded_len() as u64);
                let _guard = InFlightWrite::guard();

                let reply = self.handle_kv_transaction(request).await?;

                network_metrics::incr_sent_bytes(reply.encoded_len() as u64);

                Ok(Response::new(reply))
            };

            SP::track_future(fut, vec![TrackingData::new_query_id(query_id)]).await
        })
        .await
    }

    type ExportStream = Pin<Box<dyn Stream<Item = Result<ExportedChunk, Status>> + Send + 'static>>;

    /// Export all meta service data.
    ///
    /// Including header, raft state, logs and state machine.
    /// The exported data is a series of JSON encoded strings of `RaftStoreEntry`.
    async fn export(
        &self,
        request: Request<databend_meta_types::protobuf::Empty>,
    ) -> Result<Response<Self::ExportStream>, Status> {
        self.check_token(request.metadata())?;

        let guard = InFlightRead::guard();

        let meta_handle = self.try_get_meta_handle()?;

        let strm = meta_handle.handle_export().await?;

        let chunk_size = 32;
        // - Chunk up upto 32 Ok items inside a Vec<String>;
        // - Convert Vec<String> to ExportedChunk;
        // - Convert TryChunkError<_, io::Error> to Status;
        let s = strm
            .map(move |x| {
                let _g = &guard; // hold the guard until the stream is done.
                x
            })
            .try_chunks(chunk_size)
            .map_ok(|chunk: Vec<String>| ExportedChunk { data: chunk })
            .map_err(|e: TryChunksError<_, io::Error>| Status::internal(e.1.to_string()));

        Ok(Response::new(Box::pin(s)))
    }

    type ExportV1Stream =
        Pin<Box<dyn Stream<Item = Result<ExportedChunk, Status>> + Send + 'static>>;

    /// Export all meta data.
    ///
    /// Including header, raft state, logs and state machine.
    /// The exported data is a series of JSON encoded strings of `RaftStoreEntry`.
    async fn export_v1(
        &self,
        request: Request<pb::ExportRequest>,
    ) -> Result<Response<Self::ExportV1Stream>, Status> {
        self.check_token(request.metadata())?;

        let guard = InFlightRead::guard();

        let meta_handle = self.try_get_meta_handle()?;

        let strm = meta_handle.handle_export().await?;

        let chunk_size = request.get_ref().chunk_size.unwrap_or(32) as usize;
        // - Chunk up upto `chunk_size` Ok items inside a Vec<String>;
        // - Convert Vec<String> to ExportedChunk;
        // - Convert TryChunkError<_, io::Error> to Status;
        let s = strm
            .map(move |x| {
                let _g = &guard; // hold the guard until the stream is done.
                x
            })
            .try_chunks(chunk_size)
            .map_ok(|chunk: Vec<String>| ExportedChunk { data: chunk })
            .map_err(|e: TryChunksError<_, io::Error>| Status::internal(e.1.to_string()));

        Ok(Response::new(Box::pin(s)))
    }

    type SnapshotKeysLayoutStream =
        Pin<Box<dyn Stream<Item = Result<KeysCount, Status>> + Send + 'static>>;

    async fn snapshot_keys_layout(
        &self,
        request: Request<KeysLayoutRequest>,
    ) -> Result<Response<Self::SnapshotKeysLayoutStream>, Status> {
        self.check_token(request.metadata())?;

        let guard = InFlightRead::guard();

        let layout_request = request.into_inner();

        let meta_handle = self.try_get_meta_handle()?;

        let strm = meta_handle
            .handle_snapshot_keys_layout(layout_request)
            .await??;

        let s = strm.map(move |x| {
            let _g = &guard; // hold the guard until the stream is done.
            x.map_err(|e| Status::internal(e.to_string()))
        });

        Ok(Response::new(Box::pin(s)))
    }

    type WatchStream = Pin<Box<dyn Stream<Item = Result<WatchResponse, Status>> + Send + 'static>>;

    #[fastrace::trace]
    async fn watch(
        &self,
        request: Request<WatchRequest>,
    ) -> Result<Response<Self::WatchStream>, Status> {
        self.check_token(request.metadata())?;

        let watch = request.into_inner();

        let meta_handle = self.try_get_meta_handle()?;
        let stream = meta_handle.handle_watch(watch).await??;

        Ok(Response::new(stream as Self::WatchStream))
    }

    async fn member_list(
        &self,
        request: Request<MemberListRequest>,
    ) -> Result<Response<MemberListReply>, Status> {
        self.check_token(request.metadata())?;

        let _guard = InFlightRead::guard();

        let meta_handle = self.try_get_meta_handle()?;

        let members = meta_handle.handle_member_list(request.into_inner()).await?;

        let resp = MemberListReply { data: members };
        network_metrics::incr_sent_bytes(resp.encoded_len() as u64);

        Ok(Response::new(resp))
    }

    async fn get_cluster_status(
        &self,
        request: Request<Empty>,
    ) -> Result<Response<ClusterStatus>, Status> {
        self.check_token(request.metadata())?;

        let _guard = InFlightRead::guard();

        let meta_handle = self.try_get_meta_handle()?;

        let status = meta_handle
            .handle_get_status(&self.version.to_string())
            .await?;

        let resp = ClusterStatus {
            id: status.id,
            binary_version: status.binary_version,
            data_version: status.data_version.to_string(),
            endpoint: status.endpoint.unwrap_or_default(),

            raft_log_size: status.raft_log.wal_total_size,

            raft_log_status: Some(pb::RaftLogStatus {
                cache_items: status.raft_log.cache_items,
                cache_used_size: status.raft_log.cache_used_size,
                wal_total_size: status.raft_log.wal_total_size,
                wal_open_chunk_size: status.raft_log.wal_open_chunk_size,
                wal_offset: status.raft_log.wal_offset,
                wal_closed_chunk_count: status.raft_log.wal_closed_chunk_count,
                wal_closed_chunk_total_size: status.raft_log.wal_closed_chunk_total_size,
                wal_closed_chunk_sizes: status.raft_log.wal_closed_chunk_sizes,
            }),

            snapshot_key_count: status.snapshot_key_count,

            state: status.state,
            is_leader: status.is_leader,
            current_term: status.current_term,
            last_log_index: status.last_log_index,
            last_applied: status.last_applied.to_string(),
            snapshot_last_log_id: status.snapshot_last_log_id.map(|id| id.to_string()),
            purged: status.purged.map(|id| id.to_string()),
            leader: status.leader.map(|node| node.to_string()),
            replication: status
                .replication
                .unwrap_or_default()
                .into_iter()
                .filter_map(|(k, v)| v.map(|v| (k, v.to_string())))
                .collect(),
            voters: status.voters.iter().map(|n| n.to_string()).collect(),
            non_voters: status.non_voters.iter().map(|n| n.to_string()).collect(),
            last_seq: status.last_seq,
        };
        Ok(Response::new(resp))
    }

    async fn get_client_info(
        &self,
        request: Request<Empty>,
    ) -> Result<Response<ClientInfo>, Status> {
        self.check_token(request.metadata())?;

        let _guard = InFlightRead::guard();

        let r = request.remote_addr();
        if let Some(addr) = r {
            let resp = ClientInfo {
                client_addr: addr.to_string(),
                server_time: Some(
                    SystemTime::now()
                        .duration_since(SystemTime::UNIX_EPOCH)
                        .unwrap()
                        .as_millis() as u64,
                ),
            };
            return Ok(Response::new(resp));
        }
        Err(Status::unavailable("can not get client ip address"))
    }
}

fn warn_permissive_auth(reason: &str, remote_addr: Option<SocketAddr>) {
    let peer = match remote_addr {
        Some(addr) => addr.to_string(),
        None => "unknown address".to_string(),
    };
    warn!(
        "gRPC password is {}: from:{}: accepted because `grpc_auth.strict` is off",
        reason, peer
    );
}

fn get_query_id<T>(req: &Request<T>) -> Option<String> {
    let value = req.metadata().get("QueryID")?;
    let value = value.to_str().ok()?;

    Some(value.to_string())
}

/// Try to remove a [`WatchStream`] from the subscriber.
///
/// This function receives two weak references: one to the sender and one to the dispatcher handle.
/// Using weak references prevents memory leaks by avoiding cyclic references when these are captured in closures.
/// If either reference can't be upgraded, the function logs the situation and returns early.
pub(crate) fn try_remove_sender(
    weak_sender: Weak<WatchStreamSender<WatchTypes>>,
    weak_handle: Weak<DispatcherHandle>,
    ctx: &str,
) {
    info!("{ctx}: try removing:  {:?}", weak_sender);

    let Some(d) = weak_handle.upgrade() else {
        debug!(
            "{ctx}: when try removing {:?}; dispatcher is already dropped",
            weak_sender
        );
        return;
    };

    let Some(sender) = weak_sender.upgrade() else {
        debug!(
            "on_drop is called for WatchStream {:?}; but sender is already dropped",
            weak_sender
        );
        return;
    };

    debug!("{ctx}: request is sent to remove watcher: {}", sender);

    d.request(move |dispatcher| {
        dispatcher.remove_watcher(sender);
    })
}
