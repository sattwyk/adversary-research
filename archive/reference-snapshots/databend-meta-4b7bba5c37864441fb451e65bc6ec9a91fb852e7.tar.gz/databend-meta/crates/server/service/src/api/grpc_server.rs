// Copyright 2021 Datafuse Labs
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use std::net::SocketAddr;
use std::sync::Arc;
use std::time::Duration;

use anyerror::AnyError;
use databend_base::shutdown::Graceful;
use databend_meta_runtime_api::JoinHandle;
use databend_meta_runtime_api::SpawnApi;
use databend_meta_types::MetaNetworkError;
use databend_meta_types::protobuf::FILE_DESCRIPTOR_SET;
use databend_meta_types::protobuf::meta_service_server::MetaServiceServer;
use databend_meta_version::Version;
use databend_meta_version::version;
use fastrace::prelude::*;
use futures::future::BoxFuture;
use futures::future::Either;
use futures::future::select;
use log::info;
use tokio::sync::oneshot;
use tokio::sync::oneshot::Sender;
use tonic::transport::Identity;
use tonic::transport::Server;
use tonic::transport::ServerTlsConfig;
use tonic::transport::server::TcpIncoming;

use crate::api::grpc::grpc_service::MetaServiceImpl;
use crate::configs::MetaServiceConfig;
use crate::meta_node::meta_handle::MetaHandle;
use crate::meta_service::MetaNode;
use crate::util::DropDebug;

pub struct GrpcServer<SP: SpawnApi> {
    config: MetaServiceConfig,
    pub version: Version,
    /// GrpcServer is the main container of the gRPC service.
    /// [`MetaNode`] should never be dropped while [`GrpcServer`] is alive.
    /// Therefore, it is held by a strong reference (Arc) to ensure proper lifetime management.
    pub meta_handle: Option<Arc<MetaHandle<SP>>>,
    join_handle: Option<JoinHandle<()>>,
    stop_grpc_tx: Option<Sender<()>>,
}

impl<SP: SpawnApi> Drop for GrpcServer<SP> {
    fn drop(&mut self) {
        info!("GrpcServer::drop: id={}", self.config.raft_config.id);
    }
}

impl<SP: SpawnApi> GrpcServer<SP> {
    pub fn create(config: &MetaServiceConfig, meta_handle: Arc<MetaHandle<SP>>) -> Self {
        Self {
            config: config.clone(),
            version: *version(),
            meta_handle: Some(meta_handle),
            join_handle: None,
            stop_grpc_tx: None,
        }
    }

    pub fn get_meta_handle(&self) -> Arc<MetaHandle<SP>> {
        self.meta_handle.clone().unwrap()
    }

    /// Returns the gRPC config, which includes the actual bound port after `bind()` or `do_start()`.
    pub fn grpc_config(&self) -> &crate::configs::GrpcConfig {
        &self.config.grpc
    }

    // Only for test
    pub async fn get_meta_node(&self) -> Arc<MetaNode<SP>> {
        self.meta_handle
            .as_ref()
            .unwrap()
            .get_meta_node()
            .await
            .unwrap()
    }

    /// Binds a TCP listener for the gRPC server.
    ///
    /// If `listen_port` is `None`, binds to port 0 for OS-assigned port.
    /// The actual bound port is NOT updated in config here; it will be set in `do_start_with_incoming()`.
    pub fn bind(&self) -> Result<TcpIncoming, MetaNetworkError> {
        let port = self.config.grpc.listen_port.unwrap_or(0);
        let addr: SocketAddr = format!("{}:{}", self.config.grpc.listen_host, port).parse()?;

        let incoming = TcpIncoming::bind(addr)
            .map_err(|e| MetaNetworkError::BadAddressFormat(AnyError::new(&e)))?
            .with_nodelay(Some(true));

        Ok(incoming)
    }

    pub async fn do_start(&mut self) -> Result<(), MetaNetworkError> {
        let incoming = self.bind()?;
        self.do_start_with_incoming(incoming).await
    }

    pub async fn do_start_with_incoming(
        &mut self,
        incoming: TcpIncoming,
    ) -> Result<(), MetaNetworkError> {
        let addr = incoming
            .local_addr()
            .map_err(|e| MetaNetworkError::BadAddressFormat(AnyError::new(&e)))?;

        // Update config with actual bound port
        self.config.grpc.listen_port = Some(addr.port());

        info!("GrpcServer::start");

        let meta_handle = self.meta_handle.clone().unwrap();
        // For sending signal when server started.
        let (started_tx, started_rx) = oneshot::channel::<()>();
        // For receive stop signal.
        let (stop_grpc_tx, stop_rx) = oneshot::channel::<()>();

        let reflect_srv = tonic_reflection::server::Builder::configure()
            .register_encoded_file_descriptor_set(FILE_DESCRIPTOR_SET)
            .build_v1()
            .unwrap();

        // Configure HTTP/2 settings to handle stream reset accumulation.
        // The default limit (20) can be too low under high concurrency.
        // Setting to None disables the limit entirely.
        let builder = Server::builder().http2_max_pending_accept_reset_streams(Some(4096));

        let tls_conf = Self::tls_config(&self.config.grpc)
            .await
            .map_err(|e| MetaNetworkError::TLSConfigError(AnyError::new(&e)))?;

        let mut builder = if let Some(tls_conf) = tls_conf {
            info!("gRPC TLS enabled");
            let _ = rustls::crypto::ring::default_provider().install_default();
            builder
                .tls_config(tls_conf)
                .map_err(|e| MetaNetworkError::TLSConfigError(AnyError::new(&e)))?
        } else {
            builder
        };

        info!("start gRPC listening: {}", addr);

        let grpc_impl = MetaServiceImpl::create(
            self.version,
            Arc::downgrade(&meta_handle),
            &self.config.grpc,
        );
        let max_msg_size = self.config.grpc.max_message_size();
        let grpc_srv = MetaServiceServer::new(grpc_impl)
            .max_decoding_message_size(max_msg_size)
            .max_encoding_message_size(max_msg_size);

        let router = builder.add_service(reflect_srv).add_service(grpc_srv);

        let id = self.config.raft_config.id;

        let shutdown_fut = async move {
            started_tx.send(()).ok();
            info!(
                "meta-service gRPC(on {}) starts to wait for stop signal",
                addr
            );
            let _ = stop_rx.await;
            info!("meta-service gRPC(on {}) receives stop signal", addr);
        };

        let fu = async move {
            let _d = DropDebug::new(format!("GrpcServer(id={}) spawned service task", id));

            let res = router
                .serve_with_incoming_shutdown(incoming, shutdown_fut)
                .await;

            info!(
                "meta-service gRPC(on {}) task returned res: {:?}",
                addr, res
            );
        };

        let serving_fut = fu.in_span(Span::enter_with_local_parent("spawn-grpc"));

        let join_handle = SP::spawn(serving_fut, Some("grpc-server".into()));

        started_rx
            .await
            .expect("maybe address already in use, try to use another port");

        self.join_handle = Some(join_handle);
        self.stop_grpc_tx = Some(stop_grpc_tx);

        info!("Done GrpcServer::start");
        Ok(())
    }

    pub async fn do_stop(&mut self, _force: Option<BoxFuture<'static, ()>>) {
        info!("GrpcServer::stop");

        let meta_handle = self.meta_handle.take();
        let Some(meta_handle) = meta_handle else {
            info!("GrpcServer::do_stop: already stopped");
            return;
        };

        let id = meta_handle.id;
        let ctx = format!("gRPC-task(id={id})");

        if let Some(stop_grpc_tx) = self.stop_grpc_tx.take() {
            info!("Sending stop signal to {ctx}");
            let _ = stop_grpc_tx.send(());
        }

        if let Some(jh) = self.join_handle.take() {
            info!("Waiting for {ctx} to stop");

            let timeout = Duration::from_millis(1_000);
            let sleep = tokio::time::sleep(timeout);

            let slp = std::pin::pin!(sleep);

            match select(slp, jh).await {
                Either::Left((_v1, jh)) => {
                    info!("{ctx} stop timeout after {:?}; force abort", timeout);
                    jh.abort();
                    jh.await.ok();
                    info!("Done: waiting for {ctx} force stop");
                }
                Either::Right((_v2, _slp)) => {
                    info!("Done: waiting for {ctx} normal stop");
                }
            }
        }

        info!(
            "Drop MetaHandle for meta_node(id={id}) to stop, ref count to meta-handle: {}",
            Arc::strong_count(&meta_handle)
        );
        drop(meta_handle);

        info!("Done GrpcServer::stop");
    }

    async fn tls_config(
        grpc_config: &crate::configs::GrpcConfig,
    ) -> Result<Option<ServerTlsConfig>, std::io::Error> {
        if grpc_config.tls.enabled() {
            let cert = tokio::fs::read(grpc_config.tls.cert.as_str()).await?;
            let key = tokio::fs::read(grpc_config.tls.key.as_str()).await?;
            let server_identity = Identity::from_pem(cert, key);

            let tls = ServerTlsConfig::new().identity(server_identity);
            Ok(Some(tls))
        } else {
            Ok(None)
        }
    }
}

#[async_trait::async_trait]
impl<SP: SpawnApi> Graceful for GrpcServer<SP> {
    type Error = AnyError;

    async fn shutdown(&mut self, force: Option<BoxFuture<'static, ()>>) -> Result<(), Self::Error> {
        self.do_stop(force).await;
        Ok(())
    }
}
