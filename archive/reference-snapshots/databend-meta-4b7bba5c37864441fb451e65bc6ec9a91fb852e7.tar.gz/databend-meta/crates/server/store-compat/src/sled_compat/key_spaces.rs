// Copyright 2021 Datafuse Labs
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

//! Storage partitioning by data type with unique prefixes.
//!
//! Each key space stores a specific data type:
//! - **Logs** (V003): Raft log entries by index
//! - **Nodes**: Cluster membership by node ID
//! - **StateMachineMeta**: Last applied log and metadata
//! - **RaftStateKV** (V003): Node state (ID, vote, committed log)
//! - **Expire**: TTL expiration index by time
//! - **GenericKV**: User data with sequence numbers
//! - **Sequences**: Monotonic sequence generators
//! - **LogMeta** (V003): Log metadata for purging
//!
//! V003 uses sled storage (legacy), V004 uses separate raft log with leveled state machine.

use std::io;

use databend_meta_raft_config::header::Header;
use databend_meta_sled_store::IVec;
use databend_meta_sled_store::SledKeySpace;
use databend_meta_sled_store::SledOrderedSerde;
use databend_meta_sled_store::SledSerde;
use databend_meta_types::SeqNum;
use databend_meta_types::SeqV;
use databend_meta_types::node::Node;
use databend_meta_types::raft_types::Entry;
use databend_meta_types::raft_types::LogId;
use databend_meta_types::raft_types::LogIndex;
use databend_meta_types::raft_types::NodeId;
use databend_meta_types::raft_types::Vote;
use serde::Deserialize;
use serde::Serialize;
use state_machine_api::ExpireKey;
use state_machine_api::ExpireValue;

use crate::sled_compat::LogMetaKey;
use crate::sled_compat::LogMetaValue;
use crate::sled_compat::RaftStateKey;
use crate::sled_compat::RaftStateValue;
use crate::sled_compat::StateMachineMetaKey;
use crate::sled_compat::StateMachineMetaValue;
use crate::sled_compat::sled_header::SledHeader;

/// Raft log entries storage key space (V003 only).
///
/// Maps log index to raft entries. In V004, logs are stored separately
/// in WAL format for better performance.
/// - Key: [`LogIndex`] (u64) - Sequential log entry index
/// - Value: [`Entry`] - Complete raft log entry with payload
pub struct Logs {}
impl SledKeySpace for Logs {
    const PREFIX: u8 = 1;
    const NAME: &'static str = "log";
    type K = LogIndex;
    type V = Entry;
}

/// Log metadata storage key space (V003 only).
///
/// Stores metadata about raft logs for purging and management.
/// Used to track log ranges and cleanup operations.
/// - Key: [`LogMetaKey`] - Metadata type identifier
/// - Value: [`LogMetaValue`] - Log metadata information
pub struct LogMeta {}
impl SledKeySpace for LogMeta {
    const PREFIX: u8 = 13;
    const NAME: &'static str = "log-meta";
    type K = LogMetaKey;
    type V = LogMetaValue;
}

/// Cluster node information storage key space.
///
/// Maps node IDs to node configuration and endpoint information.
/// Used for cluster membership management and node discovery.
/// - Key: [`NodeId`] (u64) - Unique node identifier
/// - Value: [`Node`] - Node configuration with endpoint and metadata
pub struct Nodes {}
impl SledKeySpace for Nodes {
    const PREFIX: u8 = 2;
    const NAME: &'static str = "node";
    type K = NodeId;
    type V = Node;
}

/// State machine metadata storage key space.
///
/// Stores critical state machine metadata like last applied log ID
/// and other operational state required for consistency.
/// - Key: [`StateMachineMetaKey`] - Metadata type identifier
/// - Value: [`StateMachineMetaValue`] - State machine metadata
pub struct StateMachineMeta {}
impl SledKeySpace for StateMachineMeta {
    const PREFIX: u8 = 3;
    const NAME: &'static str = "sm-meta";
    type K = StateMachineMetaKey;
    type V = StateMachineMetaValue;
}

/// Raft consensus state storage key space (V003 only).
///
/// Stores core raft state including node ID, vote information,
/// and committed log index. Critical for raft consensus protocol.
/// - Key: [`RaftStateKey`] - State type identifier
/// - Value: [`RaftStateValue`] - Raft state data
pub struct RaftStateKV {}
impl SledKeySpace for RaftStateKV {
    const PREFIX: u8 = 4;
    const NAME: &'static str = "raft-state";
    type K = RaftStateKey;
    type V = RaftStateValue;
}

/// TTL expiration index storage key space.
///
/// Secondary index for records with expiration times, ordered by expire time.
/// Enables efficient cleanup of expired entries during log application.
/// - Key: [`ExpireKey`] - Expiration time and sequence
/// - Value: [`ExpireValue`] - Original key that expires
pub struct Expire {}
impl SledKeySpace for Expire {
    const PREFIX: u8 = 5;
    const NAME: &'static str = "expire";
    type K = ExpireKey;
    type V = ExpireValue;
}

/// User data storage key space.
///
/// Primary storage for application key-value data with sequence numbers
/// for versioning and consistency. Supports TTL and conditional operations.
/// - Key: [`String`] - User-defined key
/// - Value: [`SeqV<Vec<u8>>`] - Sequenced value with metadata
pub struct GenericKV {}
impl SledKeySpace for GenericKV {
    const PREFIX: u8 = 6;
    const NAME: &'static str = "generic-kv";
    type K = String;
    type V = SeqV<Vec<u8>>;
}

/// Monotonic sequence generator storage key space.
///
/// Provides atomic sequence number generation for various purposes
/// like auto-incrementing IDs and sequential key generation.
/// - Key: [`String`] - Sequence name identifier
/// - Value: [`SeqNum`] - Current sequence number
pub struct Sequences {}
impl SledKeySpace for Sequences {
    const PREFIX: u8 = 7;
    const NAME: &'static str = "sequences";
    type K = String;
    type V = SeqNum;
}

// Reserved: removed: `pub struct ClientLastResps {}`, PREFIX = 10;

/// Storage metadata header key space.
///
/// Stores version information and metadata about the storage format
/// for compatibility checking and data migration purposes.
/// - Key: [`String`] - Header type identifier
/// - Value: [`SledHeader`] - Storage format metadata
pub struct DataHeader {}
impl SledKeySpace for DataHeader {
    const PREFIX: u8 = 11;
    const NAME: &'static str = "data-header";
    type K = String;
    type V = SledHeader;
}

/// Convert SledBytesError to io::Error.
fn sled_bytes_err(e: databend_meta_sled_store::SledBytesError) -> io::Error {
    io::Error::from(e)
}

/// Split a sled key into its key-space prefix and the key bytes.
///
/// The input comes from on-disk data, so a corrupt or foreign key must be
/// reported instead of panicking.
fn split_prefix(prefix_key: &[u8]) -> Result<(u8, &[u8]), io::Error> {
    let Some((prefix, key)) = prefix_key.split_first() else {
        return Err(io::Error::new(
            io::ErrorKind::InvalidData,
            "empty sled key: no key space prefix",
        ));
    };

    Ok((*prefix, key))
}

fn unknown_prefix(prefix: u8) -> io::Error {
    io::Error::new(
        io::ErrorKind::InvalidData,
        format!("unknown key space prefix: {}", prefix),
    )
}

/// Serialize SledKeySpace key value pair
macro_rules! serialize_for_sled {
    ($ks:tt, $key:expr, $value:expr) => {
        Ok((
            $ks::serialize_key($key).map_err(sled_bytes_err)?,
            $ks::serialize_value($value).map_err(sled_bytes_err)?,
        ))
    };
}

/// Convert (sub_tree_prefix, key, value, key_space1, key_space2...) into a [`RaftStoreEntry`].
///
/// It compares the sub_tree_prefix with prefix defined by every key space to determine which key space it belongs to.
macro_rules! deserialize_by_prefix {
    ($prefix: expr, $vec_key: expr, $vec_value: expr, $($key_space: tt),+ ) => {
        $(

        if <$key_space as SledKeySpace>::PREFIX == $prefix {

            let key = SledOrderedSerde::de($vec_key).map_err(sled_bytes_err)?;
            let value = SledSerde::de($vec_value).map_err(sled_bytes_err)?;

            // Self reference the enum that use this macro
            return Ok(Self::$key_space { key, value, });
        }
        )+
    };
}

/// Enum of key-value pairs that are used in the raft state machine.
///
/// It is a sub set of [`RaftStoreEntry`] and contains only the types used by state-machine.
#[rustfmt::skip]
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum SMEntry {
    DataHeader       { key: <DataHeader       as SledKeySpace>::K, value: <DataHeader       as SledKeySpace>::V, },
    Nodes            { key: <Nodes            as SledKeySpace>::K, value: <Nodes            as SledKeySpace>::V, },
    StateMachineMeta { key: <StateMachineMeta as SledKeySpace>::K, value: <StateMachineMeta as SledKeySpace>::V, },
    Expire           { key: <Expire           as SledKeySpace>::K, value: <Expire           as SledKeySpace>::V, },
    GenericKV        { key: <GenericKV        as SledKeySpace>::K, value: <GenericKV        as SledKeySpace>::V, },
    Sequences        { key: <Sequences        as SledKeySpace>::K, value: <Sequences        as SledKeySpace>::V, },
}

impl SMEntry {
    /// Serialize a key-value entry into a two elt vec of `Vec<u8>`: `[key, value]`.
    #[rustfmt::skip]
    pub fn serialize(kv: &SMEntry) -> Result<(IVec, IVec), io::Error> {

        match kv {
            Self::DataHeader       { key, value } => serialize_for_sled!(DataHeader,       key, value),
            Self::Nodes            { key, value } => serialize_for_sled!(Nodes,            key, value),
            Self::StateMachineMeta { key, value } => serialize_for_sled!(StateMachineMeta, key, value),
            Self::Expire           { key, value } => serialize_for_sled!(Expire,           key, value),
            Self::GenericKV        { key, value } => serialize_for_sled!(GenericKV,        key, value),
            Self::Sequences        { key, value } => serialize_for_sled!(Sequences,        key, value),
        }
    }

    /// Deserialize a serialized key-value entry `[key, value]`.
    ///
    /// It is able to deserialize openraft-v7 or openraft-v8 key-value pairs.
    /// The compatibility is provided by [`SledSerde`] implementation for value types.
    pub fn deserialize(prefix_key: &[u8], vec_value: &[u8]) -> Result<Self, io::Error> {
        let (prefix, vec_key) = split_prefix(prefix_key)?;

        deserialize_by_prefix!(
            prefix,
            vec_key,
            vec_value,
            // Available key spaces:
            DataHeader,
            Nodes,
            StateMachineMeta,
            Expire,
            GenericKV,
            Sequences
        );

        Err(unknown_prefix(prefix))
    }

    pub fn last_applied(&self) -> Option<LogId> {
        match self {
            Self::StateMachineMeta { key, value } => {
                if *key == StateMachineMetaKey::LastApplied {
                    let last: LogId = value.clone().try_into().unwrap();
                    Some(last)
                } else {
                    None
                }
            }
            _ => None,
        }
    }
}

/// Enum of key-value pairs that are used in the raft storage impl for meta-service.
#[rustfmt::skip]
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum RaftStoreEntry {
    DataHeader       { key: <DataHeader       as SledKeySpace>::K, value: <DataHeader       as SledKeySpace>::V, },
    // V003 only
    Logs             { key: <Logs             as SledKeySpace>::K, value: <Logs             as SledKeySpace>::V, },
    Nodes            { key: <Nodes            as SledKeySpace>::K, value: <Nodes            as SledKeySpace>::V, },
    StateMachineMeta { key: <StateMachineMeta as SledKeySpace>::K, value: <StateMachineMeta as SledKeySpace>::V, },
    // V003 only
    RaftStateKV      { key: <RaftStateKV      as SledKeySpace>::K, value: <RaftStateKV      as SledKeySpace>::V, },
    Expire           { key: <Expire           as SledKeySpace>::K, value: <Expire           as SledKeySpace>::V, },
    GenericKV        { key: <GenericKV        as SledKeySpace>::K, value: <GenericKV        as SledKeySpace>::V, },
    Sequences        { key: <Sequences        as SledKeySpace>::K, value: <Sequences        as SledKeySpace>::V, },
    // V003 only
    LogMeta          { key: <LogMeta          as SledKeySpace>::K, value: <LogMeta          as SledKeySpace>::V, },

    // V004 log:
    LogEntry(Entry),
    NodeId(Option<NodeId>),
    Vote(Option<Vote>),
    Committed(Option<LogId>),
    Purged(Option<LogId>),
}

impl RaftStoreEntry {
    /// Upgrade V003 to V004
    pub fn upgrade(self) -> Self {
        match self.clone() {
            Self::Logs { key: _, value } => Self::LogEntry(value),
            Self::RaftStateKV { key: _, value } => match value {
                RaftStateValue::NodeId(node_id) => Self::NodeId(Some(node_id)),
                RaftStateValue::HardState(vote) => Self::Vote(Some(vote)),
                RaftStateValue::Committed(committed) => Self::Committed(committed),
                RaftStateValue::StateMachineId(_) => self,
            },
            Self::LogMeta { key: _, value } => Self::Purged(Some(value.log_id())),

            RaftStoreEntry::DataHeader { .. }
            | RaftStoreEntry::Nodes { .. }
            | RaftStoreEntry::StateMachineMeta { .. }
            | RaftStoreEntry::Expire { .. }
            | RaftStoreEntry::GenericKV { .. }
            | RaftStoreEntry::Sequences { .. }
            | RaftStoreEntry::LogEntry(_)
            | RaftStoreEntry::NodeId(_)
            | RaftStoreEntry::Vote(_)
            | RaftStoreEntry::Committed(_)
            | RaftStoreEntry::Purged(_) => self,
        }
    }

    /// Serialize a key-value entry into a two elt vec of `Vec<u8>`: `[key, value]`.
    #[rustfmt::skip]
    pub fn serialize(kv: &RaftStoreEntry) -> Result<(IVec, IVec), io::Error> {

        match kv {
            Self::DataHeader       { key, value } => serialize_for_sled!(DataHeader,       key, value),
            Self::Logs             { key, value } => serialize_for_sled!(Logs,             key, value),
            Self::Nodes            { key, value } => serialize_for_sled!(Nodes,            key, value),
            Self::StateMachineMeta { key, value } => serialize_for_sled!(StateMachineMeta, key, value),
            Self::RaftStateKV      { key, value } => serialize_for_sled!(RaftStateKV,      key, value),
            Self::Expire           { key, value } => serialize_for_sled!(Expire,           key, value),
            Self::GenericKV        { key, value } => serialize_for_sled!(GenericKV,        key, value),
            Self::Sequences        { key, value } => serialize_for_sled!(Sequences,        key, value),
            Self::LogMeta          { key, value } => serialize_for_sled!(LogMeta,          key, value),

            RaftStoreEntry::LogEntry(_) |
            RaftStoreEntry::NodeId(_)|
            RaftStoreEntry::Vote(_) |
            RaftStoreEntry::Committed(_)|
            RaftStoreEntry::Purged(_) => {
                unreachable!("V004 entries should not be serialized for sled")
            }
        }
    }

    /// Deserialize a serialized key-value entry `[key, value]`.
    ///
    /// It is able to deserialize openraft-v7 or openraft-v8 key-value pairs.
    /// The compatibility is provided by [`SledSerde`] implementation for value types.
    pub fn deserialize(prefix_key: &[u8], vec_value: &[u8]) -> Result<Self, io::Error> {
        let (prefix, vec_key) = split_prefix(prefix_key)?;

        deserialize_by_prefix!(
            prefix,
            vec_key,
            vec_value,
            // Available key spaces:
            DataHeader,
            Logs,
            Nodes,
            StateMachineMeta,
            RaftStateKV,
            Expire,
            GenericKV,
            Sequences,
            LogMeta
        );

        Err(unknown_prefix(prefix))
    }

    pub fn new_header(header: Header) -> Self {
        RaftStoreEntry::DataHeader {
            key: Header::KEY.to_string(),
            value: SledHeader(header),
        }
    }
}

impl TryInto<SMEntry> for RaftStoreEntry {
    type Error = String;

    #[rustfmt::skip]
    fn try_into(self) -> Result<SMEntry, Self::Error> {
        match self {
            Self::DataHeader       { key, value } => Ok(SMEntry::DataHeader       { key, value }),
            Self::Nodes            { key, value } => Ok(SMEntry::Nodes            { key, value }),
            Self::StateMachineMeta { key, value } => Ok(SMEntry::StateMachineMeta { key, value }),
            Self::Expire           { key, value } => Ok(SMEntry::Expire           { key, value }),
            Self::GenericKV        { key, value } => Ok(SMEntry::GenericKV        { key, value }),
            Self::Sequences        { key, value } => Ok(SMEntry::Sequences        { key, value }),

            Self::Logs             { .. } => {Err("SMEntry does not contain Logs".to_string())},
            Self::RaftStateKV      { .. } => {Err("SMEntry does not contain RaftStateKV".to_string())}
            Self::LogMeta          { .. } => {Err("SMEntry does not contain LogMeta".to_string())}


            Self::LogEntry        (_) => {Err("SMEntry does not contain LogEntry".to_string())}
            Self::Vote            (_) => {Err("SMEntry does not contain Vote".to_string())}
            Self::NodeId          (_) => {Err("SMEntry does not contain NodeId".to_string())}
            Self::Committed       (_) => {Err("SMEntry does not contain Committed".to_string())}
            Self::Purged          (_) => {Err("SMEntry does not contain Purged".to_string())}

        }
    }
}

#[cfg(test)]
mod tests {
    use databend_meta_raft_config::data_version::DataVersion;
    use databend_meta_types::Endpoint;
    use databend_meta_types::raft_types::EntryPayload;
    use databend_meta_types::raft_types::new_log_id;
    use pretty_assertions::assert_eq;

    use super::*;
    use crate::sled_compat::StateMachineMetaValue;

    fn log_id() -> LogId {
        new_log_id(1, 2, 3)
    }

    fn header() -> Header {
        Header {
            version: DataVersion::V003,
            upgrading: Some(DataVersion::V004),
            cleaning: true,
        }
    }

    /// One entry per V003 sled key space, in key-space prefix order.
    fn all_raft_store_entries() -> Vec<(u8, RaftStoreEntry)> {
        vec![
            (Logs::PREFIX, RaftStoreEntry::Logs {
                key: 3,
                value: Entry {
                    log_id: log_id(),
                    payload: EntryPayload::Blank,
                },
            }),
            (Nodes::PREFIX, RaftStoreEntry::Nodes {
                key: 7,
                value: Node::new("7", Endpoint::new("7", 7)),
            }),
            (StateMachineMeta::PREFIX, RaftStoreEntry::StateMachineMeta {
                key: StateMachineMetaKey::LastApplied,
                value: StateMachineMetaValue::LogId(log_id()),
            }),
            (RaftStateKV::PREFIX, RaftStoreEntry::RaftStateKV {
                key: RaftStateKey::HardState,
                value: RaftStateValue::HardState(Vote::new(3, 1)),
            }),
            (Expire::PREFIX, RaftStoreEntry::Expire {
                key: ExpireKey::new(1000, 2),
                value: ExpireValue::new("a", 2),
            }),
            (GenericKV::PREFIX, RaftStoreEntry::GenericKV {
                key: "k".to_string(),
                value: SeqV::new(5, b"v".to_vec()),
            }),
            (Sequences::PREFIX, RaftStoreEntry::Sequences {
                key: "s".to_string(),
                value: SeqNum(9),
            }),
            (DataHeader::PREFIX, RaftStoreEntry::new_header(header())),
            (LogMeta::PREFIX, RaftStoreEntry::LogMeta {
                key: LogMetaKey::LastPurged,
                value: LogMetaValue::LogId(log_id()),
            }),
        ]
    }

    #[test]
    fn test_raft_store_entry_round_trip() -> anyhow::Result<()> {
        for (prefix, entry) in all_raft_store_entries() {
            let (k, v) = RaftStoreEntry::serialize(&entry)?;
            assert_eq!(k[0], prefix, "{:?} is stored under its own prefix", entry);

            let got = RaftStoreEntry::deserialize(&k, &v)?;
            assert_eq!(format!("{:?}", got), format!("{:?}", entry));
        }

        Ok(())
    }

    #[test]
    fn test_sm_entry_round_trip() -> anyhow::Result<()> {
        for (_prefix, entry) in all_raft_store_entries() {
            let Ok(sm_entry): Result<SMEntry, _> = entry.clone().try_into() else {
                continue;
            };

            let (k, v) = SMEntry::serialize(&sm_entry)?;
            let got = SMEntry::deserialize(&k, &v)?;
            assert_eq!(format!("{:?}", got), format!("{:?}", sm_entry));
        }

        Ok(())
    }

    #[test]
    fn test_try_into_sm_entry_rejects_log_only_key_spaces() {
        let rejected = all_raft_store_entries()
            .into_iter()
            .chain([
                (
                    0,
                    RaftStoreEntry::LogEntry(Entry {
                        log_id: log_id(),
                        payload: EntryPayload::Blank,
                    }),
                ),
                (0, RaftStoreEntry::NodeId(Some(7))),
                (0, RaftStoreEntry::Vote(Some(Vote::new(3, 1)))),
                (0, RaftStoreEntry::Committed(Some(log_id()))),
                (0, RaftStoreEntry::Purged(Some(log_id()))),
            ])
            .filter_map(|(_, e)| TryInto::<SMEntry>::try_into(e).err())
            .collect::<Vec<_>>();

        assert_eq!(rejected, vec![
            "SMEntry does not contain Logs",
            "SMEntry does not contain RaftStateKV",
            "SMEntry does not contain LogMeta",
            "SMEntry does not contain LogEntry",
            "SMEntry does not contain NodeId",
            "SMEntry does not contain Vote",
            "SMEntry does not contain Committed",
            "SMEntry does not contain Purged",
        ]);
    }

    #[test]
    fn test_upgrade_maps_v003_entries_to_v004() {
        let upgraded = all_raft_store_entries()
            .into_iter()
            .map(|(_, e)| format!("{:?}", e.upgrade()))
            .collect::<Vec<_>>();

        assert_eq!(upgraded, vec![
            // Logs become plain log entries.
            format!(
                "{:?}",
                RaftStoreEntry::LogEntry(Entry {
                    log_id: log_id(),
                    payload: EntryPayload::Blank
                })
            ),
            // Key spaces owned by the state machine are unchanged.
            format!("{:?}", RaftStoreEntry::Nodes {
                key: 7,
                value: Node::new("7", Endpoint::new("7", 7))
            }),
            format!("{:?}", RaftStoreEntry::StateMachineMeta {
                key: StateMachineMetaKey::LastApplied,
                value: StateMachineMetaValue::LogId(log_id())
            }),
            // Raft state is split into its V004 counterparts.
            format!("{:?}", RaftStoreEntry::Vote(Some(Vote::new(3, 1)))),
            format!("{:?}", RaftStoreEntry::Expire {
                key: ExpireKey::new(1000, 2),
                value: ExpireValue::new("a", 2)
            }),
            format!("{:?}", RaftStoreEntry::GenericKV {
                key: "k".to_string(),
                value: SeqV::new(5, b"v".to_vec())
            }),
            format!("{:?}", RaftStoreEntry::Sequences {
                key: "s".to_string(),
                value: SeqNum(9)
            }),
            format!("{:?}", RaftStoreEntry::new_header(header())),
            // The purged marker becomes the V004 purged log id.
            format!("{:?}", RaftStoreEntry::Purged(Some(log_id()))),
        ]);
    }

    #[test]
    fn test_upgrade_maps_the_remaining_raft_state_keys() {
        let node_id = RaftStoreEntry::RaftStateKV {
            key: RaftStateKey::Id,
            value: RaftStateValue::NodeId(7),
        };
        assert_eq!(
            format!("{:?}", node_id.upgrade()),
            format!("{:?}", RaftStoreEntry::NodeId(Some(7)))
        );

        let committed = RaftStoreEntry::RaftStateKV {
            key: RaftStateKey::Committed,
            value: RaftStateValue::Committed(Some(log_id())),
        };
        assert_eq!(
            format!("{:?}", committed.upgrade()),
            format!("{:?}", RaftStoreEntry::Committed(Some(log_id())))
        );

        // `StateMachineId` has no V004 counterpart and stays as it is.
        let sm_id = RaftStoreEntry::RaftStateKV {
            key: RaftStateKey::StateMachineId,
            value: RaftStateValue::StateMachineId((1, 2)),
        };
        assert_eq!(
            format!("{:?}", sm_id.clone().upgrade()),
            format!("{:?}", sm_id)
        );
    }

    #[test]
    fn test_sm_entry_last_applied() {
        let last_applied = SMEntry::StateMachineMeta {
            key: StateMachineMetaKey::LastApplied,
            value: StateMachineMetaValue::LogId(log_id()),
        };
        assert_eq!(last_applied.last_applied(), Some(log_id()));

        let other_meta = SMEntry::StateMachineMeta {
            key: StateMachineMetaKey::Initialized,
            value: StateMachineMetaValue::Bool(true),
        };
        assert_eq!(other_meta.last_applied(), None);

        let not_meta = SMEntry::Sequences {
            key: "s".to_string(),
            value: SeqNum(9),
        };
        assert_eq!(not_meta.last_applied(), None);
    }

    /// On-disk bytes may be truncated or come from a removed key space; both
    /// must be reported rather than panic.
    #[test]
    fn test_deserialize_rejects_malformed_keys() {
        for got in [
            RaftStoreEntry::deserialize(&[], b"").unwrap_err(),
            SMEntry::deserialize(&[], b"").unwrap_err(),
        ] {
            assert_eq!(got.kind(), io::ErrorKind::InvalidData);
            assert_eq!(got.to_string(), "empty sled key: no key space prefix");
        }

        // 10 was `ClientLastResps`, removed from both enums.
        for got in [
            RaftStoreEntry::deserialize(&[10, 0], b"").unwrap_err(),
            SMEntry::deserialize(&[10, 0], b"").unwrap_err(),
        ] {
            assert_eq!(got.kind(), io::ErrorKind::InvalidData);
            assert_eq!(got.to_string(), "unknown key space prefix: 10");
        }

        // The prefix is known but the value is not decodable.
        let err = RaftStoreEntry::deserialize(&[Sequences::PREFIX, b's'], b"not-json").unwrap_err();
        let expected = sled_bytes_err(<SeqNum as SledSerde>::de(b"not-json").unwrap_err());
        assert_eq!(err.to_string(), expected.to_string());
    }
}
