// Copyright 2021 Datafuse Labs
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

//! The persisted layer of the state machine data.

use std::future;
use std::io;

use databend_meta_snapshot_db::DB;
use databend_meta_snapshot_db::ReadAtSeqDB;
use databend_meta_types::SeqNum;
use databend_meta_types::SeqV;
use futures_util::StreamExt;
use futures_util::TryStreamExt;
use log::info;
use map_api::IOResultStream;
use state_machine_api::ExpireKey;
use state_machine_api::ExpireValue;
use state_machine_api::UserKey;

use crate::sled_compat::StateMachineMetaKey;
use crate::sled_compat::StateMachineMetaValue;
use crate::sled_compat::key_spaces::SMEntry;

/// Export DB data to a stream of [`SMEntry`].
pub struct DBExporter<'a> {
    db: &'a DB,
}

impl<'a> DBExporter<'a> {
    pub fn new(db: &'a DB) -> Self {
        Self { db }
    }

    /// Convert sys data to a series of [`SMEntry`] for export.
    pub fn sys_data_sm_entries(&self) -> Result<Vec<SMEntry>, io::Error> {
        let sys_data = &self.db.sys_data;

        let last_applied = *sys_data.last_applied_ref();
        let last_membership = sys_data.last_membership_ref().clone();

        let mut res = Vec::with_capacity(3 + sys_data.nodes_ref().len());

        res.push(SMEntry::Sequences {
            key: "generic-kv".to_string(),
            value: SeqNum(sys_data.curr_seq()),
        });

        if let Some(last_applied) = last_applied {
            res.push(SMEntry::StateMachineMeta {
                key: StateMachineMetaKey::LastApplied,
                value: StateMachineMetaValue::LogId(last_applied),
            });
        }

        res.push(SMEntry::StateMachineMeta {
            key: StateMachineMetaKey::LastMembership,
            value: StateMachineMetaValue::Membership(last_membership),
        });

        for (nid, n) in sys_data.nodes_ref().iter() {
            res.push(SMEntry::Nodes {
                key: *nid,
                value: n.clone(),
            });
        }

        Ok(res)
    }

    /// Export all data in a stream of [`SMEntry`], ignore tombstone.
    ///
    /// First several lines are system data,
    /// including `seq`, `last_applied_log_id`, `last_applied_membership`, and `nodes`.
    ///
    /// The second parts are all the key values, in alphabetical order,
    /// ExpireKeys(`exp-/`) then Generic KV(`kv--/`);
    pub async fn export(&self) -> Result<IOResultStream<SMEntry>, io::Error> {
        let sys_entries = self.sys_data_sm_entries()?;
        info!("DBExporter::export sys_data entries: {:?}", sys_entries);

        // expire index

        let strm = ReadAtSeqDB(self.db)
            .range_at_seq(ExpireKey::default().., u64::MAX)
            .await?;
        let expire_strm = strm.try_filter_map(|(exp_k, marked)| {
            // Tombstone will be converted to None and be ignored.
            let exp_val = ExpireValue::from_marked(marked);
            let ent = exp_val.map(|value| SMEntry::Expire { key: exp_k, value });
            future::ready(Ok(ent))
        });

        // kv

        let strm = ReadAtSeqDB(self.db)
            .range_at_seq(UserKey::default().., u64::MAX)
            .await?;
        let kv_strm = strm.try_filter_map(|(user_key, seq_marked)| {
            // Tombstone will be converted to None and be ignored.
            let seqv: Option<SeqV<_>> = seq_marked.into();
            let ent = seqv.map(|value| SMEntry::GenericKV {
                key: user_key.to_string(),
                value,
            });
            future::ready(Ok(ent))
        });

        let strm = futures::stream::iter(sys_entries)
            .map(Ok)
            .chain(expire_strm)
            .chain(kv_strm);

        Ok(strm.boxed())
    }

    /// Export all user keys in a stream of `String`, ignore tombstone.
    pub async fn export_user_keys(&self) -> Result<IOResultStream<String>, io::Error> {
        let strm = ReadAtSeqDB(self.db)
            .range_at_seq(UserKey::default().., u64::MAX)
            .await?;
        // TODO: ignore tombstone, currently db does not include tombstone keys
        let user_key_strm = strm.map_ok(|(user_key, _)| user_key.key);

        Ok(user_key_strm.boxed())
    }
}

#[cfg(test)]
mod tests {
    use databend_meta_leveled_store::db_builder::DBBuilder;
    use databend_meta_leveled_store::leveled_map::LeveledMap;
    use databend_meta_snapshot_db::DB;
    use databend_meta_types::SeqV;
    use futures_util::TryStreamExt;
    use map_api::mvcc::ViewSet;
    use rotbl::v001::Config;
    use state_machine_api::ExpireKey;
    use state_machine_api::ExpireValue;
    use state_machine_api::UserKey;

    use super::*;
    use crate::sled_compat::StateMachineMetaKey;
    use crate::sled_compat::StateMachineMetaValue;

    async fn build_db() -> anyhow::Result<(tempfile::TempDir, DB)> {
        let temp_dir = tempfile::tempdir()?;
        let mut map = LeveledMap::default();
        let mut view = map.to_view();
        view.set(UserKey::new("user"), Some((None, b"value".to_vec())));
        view.set(ExpireKey::new(100, 1), Some("user".to_string()));
        view.set(UserKey::new("deleted"), Some((None, b"deleted".to_vec())));
        view.set(UserKey::new("deleted"), None);
        view.commit().await?;

        let builder = DBBuilder::new(temp_dir.path(), "snapshot", Config::default())?;
        let db = builder
            .build_from_leveled_map(&mut map, |_| "---1".to_string())
            .await?;
        Ok((temp_dir, db))
    }

    #[tokio::test]
    async fn test_export_preserves_system_data_and_skips_tombstones() -> anyhow::Result<()> {
        let (_temp_dir, db) = build_db().await?;
        let exporter = DBExporter::new(&db);

        let sys_entries = exporter.sys_data_sm_entries()?;
        assert_eq!(sys_entries.len(), 2);
        match (&sys_entries[0], &sys_entries[1]) {
            (
                SMEntry::Sequences { key, value },
                SMEntry::StateMachineMeta {
                    key: membership_key,
                    value: membership,
                },
            ) => {
                assert_eq!(key, "generic-kv");
                assert_eq!(value.0, 2);
                assert_eq!(*membership_key, StateMachineMetaKey::LastMembership);
                assert_eq!(
                    *membership,
                    StateMachineMetaValue::Membership(db.sys_data.last_membership_ref().clone())
                );
            }
            entries => panic!("unexpected system entries: {entries:?}"),
        }

        let entries = exporter.export().await?.try_collect::<Vec<_>>().await?;
        assert_eq!(entries.len(), 4);
        match (&entries[2], &entries[3]) {
            (
                SMEntry::Expire { key, value },
                SMEntry::GenericKV {
                    key: user_key,
                    value: user_value,
                },
            ) => {
                assert_eq!(*key, ExpireKey::new(100, 1));
                assert_eq!(*value, ExpireValue::new("user", 1));
                assert_eq!(user_key, "user");
                assert_eq!(*user_value, SeqV::new(1, b"value".to_vec()));
            }
            entries => panic!("unexpected data entries: {entries:?}"),
        }

        let user_keys = exporter
            .export_user_keys()
            .await?
            .try_collect::<Vec<_>>()
            .await?;
        assert_eq!(user_keys, vec!["user"]);
        Ok(())
    }
}
