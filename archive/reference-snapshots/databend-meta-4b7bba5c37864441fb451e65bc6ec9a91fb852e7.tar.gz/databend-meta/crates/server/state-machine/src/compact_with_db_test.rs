// Copyright 2021 Datafuse Labs
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use databend_meta_leveled_store::leveled_map::LeveledMap;
use databend_meta_leveled_store::sys_data_api::SysDataApiRO;
use databend_meta_leveled_store::testing_data::build_3_levels_leveled_map;
use databend_meta_leveled_store::testing_data::build_db_from;
use databend_meta_leveled_store::testing_data::move_bottom_to_db;
use databend_meta_snapshot_db::ReadAtSeqDB;
use databend_meta_types::Endpoint;
use databend_meta_types::UpsertKV;
use databend_meta_types::node::Node;
use databend_meta_types::raft_types::Membership;
use databend_meta_types::raft_types::StoredMembership;
use databend_meta_types::raft_types::TypeConfig;
use futures_util::TryStreamExt;
use map_api::mvcc::GetAtSeq;
use map_api::mvcc::RangeAtSeq;
use maplit::btreemap;
use openraft::testing::log_id;
use pretty_assertions::assert_eq;
use seq_marked::SeqMarked;
use state_machine_api::ExpireKey;
use state_machine_api::KVMeta;
use state_machine_api::UserKey;

use crate::state_machine::StateMachine;

#[tokio::test(flavor = "multi_thread", worker_threads = 3)]
async fn test_leveled_query_with_db() -> anyhow::Result<()> {
    let (lm, _g) = build_3_levels().await?;

    assert_eq!(lm.curr_seq(), 7);
    assert_eq!(
        lm.last_membership(),
        StoredMembership::new(
            Some(log_id::<TypeConfig>(3, 3, 3)),
            Membership::new_with_defaults(vec![], [])
        )
    );
    assert_eq!(lm.last_applied(), Some(log_id::<TypeConfig>(3, 3, 3)));
    assert_eq!(
        lm.nodes(),
        btreemap! {3=>Node::new("3", Endpoint::new("3", 3))}
    );

    let strm = lm.range_at_seq(user_key("").., u64::MAX).await?;
    let got = strm.try_collect::<Vec<_>>().await?;
    assert_eq!(got, vec![
        //
        (user_key("a"), SeqMarked::new_normal(1, (None, b("a0")))),
        (user_key("b"), SeqMarked::new_tombstone(4)),
        (user_key("c"), SeqMarked::new_tombstone(6)),
        (user_key("d"), SeqMarked::new_normal(7, (None, b("d2")))),
        (user_key("e"), SeqMarked::new_normal(6, (None, b("e1")))),
    ]);

    assert_eq!(
        lm.get_at_seq(user_key("a"), u64::MAX).await?,
        SeqMarked::new_normal(1, (None, b("a0")))
    );
    assert_eq!(
        lm.get_at_seq(user_key("b"), u64::MAX).await?,
        SeqMarked::new_tombstone(4)
    );

    let strm = lm.range_at_seq(ExpireKey::default().., u64::MAX).await?;
    let got = strm.try_collect::<Vec<_>>().await?;
    assert_eq!(got, vec![]);

    Ok(())
}

#[tokio::test(flavor = "multi_thread", worker_threads = 3)]
async fn test_leveled_query_with_expire_index() -> anyhow::Result<()> {
    let (sm, _g) = build_sm_with_expire().await?;

    let lm = sm.into_leveled_map();

    assert_eq!(lm.curr_seq(), 4);
    assert_eq!(
        lm.last_membership(),
        StoredMembership::new(None, Membership::new_with_defaults(vec![], []))
    );
    assert_eq!(lm.last_applied(), None);
    assert_eq!(lm.nodes(), btreemap! {});

    let strm = lm.range_at_seq(user_key("").., u64::MAX).await?;
    let got = strm.try_collect::<Vec<_>>().await?;
    assert_eq!(got, vec![
        //
        (
            user_key("a"),
            SeqMarked::new_normal(4, (Some(KVMeta::new(Some(15), Some(0))), b("a1")))
        ),
        (
            user_key("b"),
            SeqMarked::new_normal(2, (Some(KVMeta::new(Some(5), Some(0))), b("b0")))
        ),
        (
            user_key("c"),
            SeqMarked::new_normal(3, (Some(KVMeta::new(Some(20), Some(0))), b("c0")))
        ),
    ]);

    let strm = lm.range_at_seq(ExpireKey::default().., u64::MAX).await?;
    let got = strm.try_collect::<Vec<_>>().await?;
    assert_eq!(got, vec![
        //
        (ExpireKey::new(5_000, 2), SeqMarked::new_normal(2, s("b"))),
        (ExpireKey::new(10_000, 1), SeqMarked::new_tombstone(4)),
        (ExpireKey::new(15_000, 4), SeqMarked::new_normal(4, s("a"))),
        (ExpireKey::new(20_000, 3), SeqMarked::new_normal(3, s("c"))),
    ]);

    Ok(())
}

#[tokio::test(flavor = "multi_thread", worker_threads = 3)]
async fn test_compact() -> anyhow::Result<()> {
    let (mut lm, _g) = build_3_levels().await?;
    lm.freeze_writable_without_permit();

    let temp_dir = tempfile::tempdir()?;
    let path = temp_dir.path();
    build_db_from(
        &mut lm,
        path.as_os_str().to_str().unwrap(),
        "temp-compacted",
    )
    .await?;

    let db = lm.persisted().unwrap();

    assert_eq!(db.curr_seq(), 7);
    assert_eq!(
        db.last_membership_ref(),
        &StoredMembership::new(
            Some(log_id::<TypeConfig>(3, 3, 3)),
            Membership::new_with_defaults(vec![], [])
        )
    );
    assert_eq!(db.last_applied_ref(), &Some(log_id::<TypeConfig>(3, 3, 3)));
    assert_eq!(
        db.nodes_ref(),
        &btreemap! {3=>Node::new("3", Endpoint::new("3", 3))}
    );

    let strm = ReadAtSeqDB(&db)
        .range_at_seq(user_key("").., u64::MAX)
        .await?;
    let got = strm.try_collect::<Vec<_>>().await?;
    assert_eq!(got, vec![
        //
        (user_key("a"), SeqMarked::new_normal(1, (None, b("a0")))),
        (user_key("d"), SeqMarked::new_normal(7, (None, b("d2")))),
        (user_key("e"), SeqMarked::new_normal(6, (None, b("e1")))),
    ]);

    let strm = ReadAtSeqDB(&db)
        .range_at_seq(ExpireKey::default().., u64::MAX)
        .await?;
    let got = strm.try_collect::<Vec<_>>().await?;
    assert_eq!(got, vec![]);

    Ok(())
}

#[tokio::test(flavor = "multi_thread", worker_threads = 3)]
async fn test_compact_expire_index() -> anyhow::Result<()> {
    let (sm, _g) = build_sm_with_expire().await?;
    {
        let compactor = sm.freeze_writable_for_compaction("").await;
        drop(compactor);
    }

    let mut lm = sm.into_leveled_map();

    let temp_dir = tempfile::tempdir()?;
    let path = temp_dir.path();
    build_db_from(
        &mut lm,
        path.as_os_str().to_str().unwrap(),
        "temp-compacted",
    )
    .await?;

    let db = lm.persisted().unwrap();

    assert_eq!(db.curr_seq(), 4);
    assert_eq!(
        db.last_membership_ref(),
        &StoredMembership::new(None, Membership::new_with_defaults(vec![], []))
    );
    assert_eq!(db.last_applied_ref(), &None);
    assert_eq!(db.nodes_ref(), &btreemap! {});

    let strm = ReadAtSeqDB(&db)
        .range_at_seq(UserKey::default().., u64::MAX)
        .await?;
    let got = strm.try_collect::<Vec<_>>().await?;
    assert_eq!(got, vec![
        //
        (
            user_key("a"),
            SeqMarked::new_normal(4, (Some(KVMeta::new(Some(15), Some(0))), b("a1")))
        ),
        (
            user_key("b"),
            SeqMarked::new_normal(2, (Some(KVMeta::new(Some(5), Some(0))), b("b0")))
        ),
        (
            user_key("c"),
            SeqMarked::new_normal(3, (Some(KVMeta::new(Some(20), Some(0))), b("c0")))
        ),
    ]);

    let strm = ReadAtSeqDB(&db)
        .range_at_seq(ExpireKey::default().., u64::MAX)
        .await?;
    let got = strm.try_collect::<Vec<_>>().await?;
    assert_eq!(got, vec![
        //
        (ExpireKey::new(5_000, 2), SeqMarked::new_normal(2, s("b"))),
        (ExpireKey::new(15_000, 4), SeqMarked::new_normal(4, s("a"))),
        (ExpireKey::new(20_000, 3), SeqMarked::new_normal(3, s("c"))),
    ]);

    Ok(())
}

#[tokio::test(flavor = "multi_thread", worker_threads = 3)]
async fn test_compact_output_3_level() -> anyhow::Result<()> {
    let (lm, _g) = build_3_levels().await?;
    lm.freeze_writable_without_permit();

    let immutable_data = lm.immutable_data();

    let (sys_data, strm) = immutable_data.compact_into_stream().await?;

    assert_eq!(sys_data.curr_seq(), 7);
    assert_eq!(
        sys_data.last_membership_ref(),
        &StoredMembership::new(
            Some(log_id::<TypeConfig>(3, 3, 3)),
            Membership::new_with_defaults(vec![], [])
        )
    );
    assert_eq!(
        sys_data.last_applied_ref(),
        &Some(log_id::<TypeConfig>(3, 3, 3))
    );
    assert_eq!(
        sys_data.nodes_ref(),
        &btreemap! {3=>Node::new("3", Endpoint::new("3", 3))}
    );

    let got = strm
        .map_ok(|x| serde_json::to_string(&x).unwrap())
        .try_collect::<Vec<_>>()
        .await?;

    assert_eq!(got, vec![
        r#"["kv--/a",{"seq":1,"marked":{"Normal":[1,4,110,117,108,108,2,97,48]}}]"#,
        r#"["kv--/d",{"seq":7,"marked":{"Normal":[1,4,110,117,108,108,2,100,50]}}]"#,
        r#"["kv--/e",{"seq":6,"marked":{"Normal":[1,4,110,117,108,108,2,101,49]}}]"#,
    ]);

    Ok(())
}

async fn build_3_levels() -> anyhow::Result<(LeveledMap, impl Drop)> {
    let mut lm = build_3_levels_leveled_map().await?;

    // Move the bottom level to db
    let temp_dir = tempfile::tempdir()?;
    let path = temp_dir.path();
    move_bottom_to_db(&mut lm, path.to_str().unwrap(), "temp-db").await?;

    Ok((lm, temp_dir))
}

/// The subscript is internal_seq:
///
///    | kv             | expire
///    | ---            | ---
/// l1 | aâ       câ    |               10,1â -> Ã¸    15,4â -> a  20,3â -> c
/// l0 | aâ  bâ         |  5,2â -> b    10,1â -> a
async fn build_sm_with_expire() -> anyhow::Result<(StateMachine, impl Drop)> {
    let mut sm = StateMachine::default();

    let mut a = sm.new_applier().await;
    a.upsert_kv(&UpsertKV::update("a", b"a0").with_expire_sec(10))
        .await?;
    a.upsert_kv(&UpsertKV::update("b", b"b0").with_expire_sec(5))
        .await?;
    a.commit().await?;

    sm.map_mut().freeze_writable_without_permit();

    let mut a = sm.new_applier().await;
    a.upsert_kv(&UpsertKV::update("c", b"c0").with_expire_sec(20))
        .await?;
    a.upsert_kv(&UpsertKV::update("a", b"a1").with_expire_sec(15))
        .await?;

    a.commit().await?;

    let lm = sm.levels_mut();

    let temp_dir = tempfile::tempdir()?;
    let path = temp_dir.path();
    move_bottom_to_db(lm, path.to_str().unwrap(), "temp-db").await?;
    Ok((sm, temp_dir))
}

fn s(x: impl ToString) -> String {
    x.to_string()
}

fn b(x: impl ToString) -> Vec<u8> {
    x.to_string().as_bytes().to_vec()
}

fn user_key(s: impl ToString) -> UserKey {
    UserKey::new(s)
}
