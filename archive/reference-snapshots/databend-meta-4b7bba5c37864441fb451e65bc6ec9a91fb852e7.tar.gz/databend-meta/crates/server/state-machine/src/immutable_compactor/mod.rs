// Copyright 2021 Datafuse Labs
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use std::fmt;
use std::sync::Arc;

use databend_meta_leveled_store::leveled_map::CompactorPermit;
use databend_meta_leveled_store::leveled_map::LeveledMap;
use databend_meta_leveled_store::leveled_map::WriterPermit;
use display_more::DisplaySliceExt;
use log::info;

use crate::state_machine::StateMachine;

#[cfg(test)]
mod immutable_compactor_test;

/// Compact `ImmutableLevels` to reduce the number of levels.
pub struct InMemoryCompactor {
    writer_permit: WriterPermit,
    immutable_compactor: ImmutableCompactor,
}

impl fmt::Display for InMemoryCompactor {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "InMemoryCompactor({})", self.name())
    }
}

impl InMemoryCompactor {
    pub async fn new(sm: Arc<StateMachine>, name: impl ToString) -> Self {
        let name = name.to_string();

        let (compactor_permit, writer_permit) =
            sm.acquire_compaction_and_writer(name.clone()).await;

        Self {
            writer_permit,
            immutable_compactor: ImmutableCompactor::new(
                sm.leveled_map().clone(),
                compactor_permit,
                name,
            ),
        }
    }

    /// Move the writable level to immutable levels,
    /// and return the `ImmutableCompactor` to do the further compaction of immutable levels.
    pub fn freeze(mut self) -> ImmutableCompactor {
        let leveled_map = self.leveled_map().clone();

        let writable_stat = leveled_map.writable_stat();

        leveled_map.freeze_writable(
            &mut self.writer_permit,
            &mut self.immutable_compactor.compactor_permit,
        );

        let immutable_stat = leveled_map.immutable_levels().stat();

        info!(
            "{} DONE freeze writable: {}; immutables: {}",
            self,
            writable_stat,
            immutable_stat.display_n(64)
        );

        self.immutable_compactor
    }

    pub fn leveled_map(&self) -> &LeveledMap {
        &self.immutable_compactor.leveled_map
    }

    pub(crate) fn name(&self) -> &str {
        &self.immutable_compactor.name
    }
}

pub struct ImmutableCompactor {
    name: String,
    compactor_permit: CompactorPermit,
    leveled_map: LeveledMap,
}

impl fmt::Display for ImmutableCompactor {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "ImmutableCompactor({})", self.name())
    }
}

impl ImmutableCompactor {
    pub(crate) fn new(
        leveled_map: LeveledMap,
        compactor_permit: CompactorPermit,
        name: impl ToString,
    ) -> Self {
        Self {
            name: name.to_string(),
            leveled_map,
            compactor_permit,
        }
    }

    pub fn name(&self) -> &str {
        &self.name
    }

    /// Wait until no active read predates the immutable data, then compact it.
    pub async fn compact(self) {
        let immutable_levels = self.leveled_map.immutable_levels();

        let old_stat = immutable_levels.stat();

        info!(
            "{} Start compact immutables: {}",
            self,
            old_stat.display_n(64)
        );

        if let Err(e) = immutable_levels.need_compact() {
            info!("{} Skip compact immutables because: {}", self, e);
            return;
        }

        self.leveled_map
            .wait_for_active_reads_before_compaction()
            .await;

        let new_immutable_levels = immutable_levels.compact_min_adjacent();

        let old_stat = immutable_levels.stat();
        let new_stat = new_immutable_levels.stat();

        if old_stat == new_stat {
            info!(
                "{} Done compact immutables: No compaction: {}",
                self,
                old_stat.display_n(64),
            );
            return;
        } else {
            for i in 0..new_stat.len() {
                let old = &old_stat[i];
                let new = &new_stat[i];

                if old.level_index != new.level_index {
                    info!(
                        "{} Done compact {} = {} + {}, final: {}",
                        self,
                        &new_stat[i - 1],
                        &old_stat[i - 1],
                        &old_stat[i],
                        new_stat.display_n(64)
                    );
                    break;
                }
            }
        }

        self.leveled_map
            .replace_immutable_levels(new_immutable_levels);
    }
}
