// Copyright 2021 Datafuse Labs
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

//! The replicated state machine.
//!
//! Applies raft log entries to a [`LeveledMap`](databend_meta_leveled_store),
//! serves reads from it, and compacts it in the background. It exchanges
//! snapshot `DB`s with the snapshot store but does not know how those files are
//! written or shipped.

#![allow(clippy::uninlined_format_args)]
#![feature(impl_trait_in_assoc_type)]
#![allow(clippy::diverging_sub_expression)]
#![allow(clippy::let_and_return)]
#![allow(clippy::collapsible_if)]

pub mod applier;
pub mod immutable_compactor;
mod kv_api;
pub mod state_machine;
pub mod state_machine_api_ext;
pub mod store;
pub mod utils;

mod impl_raft_state_machine;

#[cfg(test)]
mod acquire_compactor_test;
#[cfg(test)]
mod compact_with_db_test;
#[cfg(test)]
pub(crate) mod state_machine_test;

pub use state_machine::StateMachine;
pub use store::RaftStateMachineStore;
