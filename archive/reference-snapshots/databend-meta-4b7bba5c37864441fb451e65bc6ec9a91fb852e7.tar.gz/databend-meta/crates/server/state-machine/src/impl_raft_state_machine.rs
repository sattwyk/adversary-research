// Copyright 2021 Datafuse Labs
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use std::io;

use databend_meta_metrics::raft_metrics;
use databend_meta_runtime_api::SpawnApi;
use databend_meta_snapshot_db::DB;
use databend_meta_snapshot_db::Snapshot;
use databend_meta_snapshot_store::SnapshotStore;
use databend_meta_snapshot_store::open_snapshot::OpenSnapshot;
use databend_meta_types::raft_types::LogId;
use databend_meta_types::raft_types::SnapshotMeta;
use databend_meta_types::raft_types::StoredMembership;
use databend_meta_types::raft_types::TypeConfig;
use futures::Stream;
use log::debug;
use log::error;
use log::info;
use openraft::OptionalSend;
use openraft::RaftSnapshotBuilder;
use openraft::storage::EntryResponder;
use openraft::storage::RaftStateMachine;

use crate::store::RaftStateMachineStore;

impl<SP: SpawnApi> RaftSnapshotBuilder<TypeConfig> for RaftStateMachineStore<SP> {
    type SnapshotData = DB;

    #[fastrace::trace]
    async fn build_snapshot(&mut self) -> Result<Snapshot, io::Error> {
        self.do_build_snapshot().await
    }
}

impl<SP: SpawnApi> RaftStateMachine<TypeConfig> for RaftStateMachineStore<SP> {
    type SnapshotData = DB;
    type SnapshotBuilder = RaftStateMachineStore<SP>;

    async fn applied_state(&mut self) -> Result<(Option<LogId>, StoredMembership), io::Error> {
        let sm = self.get_inner();
        let last_applied = *sm.sys_data().last_applied_ref();
        let last_membership = sm.sys_data().last_membership_ref().clone();

        debug!(
            "applied_state: applied: {:?}, membership: {:?}",
            last_applied, last_membership
        );

        Ok((last_applied, last_membership))
    }

    #[fastrace::trace]
    async fn apply<Strm>(&mut self, entries: Strm) -> Result<(), io::Error>
    where Strm: Stream<Item = Result<EntryResponder<TypeConfig>, io::Error>> + Unpin + OptionalSend
    {
        self.get_inner().apply_entries(entries).await
    }

    async fn get_snapshot_builder(&mut self) -> Self::SnapshotBuilder {
        self.clone()
    }

    // This method is not used
    #[allow(clippy::diverging_sub_expression)]
    #[fastrace::trace]
    async fn begin_receiving_snapshot(&mut self) -> Result<DB, io::Error> {
        unreachable!(
            "begin_receiving_snapshot is only required when using OpenRaft Chunked snapshot transmit"
        );
    }

    #[fastrace::trace]
    async fn install_snapshot(
        &mut self,
        meta: &SnapshotMeta,
        snapshot: DB,
    ) -> Result<(), io::Error> {
        let data_size = snapshot.file_size();

        info!(
            id = self.id,
            snapshot_size = data_size;
            "decoding snapshot for installation"
        );

        let ss_store: SnapshotStore<SP> = SnapshotStore::new(self.config.as_ref().clone());
        let (storage_path, rel_path) = ss_store
            .snapshot_config()
            .move_to_final_path(&snapshot.path(), meta.snapshot_id.clone())?;

        let db = DB::open_snapshot(
            storage_path,
            rel_path,
            meta.snapshot_id.clone(),
            self.config.to_rotbl_config(),
        )?;

        info!("snapshot meta: {:?}", meta);

        // Replace state machine with the new one
        let res = self.do_install_snapshot(db).await;
        match res {
            Ok(_) => {}
            Err(e) => {
                raft_metrics::storage::incr_raft_storage_fail("install_snapshot", true);
                error!("error: {:?} when install_snapshot", e);
            }
        };

        Ok(())
    }

    #[fastrace::trace]
    async fn get_current_snapshot(&mut self) -> Result<Option<Snapshot>, io::Error> {
        info!(id = self.id; "get snapshot start");

        let r = self.get_inner();
        let db = r.leveled_map().persisted();

        let snapshot = db.map(|x| Snapshot {
            meta: x.snapshot_meta().clone(),
            snapshot: x,
        });

        info!(
            "get snapshot complete: {:?}",
            snapshot.as_ref().map(|x| &x.meta)
        );
        Ok(snapshot)
    }
}
