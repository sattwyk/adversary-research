// Copyright 2021 Datafuse Labs
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use std::marker::PhantomData;
use std::sync::Arc;
use std::time::Duration;

use anyerror::AnyError;
use databend_meta_raft_config::Secret;
use databend_meta_runtime_api::ChannelError;
use databend_meta_runtime_api::SpawnApi;
use databend_meta_runtime_api::TlsConfig;
use log::debug;
use once_cell::sync::OnceCell;
use parking_lot::Mutex;
use tonic::async_trait;
use tonic::transport::Channel;

use crate::endpoints::Endpoints;
use crate::established_client::EstablishedClient;
use crate::grpc_client::AuthInterceptor;
use crate::grpc_client::RealClient;
use crate::grpc_client::handshake;
use crate::pool::ItemManager;
use crate::types::ConnectionError;
use crate::types::MetaClientError;
use crate::types::MetaNetworkError;
use crate::types::pb::meta_service_client::MetaServiceClient;

pub const DEFAULT_GRPC_MESSAGE_SIZE: usize = 32 * 1024 * 1024;

/// Default connection TTL: 20 seconds.
///
/// This prevents h2 stream reset accumulation that can lead to
/// `too_many_internal_resets` errors (ENHANCE_YOUR_CALM).
/// The h2 library has a default limit of 1024 locally-reset streams
/// per connection. By refreshing connections periodically, we prevent
/// hitting this limit.
pub const DEFAULT_CONNECTION_TTL: Duration = Duration::from_secs(20);

#[derive(Debug)]
pub struct MetaChannelManager<R> {
    username: String,
    password: Secret,
    timeout: Option<Duration>,
    tls_config: Option<TlsConfig>,

    /// The endpoints of the meta-service cluster.
    ///
    /// The endpoints will be added to a built client item
    /// and will be updated when a error or successful response is received.
    endpoints: Arc<Mutex<Endpoints>>,

    /// Maximum time a connection can live before being refreshed.
    ///
    /// This prevents h2 stream reset accumulation that can lead to
    /// `too_many_internal_resets` errors.
    connection_ttl: Duration,

    grpc_max_message_size: usize,

    _phantom: PhantomData<R>,
}

impl<R: SpawnApi> MetaChannelManager<R> {
    pub fn new(
        username: impl ToString,
        password: impl ToString,
        timeout: Option<Duration>,
        tls_config: Option<TlsConfig>,
        endpoints: Arc<Mutex<Endpoints>>,
        connection_ttl: Option<Duration>,
        grpc_max_message_size: usize,
    ) -> Self {
        Self {
            username: username.to_string(),
            password: Secret::new(password.to_string()),
            timeout,
            tls_config,
            endpoints,
            connection_ttl: connection_ttl.unwrap_or(DEFAULT_CONNECTION_TTL),
            grpc_max_message_size,
            _phantom: PhantomData,
        }
    }

    #[async_backtrace::framed]
    async fn new_established_client(
        &self,
        addr: &String,
    ) -> Result<EstablishedClient, MetaClientError> {
        let chan = self.build_channel(addr).await?;

        let (mut real_client, once) = self.new_real_client(chan);

        debug!(
            "MetaChannelManager done building RealClient to {}, start handshake",
            addr
        );

        let password = self.password.expose();
        let handshake_res = handshake(
            &mut real_client,
            databend_meta_version::version(),
            &databend_meta_version::MIN_SERVER_VERSION,
            &self.username,
            password,
        )
        .await;

        debug!(
            "MetaChannelManager done handshake to {}, result.err(): {:?}",
            addr,
            handshake_res.as_ref().err()
        );

        let (token, server_version) = handshake_res?;

        // Update the token for the client interceptor.
        // Safe unwrap(): it is the first time setting it.
        once.set(token).unwrap();

        Ok(EstablishedClient::new(
            real_client,
            server_version,
            addr,
            self.endpoints.clone(),
        ))
    }

    /// Create a MetaServiceClient with authentication interceptor, using instance config.
    fn new_real_client(&self, chan: Channel) -> (RealClient, Arc<OnceCell<Vec<u8>>>) {
        Self::new_real_client_with_size(chan, self.grpc_max_message_size)
    }

    /// Create a MetaServiceClient with default message size, for testing.
    pub fn new_real_client_for_testing(chan: Channel) -> (RealClient, Arc<OnceCell<Vec<u8>>>) {
        Self::new_real_client_with_size(chan, DEFAULT_GRPC_MESSAGE_SIZE)
    }

    /// Create a MetaServiceClient with the specified max message size.
    ///
    /// The returned `OnceCell` is used to fill in a token for the interceptor.
    fn new_real_client_with_size(
        chan: Channel,
        max_message_size: usize,
    ) -> (RealClient, Arc<OnceCell<Vec<u8>>>) {
        let once = Arc::new(OnceCell::new());

        let interceptor = AuthInterceptor {
            token: once.clone(),
        };

        let client = MetaServiceClient::with_interceptor(chan, interceptor)
            .max_decoding_message_size(max_message_size)
            .max_encoding_message_size(max_message_size);

        (client, once)
    }

    #[async_backtrace::framed]
    async fn build_channel(&self, addr: &String) -> Result<Channel, MetaNetworkError> {
        debug!("MetaChannelManager::build_channel to {}", addr);

        let ch = R::connect(addr.clone(), self.timeout, self.tls_config.clone())
            .await
            .map_err(|e| match e {
                ChannelError::InvalidUri { .. } => MetaNetworkError::BadAddressFormat(
                    AnyError::new(&e).add_context(|| "while creating rpc channel"),
                ),
                ChannelError::TlsConfig { .. } => MetaNetworkError::TLSConfigError(
                    AnyError::new(&e).add_context(|| "while creating rpc channel"),
                ),
                ChannelError::CannotConnect { .. } => MetaNetworkError::ConnectionError(
                    ConnectionError::new(e, "while creating rpc channel"),
                ),
            })?;
        Ok(ch)
    }
}

#[async_trait]
impl<R: SpawnApi> ItemManager for MetaChannelManager<R> {
    type Key = String;
    type Item = EstablishedClient;
    type Error = MetaClientError;

    #[logcall::logcall(err = "debug")]
    #[fastrace::trace]
    #[async_backtrace::framed]
    async fn build(&self, addr: &Self::Key) -> Result<Self::Item, Self::Error> {
        self.new_established_client(addr).await
    }

    #[logcall::logcall(err = "debug")]
    #[fastrace::trace]
    #[async_backtrace::framed]
    async fn check(&self, ch: Self::Item) -> Result<Self::Item, Self::Error> {
        // The underlying `tonic::transport::channel::Channel` reconnects when server is down.
        // But we still need to assert the readiness, e.g., when handshake token expires
        // If there was an error occurred, the channel will be closed.
        if let Some(e) = ch.take_error() {
            return Err(MetaNetworkError::from(e).into());
        }

        // Check if the connection has exceeded its TTL.
        // This prevents h2 stream reset accumulation that can lead to
        // `too_many_internal_resets` errors (ENHANCE_YOUR_CALM).
        if ch.is_expired(self.connection_ttl) {
            debug!(
                "Connection {} has exceeded TTL ({:?}), will create a new one",
                ch, self.connection_ttl
            );
            return Err(MetaNetworkError::ConnectionError(ConnectionError::new(
                AnyError::error("connection TTL exceeded"),
                "refreshing connection to prevent h2 stream reset accumulation",
            ))
            .into());
        }

        Ok(ch)
    }
}

#[cfg(test)]
mod tests {
    use std::sync::Arc;

    use databend_meta_runtime_api::TokioRuntime;
    use parking_lot::Mutex;

    use super::DEFAULT_GRPC_MESSAGE_SIZE;
    use super::MetaChannelManager;
    use crate::endpoints::Endpoints;

    const PASSWORD: &str = "correct-password";

    #[test]
    fn test_meta_channel_manager_debug_redacts_password() {
        let endpoints = Endpoints::new(["127.0.0.1:9191"]);
        let endpoints = Arc::new(Mutex::new(endpoints));
        let manager = MetaChannelManager::<TokioRuntime>::new(
            "root",
            PASSWORD,
            None,
            None,
            endpoints,
            None,
            DEFAULT_GRPC_MESSAGE_SIZE,
        );

        let debug = format!("{manager:?}");
        let contains_password = debug.contains(PASSWORD);
        assert!(!contains_password);

        let contains_redaction = debug.contains("***");
        assert!(contains_redaction);
    }
}
