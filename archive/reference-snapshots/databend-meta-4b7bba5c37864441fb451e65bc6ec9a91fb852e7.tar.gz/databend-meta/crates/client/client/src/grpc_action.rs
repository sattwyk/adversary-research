// Copyright 2021 Datafuse Labs
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use std::convert::TryInto;
use std::fmt;
use std::fmt::Debug;

use crate::types::Change;
use crate::types::GrpcHelper;
use crate::types::MetaError;
use crate::types::SeqV;

/// Get a single key-value pair.
#[derive(serde::Serialize, serde::Deserialize, Clone, Debug, PartialEq, Eq)]
pub struct GetKVReq {
    pub key: String,
}

/// Get multiple key-value pairs.
#[derive(serde::Serialize, serde::Deserialize, Clone, Debug, PartialEq, Eq)]
pub struct MGetKVReq {
    pub keys: Vec<String>,
}

impl MGetKVReq {
    pub fn new<S: ToString>(keys: impl IntoIterator<Item = S>) -> Self {
        Self {
            keys: keys.into_iter().map(|x| x.to_string()).collect(),
        }
    }
}

/// Stream-oriented get-many request.
///
/// Unlike `MGetKVReq` which requires all keys upfront,
/// this accepts a fallible stream of keys.
pub struct StreamedGetMany {
    pub keys: futures_util::stream::BoxStream<'static, Result<String, MetaError>>,
}

impl fmt::Debug for StreamedGetMany {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        f.debug_struct("StreamedGetMany").finish()
    }
}

/// List key-value pairs by prefix.
#[derive(serde::Serialize, serde::Deserialize, Clone, Debug, PartialEq, Eq)]
pub struct ListKVReq {
    pub prefix: String,
}

impl ListKVReq {
    pub fn new(prefix: impl ToString) -> Self {
        Self {
            prefix: prefix.to_string(),
        }
    }
}

pub type UpsertKVReply = Change<Vec<u8>>;
pub type GetKVReply = Option<SeqV<Vec<u8>>>;
pub type MGetKVReply = Vec<Option<SeqV<Vec<u8>>>>;
pub type ListKVReply = Vec<(String, SeqV<Vec<u8>>)>;
use log::debug;
use tonic::Request;
use tonic::codegen::BoxStream;

use crate::InitFlag;
use crate::established_client::EstablishedClient;
use crate::message::ExportReq;
use crate::message::GetClientInfo;
use crate::message::GetClusterStatus;
use crate::message::GetEndpoints;
use crate::message::GetMemberList;
use crate::message::MakeEstablishedClient;
use crate::message::Streamed;
use crate::types::InvalidArgument;
use crate::types::TxnReply;
use crate::types::TxnRequest;
use crate::types::UpsertKV;
use crate::types::pb::ClientInfo;
use crate::types::pb::ClusterStatus;
use crate::types::pb::KvTransactionReply;
use crate::types::pb::KvTransactionRequest;
use crate::types::pb::MemberListReply;
use crate::types::pb::RaftRequest;
use crate::types::pb::StreamItem;
use crate::types::pb::WatchRequest;
use crate::types::pb::WatchResponse;

/// Bind a request type to its corresponding response type.
pub trait RequestFor: fmt::Debug {
    type Reply;
}

#[derive(serde::Serialize, serde::Deserialize, Clone, Debug, derive_more::From)]
pub enum MetaGrpcReq {
    UpsertKV(UpsertKV),
}

impl TryInto<MetaGrpcReq> for Request<RaftRequest> {
    type Error = tonic::Status;

    fn try_into(self) -> Result<MetaGrpcReq, Self::Error> {
        let raft_request = self.into_inner();

        let json_str = raft_request.data.as_str();
        let req = serde_json::from_str::<MetaGrpcReq>(json_str)
            .map_err(|e| tonic::Status::internal(e.to_string()))?;
        Ok(req)
    }
}

impl From<MetaGrpcReq> for RaftRequest {
    fn from(v: MetaGrpcReq) -> Self {
        let raft_request = GrpcHelper::encode_raft_request(&v).expect("fail to serialize");

        debug!(
            req :? =(&raft_request);
            "build raft_request"
        );

        raft_request
    }
}

impl MetaGrpcReq {
    pub fn to_raft_request(&self) -> Result<RaftRequest, InvalidArgument> {
        let raft_request = GrpcHelper::encode_raft_request(self)
            .map_err(|e| InvalidArgument::new(e, "fail to encode request"))?;

        debug!(
            req :? =(&raft_request);
            "build raft_request"
        );

        Ok(raft_request)
    }
}

#[derive(
    serde::Serialize,
    serde::Deserialize,
    Debug,
    Clone,
    PartialEq,
    Eq,
    derive_more::From,
    derive_more::TryInto,
)]
pub enum MetaGrpcReadReq {
    GetKV(GetKVReq),
    MGetKV(MGetKVReq),
    ListKV(ListKVReq),
}

// All Read requests returns a stream of KV pairs.
impl RequestFor for MetaGrpcReadReq {
    type Reply = BoxStream<StreamItem>;
}

impl From<MetaGrpcReadReq> for RaftRequest {
    fn from(v: MetaGrpcReadReq) -> Self {
        let raft_request = GrpcHelper::encode_raft_request(&v).expect("fail to serialize");

        debug!(
            req :? =(&raft_request);
            "build raft_request"
        );

        raft_request
    }
}

impl MetaGrpcReadReq {
    pub fn to_raft_request(&self) -> Result<RaftRequest, InvalidArgument> {
        let raft_request = GrpcHelper::encode_raft_request(self)
            .map_err(|e| InvalidArgument::new(e, "fail to encode request"))?;

        debug!(
            req :? =(&raft_request);
            "build raft_request"
        );

        Ok(raft_request)
    }

    pub fn type_name(&self) -> &'static str {
        match self {
            MetaGrpcReadReq::GetKV(_) => "get",
            MetaGrpcReadReq::MGetKV(_) => "mget",
            MetaGrpcReadReq::ListKV(_) => "list",
        }
    }
}

impl RequestFor for GetKVReq {
    type Reply = GetKVReply;
}

impl RequestFor for MGetKVReq {
    type Reply = MGetKVReply;
}

impl RequestFor for ListKVReq {
    type Reply = ListKVReply;
}

impl RequestFor for StreamedGetMany {
    type Reply = futures_util::stream::BoxStream<'static, Result<StreamItem, MetaError>>;
}

impl RequestFor for Streamed<MGetKVReq> {
    type Reply = BoxStream<StreamItem>;
}

impl RequestFor for Streamed<ListKVReq> {
    type Reply = BoxStream<StreamItem>;
}

impl RequestFor for UpsertKV {
    type Reply = UpsertKVReply;
}

impl RequestFor for WatchRequest {
    type Reply = tonic::codec::Streaming<WatchResponse>;
}

impl RequestFor for (WatchRequest, InitFlag) {
    type Reply = tonic::codec::Streaming<WatchResponse>;
}

impl RequestFor for ExportReq {
    type Reply = tonic::codec::Streaming<WatchResponse>;
}

impl RequestFor for MakeEstablishedClient {
    type Reply = EstablishedClient;
}

impl RequestFor for GetEndpoints {
    type Reply = Vec<String>;
}

impl RequestFor for TxnRequest {
    type Reply = TxnReply;
}

impl RequestFor for KvTransactionRequest {
    type Reply = KvTransactionReply;
}

impl RequestFor for GetClusterStatus {
    type Reply = ClusterStatus;
}

impl RequestFor for GetMemberList {
    type Reply = MemberListReply;
}

impl RequestFor for GetClientInfo {
    type Reply = ClientInfo;
}
