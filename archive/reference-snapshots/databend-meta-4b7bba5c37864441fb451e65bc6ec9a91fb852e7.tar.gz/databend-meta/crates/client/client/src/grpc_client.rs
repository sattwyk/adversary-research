// Copyright 2021 Datafuse Labs
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use std::fmt::Debug;
use std::fmt::Display;
use std::fmt::Formatter;
use std::marker::PhantomData;
use std::sync::Arc;
use std::task::Poll;
use std::time::Duration;
use std::time::Instant;

use arrow_flight::BasicAuth;
use databend_base::futures::ElapsedFutureExt;
use databend_meta_runtime_api::ClientMetricsApi;
use databend_meta_runtime_api::RuntimeApi;
use databend_meta_runtime_api::TlsConfig;
use databend_meta_version::Version;
use fastrace::Span;
use fastrace::func_name;
use fastrace::func_path;
use fastrace::future::FutureExt as MTFutureExt;
use futures::stream::StreamExt;
use log::debug;
use log::error;
use log::info;
use log::warn;
use once_cell::sync::OnceCell;
use parking_lot::Mutex;
use prost::Message;
use tokio::select;
use tokio::sync::mpsc;
use tokio::sync::mpsc::UnboundedReceiver;
use tokio::sync::oneshot;
use tokio::sync::oneshot::Sender as OneSend;
use tokio::time::sleep;
use tonic::Code;
use tonic::Request;
use tonic::Status;
use tonic::Streaming;
use tonic::codegen::BoxStream;
use tonic::codegen::InterceptedService;
use tonic::metadata::MetadataValue;
use tonic::service::Interceptor;
use tonic::transport::Channel;

use crate::ClientHandle;
use crate::ClientWorkerRequest;
use crate::MetaChannelManager;
use crate::MetaGrpcReadReq;
use crate::client_conf::RpcClientConf;
use crate::client_conf::RpcClientTlsConfig;
use crate::endpoints::Endpoints;
use crate::endpoints::rotate_failing_endpoint;
use crate::errors::CreationError;
use crate::established_client::EstablishedClient;
use crate::grpc_action::StreamedGetMany;
use crate::message;
use crate::message::Response;
use crate::pool::Pool;
use crate::rpc_handler::ResponseAction;
use crate::rpc_handler::RpcHandler;
use crate::types::ConnectionError;
use crate::types::MetaClientError;
use crate::types::MetaError;
use crate::types::MetaHandshakeError;
use crate::types::MetaNetworkError;
use crate::types::TxnReply;
use crate::types::TxnRequest;
use crate::types::anyerror::AnyError;
use crate::types::pb;
use crate::types::pb::ClientInfo;
use crate::types::pb::ClusterStatus;
use crate::types::pb::Empty;
use crate::types::pb::ExportedChunk;
use crate::types::pb::HandshakeRequest;
use crate::types::pb::MemberListReply;
use crate::types::pb::MemberListRequest;
use crate::types::pb::RaftRequest;
use crate::types::pb::WatchRequest;
use crate::types::pb::WatchResponse;
use crate::types::pb::meta_service_client::MetaServiceClient;

const RPC_RETRIES: usize = 4;
const AUTH_TOKEN_KEY: &str = "auth-token-bin";

pub(crate) type RealClient = MetaServiceClient<InterceptedService<Channel, AuthInterceptor>>;

// TODO: maybe it just needs a runtime, not a MetaGrpcClientWorker.
//
/// Meta grpc client has a internal worker task that deals with all traffic to remote meta service.
///
/// We expect meta-client should be cloneable.
/// But the underlying hyper client has a worker that runs in its creating tokio-runtime.
/// Thus a cloned meta client may try to talk to a destroyed hyper worker if the creating tokio-runtime is dropped.
/// Thus we have to guarantee that as long as there is a meta-client, the hyper worker runtime must not be dropped.
/// Thus a meta client creates a runtime then spawn a MetaGrpcClientWorker.
pub struct MetaGrpcClient<RT: RuntimeApi> {
    conn_pool: Pool<MetaChannelManager<RT>>,
    endpoints: Arc<Mutex<Endpoints>>,
    endpoints_str: Vec<String>,
    auto_sync_interval: Option<Duration>,

    _phantom: PhantomData<RT>,
}

impl<RT: RuntimeApi> Debug for MetaGrpcClient<RT> {
    fn fmt(&self, f: &mut Formatter) -> std::fmt::Result {
        let mut de = f.debug_struct("MetaGrpcClient");
        de.field("endpoints", &*self.endpoints.lock());
        de.field("auto_sync_interval", &self.auto_sync_interval);
        de.finish()
    }
}

impl<RT: RuntimeApi> Display for MetaGrpcClient<RT> {
    fn fmt(&self, f: &mut Formatter) -> std::fmt::Result {
        write!(f, "MetaGrpcClient({})", self.endpoints_str.join(","))
    }
}

impl<RT: RuntimeApi> MetaGrpcClient<RT> {
    /// Returns the version of this client.
    pub fn version(&self) -> &'static Version {
        databend_meta_version::version()
    }

    /// Create a new client of metasrv.
    ///
    /// It creates a new `Runtime` and spawn a background worker task in it that do all the RPC job.
    /// A client-handle is returned to communicate with the worker.
    ///
    /// Thus the real work is done in the dedicated runtime to avoid the client spawning tasks in the caller's runtime, which potentially leads to a deadlock if the caller has blocking calls to other components
    /// Because `tower` and `hyper` will spawn tasks when handling RPCs.
    ///
    /// The worker is a singleton and the returned handle is cheap to clone.
    /// When all handles are dropped the worker will quit, then the runtime will be destroyed.
    pub fn try_new(conf: &RpcClientConf) -> Result<Arc<ClientHandle<RT>>, CreationError> {
        let password = conf.password.expose();
        Self::try_create(
            conf.get_endpoints(),
            &conf.username,
            password,
            conf.timeout,
            conf.auto_sync_interval,
            conf.tls_conf.clone(),
            conf.grpc_max_message_size,
        )
    }

    /// Create a new meta-client with exact required features.
    #[fastrace::trace]
    pub fn try_create(
        endpoints_str: Vec<String>,
        username: &str,
        password: &str,
        timeout: Option<Duration>,
        auto_sync_interval: Option<Duration>,
        tls_config: Option<RpcClientTlsConfig>,
        grpc_max_message_size: usize,
    ) -> Result<Arc<ClientHandle<RT>>, CreationError> {
        Self::try_create_with_features(
            endpoints_str,
            username,
            password,
            timeout,
            auto_sync_interval,
            tls_config,
            grpc_max_message_size,
        )
    }

    /// Create a new meta-client with specific required features.
    ///
    /// This method enables version compatibility by allowing an older meta-client to
    /// connect to a newer meta-server with a limited feature set.
    /// During handshaking, the server verifies that it supports all features in `required_features`.
    ///
    /// Features not specified in `required_features` may still be available if the server supports them,
    /// but errors will only be returned when those features are actually accessed.
    ///
    /// For common feature sets, use the predefined collections in the `required` module:
    /// - `std()` - Standard features for general client usage
    /// - `business()` - Core business logic features (read, write, transaction)
    /// - `export()` - Features required for export operations
    #[fastrace::trace]
    pub fn try_create_with_features(
        endpoints_str: Vec<String>,
        username: &str,
        password: &str,
        timeout: Option<Duration>,
        auto_sync_interval: Option<Duration>,
        tls_config: Option<RpcClientTlsConfig>,
        grpc_max_message_size: usize,
    ) -> Result<Arc<ClientHandle<RT>>, CreationError> {
        Self::endpoints_non_empty(&endpoints_str)?;

        let endpoints = Arc::new(Mutex::new(Endpoints::new(endpoints_str.clone())));

        let tls = tls_config.map(|c| TlsConfig {
            root_ca_cert_path: c.rpc_tls_server_root_ca_cert,
            domain_name: c.domain_name,
        });

        let mgr = MetaChannelManager::new(
            username,
            password,
            timeout,
            tls,
            endpoints.clone(),
            None, // Use default connection TTL
            grpc_max_message_size,
        );

        let rt = RT::new(
            Some(1),
            Some(format!("meta-client-rt-{}", endpoints_str.join(","))),
        )
        .map_err(|e| CreationError::new_runtime_error(e).context("when creating meta-client"))?;

        // Build the handle-worker pair

        let (tx, rx) = mpsc::unbounded_channel();
        let (one_tx, one_rx) = oneshot::channel::<()>();

        let handle = Arc::new(ClientHandle {
            endpoints: endpoints_str.clone(),
            shared_endpoints: endpoints.clone(),
            req_tx: tx,
            cancel_auto_sync_tx: one_tx,
            _rt: Arc::new(rt.clone()) as Arc<dyn std::any::Any + Send + Sync>,
            _phantom: PhantomData,
        });

        let worker = Arc::new(Self {
            conn_pool: Pool::new(mgr, Duration::from_millis(50)),
            endpoints,
            endpoints_str,
            auto_sync_interval,
            _phantom: PhantomData,
        });

        let worker_name = worker.to_string();

        rt.spawn_on(
            RT::unlimited_future(Self::worker_loop(worker.clone(), rx)),
            Some(format!("{}::worker_loop()", worker_name)),
        );

        rt.spawn_on(
            RT::unlimited_future(Self::auto_sync_endpoints(worker, one_rx)),
            Some(format!("{}::auto_sync_endpoints()", worker_name)),
        );

        Ok(handle)
    }

    /// A worker runs a receiving-loop to accept user-request to metasrv and deals with request in the dedicated runtime.
    #[fastrace::trace]
    #[async_backtrace::framed]
    async fn worker_loop(self: Arc<Self>, mut req_rx: UnboundedReceiver<ClientWorkerRequest>) {
        info!("{}::worker spawned", self);

        loop {
            let recv_res = req_rx.recv().await;
            let Some(mut worker_request) = recv_res else {
                info!("{} handle closed. worker quit", self);
                return;
            };

            debug!(worker_request :? =(&worker_request); "{} worker handle request", self);

            let _guard = (worker_request.tracking_fn.take().unwrap())();
            let span = Span::enter_with_parent(func_path!(), &worker_request.span);

            if worker_request.resp_tx.is_closed() {
                info!(
                    req :? =(&worker_request.req);
                    "{} request.resp_tx is closed, cancel handling this request", self
                );
                continue;
            }

            // Handle requests that don't go through the generic handle_rpc_request path.
            #[allow(clippy::single_match)]
            match worker_request.req {
                message::Request::GetEndpoints(_) => {
                    let endpoints = self.get_all_endpoints();
                    let resp = Response::GetEndpoints(Ok(endpoints));
                    Self::send_response(
                        self.clone(),
                        worker_request.resp_tx,
                        worker_request.request_id,
                        resp,
                    );
                    continue;
                }
                _ => {}
            }

            RT::spawn(
                self.clone()
                    .handle_rpc_request(worker_request)
                    .in_span(span),
                Some(format!("{}::handle_rpc_request()", self)),
            );
        }
    }

    /// Handle a RPC request in a separate task.
    #[fastrace::trace]
    #[async_backtrace::framed]
    async fn handle_rpc_request(self: Arc<Self>, worker_request: ClientWorkerRequest) {
        let request_id = worker_request.request_id;
        let resp_tx = worker_request.resp_tx;
        let req = worker_request.req;
        let req_name = req.name();
        let req_str = format!("{:?}", req);

        let start = Instant::now();
        let resp = match req {
            message::Request::StreamMGet(r) => {
                let strm = self
                    .kv_read_v1(MetaGrpcReadReq::MGetKV(r.into_inner()))
                    .await;
                Response::StreamMGet(strm)
            }
            message::Request::StreamedGetMany(r) => {
                let resp = self.handle_streamed_get_many(r).await;
                Response::StreamedGetMany(resp)
            }
            message::Request::StreamList(r) => {
                let strm = self
                    .kv_read_v1(MetaGrpcReadReq::ListKV(r.into_inner()))
                    .await;
                Response::StreamMGet(strm)
            }
            message::Request::Txn(r) => {
                let resp = self.transaction(r).await;
                Response::Txn(resp)
            }
            message::Request::KvTransaction(r) => {
                let resp = self.transaction_v2(r).await;
                Response::KvTransaction(resp)
            }
            message::Request::Watch(r) => {
                let resp = self.watch(r).await;
                Response::Watch(resp)
            }
            message::Request::WatchWithInitialization((r, _)) => {
                let resp = self.watch_with_initialization(r).await;
                Response::WatchWithInitialization(resp)
            }
            message::Request::Export(r) => {
                let resp = self.export(r).await;
                Response::Export(resp)
            }
            message::Request::MakeEstablishedClient(_) => {
                let resp = self.get_established_client().await;
                Response::MakeEstablishedClient(resp)
            }
            message::Request::GetEndpoints(_) => {
                unreachable!("handled above");
            }
            message::Request::GetClusterStatus(_) => {
                let resp = self.get_cluster_status().await;
                Response::GetClusterStatus(resp)
            }
            message::Request::GetMemberList(_) => {
                let resp = self.get_member_list().await;
                Response::GetMemberList(resp)
            }
            message::Request::GetClientInfo(_) => {
                let resp = self.get_client_info().await;
                Response::GetClientInfo(resp)
            }
        };

        self.update_rpc_metrics(req_name, &req_str, request_id, start, resp.err());

        Self::send_response(self.clone(), resp_tx, request_id, resp);
    }

    fn send_response(self: Arc<Self>, tx: OneSend<Response>, request_id: u64, resp: Response) {
        debug!(
            "{} send response to the handle; request_id={}, resp={:?}",
            self, request_id, resp
        );

        let send_res = tx.send(resp);
        if let Err(err) = send_res {
            error!(
                "{} failed to send response to the handle. recv-end closed; request_id={}, error={:?}",
                self, request_id, err
            );
        }
    }

    /// Call `kv_get_many` with a channel-backed stream, retrying on
    /// retryable errors (e.g. "not leader").
    ///
    /// A channel decouples the input key stream from the gRPC call:
    /// keys are only fed into the channel after a successful connection,
    /// so on failure the input stream is untouched and retry is trivial.
    async fn handle_streamed_get_many(
        &self,
        req: StreamedGetMany,
    ) -> Result<
        futures_util::stream::BoxStream<'static, Result<pb::StreamItem, MetaError>>,
        MetaClientError,
    > {
        use databend_meta_kvapi::fail_fast;

        let mut keys = req.keys;
        let input_err: Arc<Mutex<Option<MetaError>>> = Arc::new(Mutex::new(None));

        let n = {
            let eps = self.endpoints.lock();
            eps.len()
        };

        let mut last_status = None::<Status>;

        for _attempt in 0..n {
            let mut client = self.get_established_client().await?;

            let (tx, rx) = futures::channel::mpsc::channel(64);

            // Box::pin erases the future type that contains a `dyn Stream`
            // trait object, which otherwise triggers a HRTB `Send` error.
            let result = {
                use std::future::Future;
                use std::pin::Pin;

                let fut: Pin<Box<dyn Future<Output = _> + Send>> = Box::pin(client.kv_get_many(rx));
                fut.await
            };

            match result {
                Ok(response) => {
                    // Connection accepted. Map keys and feed them into the
                    // channel concurrently with reading the response.
                    let err_slot = input_err.clone();
                    tokio::spawn(async move {
                        use futures::SinkExt;
                        let mut tx = tx;
                        while let Some(result) = keys.next().await {
                            match result {
                                Ok(key) => {
                                    if tx.send(pb::KvGetManyRequest { key }).await.is_err() {
                                        break;
                                    }
                                }
                                Err(e) => {
                                    *err_slot.lock() = Some(e);
                                    break;
                                }
                            }
                        }
                    });

                    let output = response.into_inner();
                    let mapped =
                        output.map(|item| item.map_err(|s| MetaNetworkError::from(s).into()));

                    let with_input_err = mapped.chain(futures::stream::poll_fn(move |_cx| {
                        match input_err.lock().take() {
                            Some(e) => Poll::Ready(Some(Err(e))),
                            None => Poll::Ready(None),
                        }
                    }));

                    return Ok(fail_fast(with_input_err).boxed());
                }
                Err(status) => {
                    if is_status_retryable(&status) {
                        warn!("kv_get_many retryable error: {:?}; retrying", status);
                        last_status = Some(status);
                        continue;
                    }
                    return Err(MetaClientError::from(MetaNetworkError::from(status)));
                }
            }
        }

        Err(MetaClientError::from(MetaNetworkError::from(
            last_status.unwrap_or_else(|| Status::internal("kv_get_many: no endpoints available")),
        )))
    }

    fn update_rpc_metrics(
        &self,
        req_name: &'static str,
        req_str: &str,
        request_id: u64,
        start: Instant,
        resp_err: Option<&(dyn std::error::Error + 'static)>,
    ) {
        // TODO: this current endpoint is not stable, may be modified by other thread.
        //       The caller should passing the in use endpoint.
        let current_endpoint = self.get_current_endpoint();

        let Some(endpoint) = current_endpoint else {
            return;
        };

        // Duration metrics
        {
            let elapsed = start.elapsed().as_millis() as f64;
            RT::ClientMetrics::record_request_duration(&endpoint, req_name, elapsed);

            if elapsed > 1000_f64 {
                warn!(
                    "{} slow request {} to {} takes {} ms; request_id={}; request: {}",
                    self, req_name, endpoint, elapsed, request_id, req_str,
                );
            }
        }

        // Error metrics
        if let Some(err) = resp_err {
            let err_name = err
                .downcast_ref::<MetaError>()
                .map(|e| e.name())
                .unwrap_or("unknown");
            RT::ClientMetrics::record_request_failed(&endpoint, req_name, err_name);
            error!("{} request_id={} error: {:?}", self, request_id, err);
        } else {
            RT::ClientMetrics::record_request_success(&endpoint, req_name);
        }
    }

    /// Return a client for communication, and a server version in form of `{major:03}.{minor:03}.{patch:03}`.
    #[fastrace::trace]
    #[async_backtrace::framed]
    pub async fn get_established_client(&self) -> Result<EstablishedClient, MetaClientError> {
        let (endpoints_str, n) = {
            let eps = self.endpoints.lock();
            (eps.to_string(), eps.len())
        };
        debug_assert!(n > 0);

        debug!("{}::{}; endpoints: {}", self, func_name!(), endpoints_str);

        let mut last_err = None::<MetaClientError>;

        for _ith in 0..n {
            let addr = {
                let mut es = self.endpoints.lock();
                es.current_or_next().to_string()
            };

            debug!("{} get or build ReadClient to {}", self, addr);

            let res = self.conn_pool.get(&addr).await;

            match res {
                Ok(client) => {
                    return Ok(client);
                }
                Err(client_err) => {
                    error!(
                        "Failed to get or build RealClient to {}, err: {:?}",
                        addr, client_err
                    );
                    RT::ClientMetrics::record_make_client_fail(&addr);

                    rotate_failing_endpoint(&self.endpoints, Some(&addr), self);

                    last_err = Some(client_err);
                    continue;
                }
            }
        }

        if let Some(e) = last_err {
            return Err(e);
        }

        let conn_err =
            ConnectionError::new(AnyError::error(&endpoints_str), "no endpoints to connect");

        Err(MetaClientError::NetworkError(
            MetaNetworkError::ConnectionError(conn_err),
        ))
    }

    pub fn endpoints_non_empty(endpoints: &[String]) -> Result<(), CreationError> {
        if endpoints.is_empty() {
            return Err(CreationError::new_config_error("endpoints is empty"));
        }
        Ok(())
    }

    fn get_all_endpoints(&self) -> Vec<String> {
        let eps = self.endpoints.lock();
        eps.nodes().cloned().collect()
    }

    #[fastrace::trace]
    #[async_backtrace::framed]
    pub fn set_endpoints(&self, endpoints: Vec<String>) {
        debug_assert!(!endpoints.is_empty());

        // Older meta nodes may not store endpoint information and need to be filtered out.
        let distinct_cnt = endpoints.iter().filter(|n| !(*n).is_empty()).count();

        // If the fetched endpoints are less than the majority of the current cluster, no replacement should occur.
        if distinct_cnt < endpoints.len() / 2 + 1 {
            warn!(
                "distinct endpoints small than majority of meta cluster nodes {}<{}, endpoints: {:?}",
                distinct_cnt,
                endpoints.len(),
                endpoints
            );
            return;
        }

        let mut eps = self.endpoints.lock();
        eps.replace_nodes(endpoints);
    }

    #[fastrace::trace]
    #[async_backtrace::framed]
    pub async fn sync_endpoints(&self) -> Result<(), MetaError> {
        let mut established_client = self.get_established_client().await?;

        let result = established_client
            .member_list(Request::new(MemberListRequest {
                data: "".to_string(),
            }))
            .await;

        let endpoints: Result<MemberListReply, Status> = match result {
            Ok(r) => Ok(r.into_inner()),
            Err(s) => {
                if is_status_retryable(&s) {
                    established_client.rotate_failing_target();

                    let mut client = self.get_established_client().await?;
                    let req = Request::new(MemberListRequest {
                        data: "".to_string(),
                    });
                    Ok(client.member_list(req).await?.into_inner())
                } else {
                    Err(s)
                }
            }
        };

        let result: Vec<String> = endpoints?.data;
        debug!("received meta endpoints: {:?}", result);

        if result.is_empty() {
            error!("Can not update local endpoints, the returned result is empty");
        } else {
            self.set_endpoints(result);
        }

        Ok(())
    }

    #[fastrace::trace]
    #[async_backtrace::framed]
    async fn auto_sync_endpoints(self: Arc<Self>, mut cancel_rx: oneshot::Receiver<()>) {
        info!(
            "{} start auto_sync_endpoints: interval: {:?}",
            self, self.auto_sync_interval
        );

        if let Some(interval) = self.auto_sync_interval {
            loop {
                debug!("{} auto_sync_endpoints loop start", self);

                select! {
                    _ = &mut cancel_rx => {
                        info!("{} auto_sync_endpoints received quit signal, quit", self);
                        return;
                    }
                    _ = sleep(interval) => {
                        let r = self.sync_endpoints().await;
                        if let Err(e) = r {
                            warn!("{} auto_sync_endpoints failed: {:?}", self, e);
                        }
                    }
                }
            }
        }
    }

    /// Create a watching stream that receives KV change events.
    #[fastrace::trace]
    #[async_backtrace::framed]
    pub(crate) async fn watch(
        &self,
        watch_request: WatchRequest,
    ) -> Result<Streaming<WatchResponse>, MetaClientError> {
        debug!("{}: handle watch request: {:?}", self, watch_request);

        let mut client = self.get_established_client().await?;

        let res = client.watch(watch_request).await?;
        Ok(res.into_inner())
    }

    /// Create a watching stream that receives KV change events.
    ///
    /// This method is similar to `watch`, but it also sends all existing key-values with `is_initialization=true`
    /// before starting the watch stream.
    #[fastrace::trace]
    #[async_backtrace::framed]
    pub(crate) async fn watch_with_initialization(
        &self,
        watch_request: WatchRequest,
    ) -> Result<Streaming<WatchResponse>, MetaClientError> {
        debug!("{}: handle watch request: {:?}", self, watch_request);

        let mut client = self.get_established_client().await?;

        let res = client.watch(watch_request).await?;
        Ok(res.into_inner())
    }

    /// Export all data in json from metasrv.
    #[fastrace::trace]
    #[async_backtrace::framed]
    pub(crate) async fn export(
        &self,
        export_request: message::ExportReq,
    ) -> Result<Streaming<ExportedChunk>, MetaClientError> {
        debug!(
            "{} worker: handle export request: {:?}",
            self, export_request
        );

        let mut client = self.get_established_client().await?;
        let res = client
            .export_v1(pb::ExportRequest {
                chunk_size: export_request.chunk_size,
            })
            .await?;
        Ok(res.into_inner())
    }

    /// Get cluster status
    #[fastrace::trace]
    #[async_backtrace::framed]
    pub(crate) async fn get_cluster_status(&self) -> Result<ClusterStatus, MetaClientError> {
        debug!("{}::get_cluster_status", self);

        let mut client = self.get_established_client().await?;
        let res = client.get_cluster_status(Empty {}).await?;
        Ok(res.into_inner())
    }

    /// Get member list
    #[fastrace::trace]
    #[async_backtrace::framed]
    pub async fn get_member_list(&self) -> Result<MemberListReply, MetaClientError> {
        debug!("{}::get_member_list", self);
        let mut client = self.get_established_client().await?;
        let req = MemberListRequest {
            data: "".to_string(),
        };
        let res = client.member_list(req).await?;
        Ok(res.into_inner())
    }

    /// Export all data in json from metasrv.
    #[fastrace::trace]
    #[async_backtrace::framed]
    pub(crate) async fn get_client_info(&self) -> Result<ClientInfo, MetaClientError> {
        debug!("{}::get_client_info", self);

        let mut client = self.get_established_client().await?;
        let res = client.get_client_info(Empty {}).await?;
        Ok(res.into_inner())
    }

    #[fastrace::trace]
    #[async_backtrace::framed]
    pub(crate) async fn kv_read_v1(
        &self,
        grpc_req: MetaGrpcReadReq,
    ) -> Result<BoxStream<pb::StreamItem>, MetaError> {
        debug!("{}::kv_read_v1 request: {:?}", self, grpc_req);

        let raft_req: RaftRequest = grpc_req.clone().into();
        let mut rpc_handler = RpcHandler::new(self);

        for _i in 0..RPC_RETRIES {
            let req = RT::prepare_request(Request::new(raft_req.clone()));

            let established = rpc_handler.new_established_client().await?;

            debug!("{}::kv_read_v1 established client: {:?}", self, established);

            let result = established
                .kv_read_v1(req)
                .inspect_elapsed_over(threshold(), info_spent("kv_read_v1"))
                .await;

            debug!("{self}::kv_read_v1 result: {:?}", result);

            let retryable = rpc_handler.process_response_result(&grpc_req, result)?;

            let response = match retryable {
                ResponseAction::Success(resp) => resp,
                ResponseAction::ShouldRetry => {
                    continue;
                }
            };

            let strm = response.into_inner();
            return Ok(strm.boxed());
        }

        let net_err = rpc_handler.create_network_error();
        Err(net_err.into())
    }

    #[fastrace::trace]
    #[async_backtrace::framed]
    pub(crate) async fn transaction(&self, txn: TxnRequest) -> Result<TxnReply, MetaClientError> {
        debug!("{self}::transaction request: {txn}");

        let mut rpc_handler = RpcHandler::new(self);

        for _i in 0..RPC_RETRIES {
            let req = RT::prepare_request(Request::new(txn.clone()));

            let established = rpc_handler.new_established_client().await?;

            let result = established
                .transaction(req)
                .inspect_elapsed_over(threshold(), info_spent("transaction"))
                .await;

            let retryable = rpc_handler.process_response_result(&txn, result)?;

            let response = match retryable {
                ResponseAction::Success(resp) => resp,
                ResponseAction::ShouldRetry => {
                    continue;
                }
            };

            let txn_reply = response.into_inner();
            return Ok(txn_reply);
        }

        let net_err = rpc_handler.create_network_error();
        Err(net_err.into())
    }

    #[fastrace::trace]
    #[async_backtrace::framed]
    pub(crate) async fn transaction_v2(
        &self,
        txn: pb::KvTransactionRequest,
    ) -> Result<pb::KvTransactionReply, MetaClientError> {
        debug!("{self}::transaction_v2 request: {txn:?}");

        let mut rpc_handler = RpcHandler::new(self);

        for _i in 0..RPC_RETRIES {
            let req = RT::prepare_request(Request::new(txn.clone()));

            let established = rpc_handler.new_established_client().await?;

            let result = established
                .kv_transaction(req)
                .inspect_elapsed_over(threshold(), info_spent("transaction_v2"))
                .await;

            let retryable = rpc_handler.process_response_result(&txn, result)?;

            let response = match retryable {
                ResponseAction::Success(resp) => resp,
                ResponseAction::ShouldRetry => {
                    continue;
                }
            };

            let reply = response.into_inner();
            return Ok(reply);
        }

        let net_err = rpc_handler.create_network_error();
        Err(net_err.into())
    }

    fn get_current_endpoint(&self) -> Option<String> {
        let es = self.endpoints.lock();
        es.current().map(|x| x.to_string())
    }
}

/// Handshake with metasrv.
///
/// - Check whether the versions of this client(`C`) and the remote metasrv(`S`) are compatible.
/// - Authorize this client.
///
/// ## Check compatibility
///
/// Both client `C` and  server `S` maintains two semantic-version:
/// - `C` maintains the its own semver(`C.ver`) and the minimal compatible `S` semver(`C.min_srv_ver`).
/// - `S` maintains the its own semver(`S.ver`) and the minimal compatible `S` semver(`S.min_cli_ver`).
///
/// When handshaking:
/// - `C` sends its ver `C.ver` to `S`,
/// - When `S` receives handshake request, `S` asserts that `C.ver >= S.min_cli_ver`.
/// - Then `S` replies handshake-reply with its `S.ver`.
/// - When `C` receives the reply, `C` asserts that `S.ver >= C.min_srv_ver`.
///
/// Handshake succeeds if both of these two assertions hold.
///
/// E.g.:
/// - `S: (ver=3, min_cli_ver=1)` is compatible with `C: (ver=3, min_srv_ver=2)`.
/// - `S: (ver=4, min_cli_ver=4)` is **NOT** compatible with `C: (ver=3, min_srv_ver=2)`.
///   Because although `S.ver(4) >= C.min_srv_ver(3)` holds,
///   but `C.ver(3) >= S.min_cli_ver(4)` does not hold.
///
/// ```text
/// C.ver:    1             3      4
/// C --------+-------------+------+------------>
///           ^      .------'      ^
///           |      |             |
///           '-------------.      |
///                  |      |      |
///                  v      |      |
/// S ---------------+------+------+------------>
/// S.ver:           2      3      4
/// ```
#[fastrace::trace]
#[async_backtrace::framed]
pub async fn handshake(
    client: &mut RealClient,
    client_version: &Version,
    required_server_version: &Version,
    username: &str,
    password: &str,
) -> Result<(Vec<u8>, u64), MetaHandshakeError> {
    debug!("client version: {client_version}");

    let auth = BasicAuth {
        username: username.to_string(),
        password: password.to_string(),
    };
    let mut payload = vec![];

    // TODO: return MetaNetworkError
    auth.encode(&mut payload)
        .map_err(|e| MetaHandshakeError::new("Fail to encode request payload").with_source(&e))?;

    let my_ver = client_version.to_digit();
    let req = Request::new(futures::stream::once(async move {
        HandshakeRequest {
            protocol_version: my_ver,
            payload,
        }
    }));

    // TODO: return MetaNetworkError
    let rx = client
        .handshake(req)
        .await
        .map_err(|e| MetaHandshakeError::new("Connection Failure").with_source(&e))?;
    let mut rx = rx.into_inner();

    let res = rx
        .next()
        .await
        .ok_or_else(|| MetaHandshakeError::new("Server returned nothing"))?;

    let resp =
        res.map_err(|status| MetaHandshakeError::new("Connection Failure").with_source(&status))?;

    assert!(
        resp.protocol_version > 0,
        "talking to a very old databend-meta: upgrade databend-meta to at least 0.8"
    );

    let server_version = Version::from_digit(resp.protocol_version);

    if server_version < *required_server_version {
        return Err(MetaHandshakeError::new(format!(
            "Invalid: server protocol_version({:?}) < client required({:?})",
            server_version.as_tuple(),
            required_server_version.as_tuple()
        )));
    }

    let token = resp.payload;
    let server_version = resp.protocol_version;

    Ok((token, server_version))
}

fn is_status_retryable(status: &Status) -> bool {
    matches!(
        status.code(),
        Code::Unauthenticated | Code::Unavailable | Code::Internal | Code::Cancelled
    )
}

/// Fill in auth token into request metadata.
///
/// The token is stored in a `OnceCell`, which is fill in when handshake is done.
#[derive(Clone)]
pub struct AuthInterceptor {
    pub token: Arc<OnceCell<Vec<u8>>>,
}

impl Interceptor for AuthInterceptor {
    fn call(&mut self, mut req: tonic::Request<()>) -> Result<tonic::Request<()>, Status> {
        let metadata = req.metadata_mut();

        // The handshake does not need token.
        // When the handshake is done, token is filled.
        let Some(token) = self.token.get() else {
            return Ok(req);
        };

        let meta_value = MetadataValue::from_bytes(token.as_ref());
        metadata.insert_bin(AUTH_TOKEN_KEY, meta_value);
        Ok(req)
    }
}

fn threshold() -> Duration {
    Duration::from_millis(300)
}

fn info_spent<T>(msg: impl Display) -> impl Fn(&T, Duration, Duration)
where T: Debug {
    move |output, total, busy| {
        info!(
            "{} spent: total: {:?}, busy: {:?}; result: {:?}",
            msg, total, busy, output
        );
    }
}
