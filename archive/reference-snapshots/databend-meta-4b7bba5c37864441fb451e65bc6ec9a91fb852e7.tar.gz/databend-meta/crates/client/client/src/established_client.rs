// Copyright 2021 Datafuse Labs
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use std::fmt;
use std::sync::Arc;
use std::sync::atomic::AtomicU64;
use std::sync::atomic::Ordering;
use std::time::Duration;
use std::time::Instant;

use chrono::Utc;
use display_more::DisplayOptionExt;
use log::debug;
use log::error;
use log::info;
use log::warn;
use parking_lot::Mutex;
use tonic::Response;
use tonic::Status;
use tonic::codec::Streaming;
use tonic::codegen::InterceptedService;
use tonic::transport::Channel;

use crate::endpoints::Endpoints;
use crate::endpoints::rotate_failing_endpoint;
use crate::grpc_client::AuthInterceptor;
use crate::grpc_client::RealClient;
use crate::types::Endpoint;
use crate::types::GrpcHelper;
use crate::types::TxnReply;
use crate::types::TxnRequest;
use crate::types::pb;
use crate::types::pb::ClientInfo;
use crate::types::pb::ClusterStatus;
use crate::types::pb::Empty;
use crate::types::pb::ExportedChunk;
use crate::types::pb::KeysCount;
use crate::types::pb::KeysLayoutRequest;
use crate::types::pb::KvGetManyRequest;
use crate::types::pb::KvListRequest;
use crate::types::pb::MemberListReply;
use crate::types::pb::MemberListRequest;
use crate::types::pb::RaftReply;
use crate::types::pb::RaftRequest;
use crate::types::pb::StreamItem;
use crate::types::pb::WatchRequest;
use crate::types::pb::WatchResponse;
use crate::types::pb::meta_service_client::MetaServiceClient;

/// Update the client state according to the result of an RPC.
trait HandleRPCResult<T> {
    fn update_client(self, client: &mut EstablishedClient) -> Self;
}

impl<T> HandleRPCResult<T> for Result<Response<T>, Status> {
    fn update_client(self, client: &mut EstablishedClient) -> Result<Response<T>, Status> {
        // - Set the `current` node in endpoints to the leader if the request is forwarded by a follower to a leader.
        // - Store the error if received an error.

        debug!(
            "{client} update_client: received response, endpoints: {}",
            &*client.endpoints.lock(),
        );

        self.inspect(|response| {
            let Some(leader) = GrpcHelper::parse_leader_from_metadata(response.metadata()) else {
                return;
            };

            client.try_set_leader(&leader, "response");
        })
        .inspect_err(|status| {
            if let Some(leader) = GrpcHelper::parse_leader_from_metadata(status.metadata()) {
                client.try_set_leader(&leader, "error status");
            }

            warn!("{client} update_client: received error: {:?}", status);
            client.set_error(status.clone());
        })
    }
}

/// A gRPC client that has established a connection to a server and passed handshake.
#[derive(Debug, Clone)]
pub struct EstablishedClient {
    client: RealClient,

    server_protocol_version: u64,

    /// The target endpoint this client connected to.
    ///
    /// Note that `target_endpoint` may be different from the `self.endpoints.current()`,
    /// which is used for in future connections and may have been updated by other thread.
    target_endpoint: String,

    /// The endpoints shared in a client pool.
    endpoints: Arc<Mutex<Endpoints>>,

    /// For implementing `Display`, without acquiring the lock in `endpoints`, which might lead to deadlock.
    ///
    /// For example, to implement `Display` with `endpoints`, `format!("{self} {self}")` will deadlock.
    endpoints_string: String,

    /// The error that occurred when sending an RPC.
    ///
    /// The client with error will be dropped by the client pool.
    error: Arc<Mutex<Option<Status>>>,

    /// A unique identifier for the client, used to distinguish between different clients.
    uniq: u64,

    /// The timestamp when this client was created (human-readable for logging).
    created_at: String,

    /// The instant when this client was created (for TTL checking).
    created_instant: Instant,
}

impl fmt::Display for EstablishedClient {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "EstablishedClient[uniq={}, {}]{{ target: {}, server_version: {}, endpoints: {} }}",
            self.uniq,
            self.created_at,
            self.target_endpoint,
            self.server_protocol_version,
            self.endpoints_string
        )
    }
}

impl EstablishedClient {
    pub(crate) fn new(
        client: MetaServiceClient<InterceptedService<Channel, AuthInterceptor>>,
        server_protocol_version: u64,
        target_endpoint: impl ToString,
        endpoints: Arc<Mutex<Endpoints>>,
    ) -> Self {
        // Generate a unique identifier for the client.
        static UNIQ_COUNTER: AtomicU64 = AtomicU64::new(0);
        let uniq = UNIQ_COUNTER.fetch_add(1, Ordering::Relaxed);

        // Get current timestamp in human-readable string
        let utc_time = Utc::now();
        let created_at = utc_time.format("%Y-%m-%d-%H:%M:%S-UTC").to_string();
        let created_instant = Instant::now();

        let endpoints_string = format!("{}", &*endpoints.lock());

        let client = Self {
            client,
            server_protocol_version,
            target_endpoint: target_endpoint.to_string(),
            endpoints,
            endpoints_string,
            error: Arc::new(Mutex::new(None)),
            uniq,
            created_at,
            created_instant,
        };

        debug!("Created: {client}");
        client
    }

    pub fn target_endpoint(&self) -> &str {
        &self.target_endpoint
    }

    pub fn endpoints(&self) -> &Arc<Mutex<Endpoints>> {
        &self.endpoints
    }

    pub fn server_protocol_version(&self) -> u64 {
        self.server_protocol_version
    }

    pub(crate) fn set_error(&self, error: Status) {
        *self.error.lock() = Some(error);
    }

    /// Check if this client has exceeded its TTL (time-to-live).
    ///
    /// Returns `true` if the client has been alive longer than the specified TTL.
    /// This is used to force reconnection periodically to prevent h2 stream reset
    /// accumulation that can lead to `too_many_internal_resets` errors.
    pub(crate) fn is_expired(&self, ttl: Duration) -> bool {
        self.created_instant.elapsed() > ttl
    }

    /// Try to update the current endpoint to the leader.
    fn try_set_leader(&self, leader: &Endpoint, ctx: &str) {
        info!(
            "{self} update_client: received leader({leader}) from {ctx}, endpoints: {}",
            &*self.endpoints.lock(),
        );

        let mut endpoints = self.endpoints.lock();
        match endpoints.set_current(Some(leader.to_string())) {
            Ok(prev) => {
                info!(
                    "{self} update_client: switched to leader({leader}), previous: {}",
                    prev.display()
                );
            }
            Err(e) => {
                error!("{self} update_client: failed to set leader({leader}): {e}");
            }
        }
    }

    pub(crate) fn take_error(&self) -> Option<Status> {
        self.error.lock().take()
    }

    /// A shortcut to [`rotate_failing_endpoint`]
    pub(crate) fn rotate_failing_target(&self) {
        rotate_failing_endpoint(&self.endpoints, Some(self.target_endpoint()), self);
    }

    #[async_backtrace::framed]
    pub async fn kv_api(
        &mut self,
        request: impl tonic::IntoRequest<RaftRequest>,
    ) -> Result<Response<RaftReply>, Status> {
        self.client.kv_api(request).await.update_client(self)
    }

    #[async_backtrace::framed]
    pub async fn kv_read_v1(
        &mut self,
        request: impl tonic::IntoRequest<RaftRequest>,
    ) -> Result<Response<Streaming<StreamItem>>, Status> {
        let resp = self.client.kv_read_v1(request).await;
        resp.update_client(self)
    }

    #[async_backtrace::framed]
    pub async fn kv_list(
        &mut self,
        request: impl tonic::IntoRequest<KvListRequest>,
    ) -> Result<Response<Streaming<StreamItem>>, Status> {
        self.client.kv_list(request).await.update_client(self)
    }

    #[async_backtrace::framed]
    pub async fn kv_get_many(
        &mut self,
        request: impl tonic::IntoStreamingRequest<Message = KvGetManyRequest>,
    ) -> Result<Response<Streaming<StreamItem>>, Status> {
        self.client.kv_get_many(request).await.update_client(self)
    }

    #[async_backtrace::framed]
    pub async fn export(
        &mut self,
        request: impl tonic::IntoRequest<Empty>,
    ) -> Result<Response<Streaming<ExportedChunk>>, Status> {
        self.client.export(request).await.update_client(self)
    }

    #[async_backtrace::framed]
    pub async fn export_v1(
        &mut self,
        request: impl tonic::IntoRequest<pb::ExportRequest>,
    ) -> Result<Response<Streaming<ExportedChunk>>, Status> {
        self.client.export_v1(request).await.update_client(self)
    }

    #[async_backtrace::framed]
    pub async fn snapshot_keys_layout(
        &mut self,
        request: impl tonic::IntoRequest<KeysLayoutRequest>,
    ) -> Result<Response<Streaming<KeysCount>>, Status> {
        self.client
            .snapshot_keys_layout(request)
            .await
            .update_client(self)
    }

    #[async_backtrace::framed]
    pub async fn watch(
        &mut self,
        request: impl tonic::IntoRequest<WatchRequest>,
    ) -> Result<Response<Streaming<WatchResponse>>, Status> {
        self.client.watch(request).await.update_client(self)
    }

    #[async_backtrace::framed]
    pub async fn transaction(
        &mut self,
        request: impl tonic::IntoRequest<TxnRequest>,
    ) -> Result<Response<TxnReply>, Status> {
        self.client.transaction(request).await.update_client(self)
    }

    #[async_backtrace::framed]
    pub async fn kv_transaction(
        &mut self,
        request: impl tonic::IntoRequest<pb::KvTransactionRequest>,
    ) -> Result<Response<pb::KvTransactionReply>, Status> {
        self.client
            .kv_transaction(request)
            .await
            .update_client(self)
    }

    #[async_backtrace::framed]
    pub async fn member_list(
        &mut self,
        request: impl tonic::IntoRequest<MemberListRequest>,
    ) -> Result<Response<MemberListReply>, Status> {
        self.client.member_list(request).await.update_client(self)
    }

    #[async_backtrace::framed]
    pub async fn get_cluster_status(
        &mut self,
        request: impl tonic::IntoRequest<Empty>,
    ) -> Result<Response<ClusterStatus>, Status> {
        self.client
            .get_cluster_status(request)
            .await
            .update_client(self)
    }

    #[async_backtrace::framed]
    pub async fn get_client_info(
        &mut self,
        request: impl tonic::IntoRequest<Empty>,
    ) -> Result<Response<ClientInfo>, Status> {
        self.client
            .get_client_info(request)
            .await
            .update_client(self)
    }
}
