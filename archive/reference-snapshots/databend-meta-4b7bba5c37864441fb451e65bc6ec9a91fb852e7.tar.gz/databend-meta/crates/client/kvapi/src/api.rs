// Copyright 2021 Datafuse Labs
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use std::ops::Deref;

use async_trait::async_trait;
use futures_util::Stream;
use futures_util::StreamExt;
use futures_util::stream::BoxStream;

use crate as kvapi;
use crate::ListOptions;
use crate::types::TxnReply;
use crate::types::TxnRequest;
use crate::types::errors;
use crate::types::pb::StreamItem;

/// Build an API impl instance or a cluster of API impl
#[async_trait]
pub trait ApiBuilder<T>: Clone {
    /// Create a single node impl
    async fn build(&self) -> T;

    /// Create a cluster of T
    async fn build_cluster(&self) -> Vec<T>;
}

/// A stream of key-value records that are returned by stream based API such as mget and list.
pub type KVStream<E> = BoxStream<'static, Result<StreamItem, E>>;

/// Apply an optional limit to a stream, returning a boxed stream.
pub fn limit_stream<S, E>(strm: S, limit: Option<u64>) -> KVStream<E>
where S: Stream<Item = Result<StreamItem, E>> + Send + 'static {
    match limit {
        Some(n) => strm.take(n as usize).boxed(),
        None => strm.boxed(),
    }
}

/// Wrap a stream to stop yielding after the first error (fail-fast).
///
/// Returns a stream that yields items until an error is encountered.
/// The error is yielded, then the stream terminates immediately.
pub fn fail_fast<S, T, E>(strm: S) -> impl Stream<Item = Result<T, E>>
where S: Stream<Item = Result<T, E>> {
    strm.scan(false, |stop, item| {
        std::future::ready(if *stop {
            None
        } else {
            *stop = item.is_err();
            Some(item)
        })
    })
}

/// API of a key-value store.
#[async_trait]
pub trait KVApi: Send + Sync {
    /// The Error an implementation returns.
    ///
    /// Depends on the implementation the error could be different.
    /// E.g., a remove kvapi::KVApi impl returns network error or remote storage error.
    /// A local kvapi::KVApi impl just returns storage error.
    type Error: std::error::Error
        + From<errors::IncompleteStream>
        + From<errors::InvalidReply>
        + Send
        + Sync
        + 'static;

    /// Get key-values by streaming keys.
    ///
    /// Processes keys lazily as they arrive from the input stream.
    /// The input stream may contain errors; when an error is encountered,
    /// it is propagated to the output stream.
    ///
    /// Implementations are **not** required to retry internally.
    /// Because the input is a stream that may not be cloneable or replayable,
    /// the caller should handle errors by re-creating the request.
    ///
    /// The input uses `BoxStream` instead of `impl Stream` to keep the trait dyn-compatible,
    /// allowing usage as `dyn KVApi`.
    async fn get_many_kv(
        &self,
        keys: BoxStream<'static, Result<String, Self::Error>>,
    ) -> Result<KVStream<Self::Error>, Self::Error>;

    /// List key-value records that are starts with the specified prefix.
    ///
    /// Same as `prefix_list_kv()`, except it returns a stream.
    /// If `limit` is `Some(n)`, at most `n` records will be returned.
    async fn list_kv(
        &self,
        opts: ListOptions<'_, str>,
    ) -> Result<KVStream<Self::Error>, Self::Error>;

    /// Run transaction: update one or more records if specified conditions are met.
    async fn transaction(&self, txn: TxnRequest) -> Result<TxnReply, Self::Error>;
}

#[async_trait]
impl<U: kvapi::KVApi, T: Deref<Target = U> + Send + Sync> kvapi::KVApi for T {
    type Error = U::Error;

    async fn get_many_kv(
        &self,
        keys: BoxStream<'static, Result<String, Self::Error>>,
    ) -> Result<KVStream<Self::Error>, Self::Error> {
        self.deref().get_many_kv(keys).await
    }

    async fn list_kv(
        &self,
        opts: ListOptions<'_, str>,
    ) -> Result<KVStream<Self::Error>, Self::Error> {
        self.deref().list_kv(opts).await
    }

    async fn transaction(&self, txn: TxnRequest) -> Result<TxnReply, Self::Error> {
        self.deref().transaction(txn).await
    }
}
