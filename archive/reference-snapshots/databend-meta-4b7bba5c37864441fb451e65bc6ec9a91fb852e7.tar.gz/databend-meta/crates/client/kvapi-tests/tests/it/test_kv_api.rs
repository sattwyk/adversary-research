// Copyright 2021 Datafuse Labs
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use databend_meta_kvapi_test_suite::TestSuite;
use databend_meta_runtime_api::TokioRuntime;
use databend_meta_test_harness::meta_service_test_harness;
use test_harness::test;

use crate::metasrv_builder::MetaSrvBuilder;

#[test(harness = meta_service_test_harness::<TokioRuntime, _, _>)]
#[fastrace::trace]
async fn test_kvapi_on_metasrv() -> anyhow::Result<()> {
    let builder = MetaSrvBuilder::new();
    TestSuite {}.test_all(builder).await
}
