// Copyright 2021 Datafuse Labs
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use std::time::Duration;
use std::time::SystemTime;

use databend_meta_kvapi as kvapi;
use databend_meta_kvapi::KvApiExt;
use databend_meta_kvapi::ListOptions;
use display_more::DisplayOptionExt;
use display_more::DisplaySliceExt;
use fastrace::func_name;
use fastrace::func_path;
use futures_util::TryStreamExt;
use log::debug;
use log::info;
use state_machine_api::KVMeta;
use tokio::time::sleep;

use crate::types::ConditionResult;
use crate::types::MatchSeq;
use crate::types::MetaSpec;
use crate::types::SeqV;
use crate::types::TxnCondition;
use crate::types::TxnDeleteByPrefixRequest;
use crate::types::TxnDeleteByPrefixResponse;
use crate::types::TxnDeleteRequest;
use crate::types::TxnDeleteResponse;
use crate::types::TxnGetRequest;
use crate::types::TxnGetResponse;
use crate::types::TxnOp;
use crate::types::TxnOpResponse;
use crate::types::TxnPutResponse;
use crate::types::TxnReply;
use crate::types::TxnRequest;
use crate::types::UpsertKV;
use crate::types::With;
use crate::types::normalize_meta::NormalizeMeta;
use crate::types::pb;
use crate::types::pb::BooleanExpression;
use crate::types::pb::FetchIncreaseU64Response;
use crate::types::pb::KvMeta;
use crate::types::txn_condition;
use crate::types::txn_op;
use crate::types::txn_op_response;
use crate::types::txn_op_response::Response;

pub struct TestSuite {}

impl TestSuite {
    pub async fn test_all<KV, B>(&self, builder: B) -> anyhow::Result<()>
    where
        KV: kvapi::KVApi,
        B: kvapi::ApiBuilder<KV>,
    {
        self.test_single_node(&builder).await?;

        // Run cross node test on every 2 adjacent nodes
        let mut i = 0;
        loop {
            let cluster = builder.build_cluster().await;
            self.kv_write_read_across_nodes(&cluster[i], &cluster[i + 1])
                .await?;

            if i + 1 == cluster.len() - 1 {
                break;
            }
            i += 1;
        }

        Ok(())
    }

    pub async fn test_single_node<KV, B>(&self, builder: &B) -> anyhow::Result<()>
    where
        KV: kvapi::KVApi,
        B: kvapi::ApiBuilder<KV>,
    {
        self.kv_timeout(&builder.build().await).await?;
        self.kv_expire_sec_or_ms(&builder.build().await).await?;
        self.kv_list(&builder.build().await).await?;
        self.kv_list_with_limit(&builder.build().await).await?;
        self.kv_list_collect_with_limit(&builder.build().await)
            .await?;
        self.kv_mget(&builder.build().await).await?;
        self.kv_get_many_kv(&builder.build().await).await?;
        self.kv_get_many_kv_error_propagation(&builder.build().await)
            .await?;

        self.kv_txn_absent_seq_0(&builder.build().await).await?;
        self.kv_transaction(&builder.build().await).await?;
        self.kv_transaction_proposed_at(&builder.build().await)
            .await?;
        self.kv_transaction_fetch_add_u64(&builder.build().await)
            .await?;
        self.kv_transaction_fetch_add_u64_match_seq(&builder.build().await)
            .await?;
        self.kv_transaction_fetch_increase_u64_max_value(&builder.build().await)
            .await?;
        self.kv_transaction_condition_ne(&builder.build().await)
            .await?;
        self.kv_txn_put_sequential(&builder.build().await).await?;
        self.kv_txn_put_sequential_expire_and_ttl(&builder.build().await)
            .await?;
        self.kv_transaction_with_ttl(&builder.build().await).await?;
        self.kv_transaction_put_expire_at(&builder.build().await)
            .await?;
        self.kv_transaction_delete_match_seq_none(&builder.build().await)
            .await?;
        self.kv_transaction_condition_keys_with_prefix(&builder.build().await)
            .await?;
        self.kv_transaction_complex_conditions(&builder.build().await)
            .await?;
        self.kv_transaction_delete_match_seq_some_not_match(&builder.build().await)
            .await?;
        self.kv_transaction_delete_match_seq_some_match(&builder.build().await)
            .await?;
        self.kv_delete_by_prefix_transaction(&builder.build().await)
            .await?;

        Ok(())
    }
}

impl TestSuite {
    pub async fn kv_timeout<KV: kvapi::KVApi>(&self, kv: &KV) -> anyhow::Result<()> {
        info!("--- {} start", func_name!());

        // - Test get  expired and non-expired.
        // - Test mget expired and non-expired.
        // - Test list expired and non-expired.
        // - Test update with a new expire value.

        let _res = kv
            .upsert_kv(
                UpsertKV::update("k1", b"v1").with(MetaSpec::new_ttl(Duration::from_secs(2))),
            )
            .await?;
        // dbg!("upsert non expired k1", _res);

        info!("---get unexpired");
        {
            let res = kv.get_kv("k1").await?;
            // dbg!("got k1:{:?}", &res);
            // dbg!("got non expired k1", &res);
            assert!(res.is_some(), "got unexpired");
        }

        info!("---get expired");
        {
            tokio::time::sleep(Duration::from_millis(3000)).await;
            let res = kv.get_kv("k1").await?;
            // dbg!("k1 expired", &res);
            debug!("got k1:{:?}", res);
            assert!(res.is_none(), "got expired");
        }

        let now_sec = since_epoch_secs();

        info!("--- expired entry act as if it does not exist, an ADD op should apply");
        {
            // dbg!("start upsert expired k1");
            let _res = kv
                .upsert_kv(
                    UpsertKV::update("k1", b"v1")
                        .with(MatchSeq::Exact(0))
                        .with(MetaSpec::new_expire(now_sec - 1)),
                )
                .await?;
            // dbg!("update on expired k1", _res);

            let _res = kv
                .upsert_kv(
                    UpsertKV::update("k2", b"v2")
                        .with(MatchSeq::Exact(0))
                        .with(MetaSpec::new_ttl(Duration::from_secs(10))),
                )
                .await?;
            // dbg!("update non expired k2", _res);

            info!("--- mget should not return expired");
            {
                // let got = kv.get_kv("k1").await?;
                // dbg!("k1", got);
                // let got = kv.get_kv("k2").await?;
                // dbg!("k2", got);

                let mut res = kv.mget_kv(&["k1".to_string(), "k2".to_string()]).await?;
                // dbg!(&res);
                assert_eq!(res[0], None);

                let v2 = res.remove(1).unwrap();
                assert_eq!(v2.seq, 3);
                assert_eq!(v2.data, b("v2"));
                let v2_meta = v2.meta.unwrap();
                let expire_at_sec = v2_meta.expires_at_sec_opt().unwrap();
                let want = now_sec + 10;
                assert!((want..want + 2).contains(&expire_at_sec));
            }
        }

        info!("--- list should not return expired");
        {
            let res = kv.list_kv_collect(ListOptions::unlimited("k")).await?;
            let res_vec = res.iter().map(|(key, _)| key.clone()).collect::<Vec<_>>();

            assert_eq!(res_vec, vec!["k2".to_string(),]);
        }

        info!("--- update expire");
        {
            kv.upsert_kv(
                UpsertKV::update("k2", b"v2")
                    .with(MatchSeq::Exact(3))
                    .with(MetaSpec::new_expire(now_sec - 1)),
            )
            .await?;

            let res = kv.get_kv("k2").await?;
            assert!(res.is_none(), "k2 expired");
        }

        Ok(())
    }

    /// Test expire time in seconds or milliseconds.
    pub async fn kv_expire_sec_or_ms<KV: kvapi::KVApi>(&self, kv: &KV) -> anyhow::Result<()> {
        info!("--- {} start", func_name!());

        // 100_000_000_000 is the max value in seconds.
        kv.upsert_kv(UpsertKV::update("k1", b"v1").with(MetaSpec::new_expire(100_000_000_000)))
            .await?;
        // dbg!("upsert non expired k1", _res);

        info!("--- get unexpired");
        {
            let res = kv.get_kv("k1").await?;
            let meta = res.unwrap().meta.unwrap();
            assert_eq!(meta.expires_at_sec_opt(), Some(100_000_000_000));
        }

        info!("--- expired in milliseconds");
        {
            let now_sec = since_epoch_secs();

            // expire time in milliseconds
            kv.upsert_kv(
                UpsertKV::update("k1", b"v1").with(MetaSpec::new_expire((now_sec - 2) * 1000)),
            )
            .await?;

            let res = kv.get_kv("k1").await?;
            assert!(res.is_none(), "expired");
        }

        info!("--- unexpired in milliseconds");
        {
            // 2035-01-04 18:12:23
            let millis = 2051518343000;

            // expire time in milliseconds
            kv.upsert_kv(UpsertKV::update("k1", b"v1").with(MetaSpec::new_expire(millis)))
                .await?;

            let res = kv.get_kv("k1").await?;
            let meta = res.unwrap().meta.unwrap();
            assert_eq!(meta.get_expire_at_ms(), Some(millis));
        }

        info!("--- ttl in milliseconds: 1 sec");
        {
            kv.upsert_kv(
                UpsertKV::update("k1", b"v1").with(MetaSpec::new_ttl(Duration::from_secs(1))),
            )
            .await?;

            sleep(Duration::from_millis(2_000)).await;

            let res = kv.get_kv("k1").await?;
            assert!(res.is_none());
        }

        info!("--- ttl in milliseconds: 5 sec");
        {
            kv.upsert_kv(
                UpsertKV::update("k1", b"v1").with(MetaSpec::new_ttl(Duration::from_secs(5))),
            )
            .await?;

            sleep(Duration::from_millis(2_000)).await;

            let res = kv.get_kv("k1").await?;
            assert!(res.is_some());
        }

        Ok(())
    }

    pub async fn kv_list<KV: kvapi::KVApi>(&self, kv: &KV) -> anyhow::Result<()> {
        info!("--- kvapi::KVApiTestSuite::kv_list() start");

        let mut values = vec![];
        {
            kv.upsert_kv(UpsertKV::update("t", b"")).await?;

            for i in 0..9 {
                let key = format!("__users/{}", i);
                let val = format!("val_{}", i);
                values.push(val.clone());
                kv.upsert_kv(UpsertKV::update(&key, val.as_bytes())).await?;
            }
            kv.upsert_kv(UpsertKV::update("v", b"")).await?;
        }

        let res = kv
            .list_kv_collect(ListOptions::unlimited("__users/"))
            .await?;
        assert_eq!(
            res.iter()
                .map(|(_key, val)| val.data.clone())
                .collect::<Vec<_>>(),
            values
                .iter()
                .map(|v| v.as_bytes().to_vec())
                .collect::<Vec<_>>()
        );
        Ok(())
    }

    /// Test `list_kv` with limit parameter
    pub async fn kv_list_with_limit<KV: kvapi::KVApi>(&self, kv: &KV) -> anyhow::Result<()> {
        info!("--- kvapi::KVApiTestSuite::kv_list_with_limit() start");

        // Insert 5 keys
        for i in 0..5 {
            let key = format!("__limit_test/{}", i);
            let val = format!("val_{}", i);
            kv.upsert_kv(UpsertKV::update(&key, val.as_bytes())).await?;
        }

        // List all with no limit
        let strm = kv.list_kv(ListOptions::unlimited("__limit_test/")).await?;
        let res: Vec<_> = strm.map_ok(|item| item.key).try_collect().await?;
        assert_eq!(res, vec![
            "__limit_test/0",
            "__limit_test/1",
            "__limit_test/2",
            "__limit_test/3",
            "__limit_test/4",
        ]);

        // List with limit 3
        let strm = kv.list_kv(ListOptions::limited("__limit_test/", 3)).await?;
        let res: Vec<_> = strm.map_ok(|item| item.key).try_collect().await?;
        assert_eq!(res, vec![
            "__limit_test/0",
            "__limit_test/1",
            "__limit_test/2",
        ]);

        // List with limit 0
        let strm = kv.list_kv(ListOptions::limited("__limit_test/", 0)).await?;
        let res: Vec<_> = strm.map_ok(|item| item.key).try_collect().await?;
        assert_eq!(res, Vec::<String>::new());

        // List with limit larger than result set
        let strm = kv
            .list_kv(ListOptions::limited("__limit_test/", 100))
            .await?;
        let res: Vec<_> = strm.map_ok(|item| item.key).try_collect().await?;
        assert_eq!(res, vec![
            "__limit_test/0",
            "__limit_test/1",
            "__limit_test/2",
            "__limit_test/3",
            "__limit_test/4",
        ]);

        Ok(())
    }

    /// Test `list_kv_collect` with limit parameter
    pub async fn kv_list_collect_with_limit<KV: kvapi::KVApi>(
        &self,
        kv: &KV,
    ) -> anyhow::Result<()> {
        info!("--- kvapi::KVApiTestSuite::kv_list_collect_with_limit() start");

        // Insert 5 keys
        for i in 0..5 {
            let key = format!("__collect_limit/{}", i);
            let val = format!("val_{}", i);
            kv.upsert_kv(UpsertKV::update(&key, val.as_bytes())).await?;
        }

        // List all with no limit
        let res = kv
            .list_kv_collect(ListOptions::unlimited("__collect_limit/"))
            .await?;
        let keys: Vec<_> = res.iter().map(|(k, _)| k.as_str()).collect();
        assert_eq!(keys, vec![
            "__collect_limit/0",
            "__collect_limit/1",
            "__collect_limit/2",
            "__collect_limit/3",
            "__collect_limit/4",
        ]);

        // List with limit 3
        let res = kv
            .list_kv_collect(ListOptions::limited("__collect_limit/", 3))
            .await?;
        let keys: Vec<_> = res.iter().map(|(k, _)| k.as_str()).collect();
        assert_eq!(keys, vec![
            "__collect_limit/0",
            "__collect_limit/1",
            "__collect_limit/2",
        ]);

        // List with limit 0
        let res = kv
            .list_kv_collect(ListOptions::limited("__collect_limit/", 0))
            .await?;
        assert_eq!(res, vec![]);

        Ok(())
    }

    pub async fn kv_mget<KV: kvapi::KVApi>(&self, kv: &KV) -> anyhow::Result<()> {
        info!("--- kvapi::KVApiTestSuite::kv_mget() start");

        kv.upsert_kv(UpsertKV::update("k1", b"v1")).await?;
        kv.upsert_kv(UpsertKV::update("k2", b"v2")).await?;

        let res = kv.mget_kv(&["k1".to_string(), "k2".to_string()]).await?;
        assert_eq!(res.without_proposed_at(), vec![
            Some(SeqV::new(1, b("v1"),)),
            // NOTE, the sequence number is increased globally (inside the namespace of generic kv)
            Some(SeqV::new(2, b("v2"),)),
        ]);

        let res = kv
            .mget_kv(&["k1".to_string(), "key_no exist".to_string()])
            .await?;
        assert_eq!(res.without_proposed_at(), vec![
            Some(SeqV::new(1, b("v1"))),
            None
        ]);

        Ok(())
    }

    /// Test that `get_many_kv` returns keys and values correctly in the output stream.
    pub async fn kv_get_many_kv<KV: kvapi::KVApi>(&self, kv: &KV) -> anyhow::Result<()> {
        use futures_util::StreamExt;

        info!("--- kvapi::KVApiTestSuite::kv_get_many_kv() start");

        // Insert test data
        kv.upsert_kv(UpsertKV::update("keys_k1", b"v1")).await?;
        kv.upsert_kv(UpsertKV::update("keys_k2", b"v2")).await?;

        // Create input stream with keys
        let input: Vec<Result<String, KV::Error>> = vec![
            Ok("keys_k1".to_string()),
            Ok("keys_k2".to_string()),
            Ok("keys_nonexistent".to_string()),
        ];
        let input_stream = futures_util::stream::iter(input);

        // Call get_many_kv
        let output_stream = kv.get_many_kv(input_stream.boxed()).await?;
        let results: Vec<_> = output_stream
            .map(|r| {
                let item = r.unwrap();
                (item.key, item.value.map(|v| v.data))
            })
            .collect()
            .await;

        assert_eq!(results, vec![
            ("keys_k1".to_string(), Some(b("v1"))),
            ("keys_k2".to_string(), Some(b("v2"))),
            ("keys_nonexistent".to_string(), None),
        ]);

        Ok(())
    }

    /// Test that `get_many_kv` propagates errors from the input stream and stops immediately.
    ///
    /// When an error is encountered in the input stream, the output stream should:
    /// 1. Return all items processed before the error
    /// 2. Return the error
    /// 3. Terminate immediately (no more items after the error)
    pub async fn kv_get_many_kv_error_propagation<KV: kvapi::KVApi>(
        &self,
        kv: &KV,
    ) -> anyhow::Result<()> {
        use databend_meta_kvapi::KVStream;
        use futures_util::StreamExt;

        use crate::types::errors::IncompleteStream;

        info!("--- kvapi::KVApiTestSuite::kv_get_many_kv_error_propagation() start");

        // Insert some test data
        kv.upsert_kv(UpsertKV::update("err_k1", b"v1")).await?;
        kv.upsert_kv(UpsertKV::update("err_k2", b"v2")).await?;

        // Create input stream: k1, error, k2
        // KV::Error has bound `From<IncompleteStream>`, so we can use `.into()`
        let input: Vec<Result<String, KV::Error>> = vec![
            Ok("err_k1".to_string()),
            Err(IncompleteStream::new(10, 5)
                .context("simulated input error")
                .into()),
            Ok("err_k2".to_string()),
        ];
        let input_stream = futures_util::stream::iter(input);

        // Call get_many_kv with the error-containing stream
        let output_stream: KVStream<KV::Error> = kv.get_many_kv(input_stream.boxed()).await?;
        let results: Vec<_> = output_stream.collect().await;

        // Verify: should have exactly 2 items - Ok(k1), then Err(...)
        // Stream terminates immediately after error (fail-fast), k2 is never processed
        assert_eq!(
            results.len(),
            2,
            "stream should terminate after error, got {} items",
            results.len()
        );

        // First item should be Ok with k1's value
        assert!(results[0].is_ok(), "first item should be Ok");
        let item0 = results[0].as_ref().unwrap();
        assert_eq!(item0.key, "err_k1");

        // Second item should be the propagated error, then stream ends
        assert!(
            results[1].is_err(),
            "second item should be error propagated from input"
        );
        let err = results[1].as_ref().unwrap_err();
        let err_str = err.to_string();
        assert!(
            err_str.contains("simulated input error"),
            "error should contain our message, got: {}",
            err_str
        );

        Ok(())
    }

    fn check_transaction_responses(
        &self,
        reply: &TxnReply,
        expected: &[TxnOpResponse],
        success: bool,
    ) {
        assert_eq!(reply.success, success);
        let responses = &reply.responses;
        assert_eq!(responses.len(), expected.len());

        let responses = normalize_txn_response(responses.clone());
        let expected = normalize_txn_response(expected.to_vec());

        for i in 0..responses.len() {
            let resp = &responses[i];

            let expect_resp = &expected[i];

            assert_eq!(resp, expect_resp, "{}-th response", i);
        }
    }

    pub async fn kv_txn_absent_seq_0<KV: kvapi::KVApi>(&self, kv: &KV) -> anyhow::Result<()> {
        info!("--- Absent record should has seq as 0");

        let k1 = "txn_0_absent";

        let txn_key = k1.to_string();
        let conditions = vec![TxnCondition {
            key: txn_key.clone(),
            expected: ConditionResult::Eq as i32,
            target: Some(txn_condition::Target::Seq(0)),
        }];

        let if_then: Vec<TxnOp> = vec![TxnOp::put(txn_key.clone(), b("new_v1"))];

        let txn = TxnRequest::new(conditions, if_then);

        let resp = kv.transaction(txn).await?;

        let expected: Vec<TxnOpResponse> = vec![TxnOpResponse {
            response: Some(txn_op_response::Response::Put(TxnPutResponse {
                key: txn_key.clone(),
                prev_value: None,
                current: Some(pb::SeqV::new(1, b"new_v1".to_vec())),
            })),
        }];

        self.check_transaction_responses(&resp, &expected, true);

        Ok(())
    }

    pub async fn kv_delete_by_prefix_transaction<KV: kvapi::KVApi>(
        &self,
        kv: &KV,
    ) -> anyhow::Result<()> {
        info!("--- kvapi::KVApiTestSuite::kv_delete_by_prefix_transaction() start");
        let test_prefix = "test";

        let match_keys = vec![
            format!("{}_key1", test_prefix),
            format!("{}/key2", test_prefix),
            format!("{}key3", test_prefix),
        ];

        let unmatch_keys = vec!["teskey4".to_string()];

        for key in [match_keys.clone(), unmatch_keys.clone()].concat().iter() {
            kv.upsert_kv(UpsertKV::update(key, b"v1")).await?;

            let current = kv.get_kv(key).await?;
            assert!(current.is_some());
        }

        // test again with if condition
        {
            let txn_key = unmatch_keys.first().unwrap().to_string();
            let condition = vec![TxnCondition {
                key: txn_key.clone(),
                expected: ConditionResult::Gt as i32,
                target: Some(txn_condition::Target::Seq(0)),
            }];

            let if_then: Vec<TxnOp> = vec![TxnOp {
                request: Some(txn_op::Request::DeleteByPrefix(TxnDeleteByPrefixRequest {
                    prefix: test_prefix.to_string(),
                })),
            }];

            let txn = TxnRequest::new(condition, if_then);

            let resp = kv.transaction(txn).await?;

            let expected: Vec<TxnOpResponse> = vec![TxnOpResponse {
                response: Some(txn_op_response::Response::DeleteByPrefix(
                    TxnDeleteByPrefixResponse {
                        prefix: test_prefix.to_string(),
                        count: match_keys.len() as u32,
                    },
                )),
            }];

            self.check_transaction_responses(&resp, &expected, true);

            for key in match_keys.iter() {
                let current = kv.get_kv(key).await?;
                assert!(current.is_none());
            }
            for key in unmatch_keys.iter() {
                let current = kv.get_kv(key).await?;
                assert!(current.is_some());
            }
        }

        // test again with else condition
        {
            let txn_key = "unmatch_keys".to_string();
            let unmatch_prefix = unmatch_keys.first().unwrap().to_string();
            let condition = vec![TxnCondition {
                key: txn_key.clone(),
                expected: ConditionResult::Gt as i32,
                target: Some(txn_condition::Target::Seq(0)),
            }];

            let else_then: Vec<TxnOp> = vec![TxnOp {
                request: Some(txn_op::Request::DeleteByPrefix(TxnDeleteByPrefixRequest {
                    prefix: unmatch_prefix.clone(),
                })),
            }];
            let txn = TxnRequest::new(condition, vec![]).with_else(else_then);

            let resp = kv.transaction(txn).await?;

            let expected: Vec<TxnOpResponse> = vec![TxnOpResponse {
                response: Some(txn_op_response::Response::DeleteByPrefix(
                    TxnDeleteByPrefixResponse {
                        prefix: unmatch_prefix.to_string(),
                        count: unmatch_keys.len() as u32,
                    },
                )),
            }];

            self.check_transaction_responses(&resp, &expected, false);

            for key in unmatch_keys.iter() {
                let current = kv.get_kv(key).await?;
                assert!(current.is_none());
            }
        }

        Ok(())
    }

    #[allow(clippy::bool_assert_comparison)]
    pub async fn kv_transaction<KV: kvapi::KVApi>(&self, kv: &KV) -> anyhow::Result<()> {
        info!("--- kvapi::KVApiTestSuite::kv_transaction() start");
        // first case: get and set one key transaction
        {
            let k1 = "txn_1_K1";
            let val1 = b("v1");

            // first insert k1 value
            kv.upsert_kv(UpsertKV::update(k1, &val1)).await?;

            // transaction by k1 condition
            let txn_key = k1.to_string();
            let condition = vec![TxnCondition {
                key: txn_key.clone(),
                expected: ConditionResult::Gt as i32,
                target: Some(txn_condition::Target::Seq(0)),
            }];

            let if_then: Vec<TxnOp> = vec![TxnOp::put(txn_key.clone(), b("new_v1"))];

            let txn = TxnRequest::new(condition, if_then);

            let resp = kv.transaction(txn).await?;

            let expected: Vec<TxnOpResponse> = vec![TxnOpResponse {
                response: Some(txn_op_response::Response::Put(TxnPutResponse {
                    key: txn_key.clone(),
                    prev_value: Some(pb::SeqV::from(SeqV::new(1, val1.clone()))),
                    current: Some(pb::SeqV::new(2, b("new_v1"))),
                })),
            }];

            self.check_transaction_responses(&resp, &expected, true);
        }
        // second case: get two key(one not exist) and set one key transaction
        {
            // first insert k1 value
            let k1 = "txn_2_K1";
            let k2 = "txn_2_K2";

            kv.upsert_kv(UpsertKV::update(k1, b"v1")).await?;

            // transaction by k1 and k2 condition
            let txn_key1 = k1.to_string();
            let txn_key2 = k2.to_string();

            let condition = vec![
                TxnCondition {
                    key: txn_key1.clone(),
                    expected: ConditionResult::Gt as i32,
                    target: Some(txn_condition::Target::Seq(0)),
                },
                TxnCondition {
                    key: txn_key2.clone(),
                    expected: ConditionResult::Gt as i32,
                    target: Some(txn_condition::Target::Seq(0)),
                },
            ];

            let if_then: Vec<TxnOp> = vec![TxnOp::put(txn_key1.clone(), b("new_v1"))];

            let txn = TxnRequest::new(condition, if_then);

            let resp = kv.transaction(txn).await?;

            // k2 not exists, so the resp MUST return false
            assert!(!resp.success);
            assert_eq!(resp.responses.len(), 0);
        }

        // 3rd case: get two key and set both key transaction
        {
            let k1 = "txn_3_K1";
            let val1 = b("v1");
            let val1_new = b("v1_new");

            let k2 = "txn_3_K2";
            let val2 = b("v1");

            // first insert k1 and k2 value
            kv.upsert_kv(UpsertKV::update(k1, &val1)).await?;
            kv.upsert_kv(UpsertKV::update(k2, &val2)).await?;

            // transaction by k1 and k2 condition
            let txn_key1 = k1.to_string();
            let txn_key2 = k2.to_string();

            let condition = vec![
                TxnCondition {
                    key: txn_key1.clone(),
                    expected: ConditionResult::Gt as i32,
                    target: Some(txn_condition::Target::Seq(0)),
                },
                TxnCondition {
                    key: txn_key2.clone(),
                    expected: ConditionResult::Gt as i32,
                    target: Some(txn_condition::Target::Seq(0)),
                },
            ];

            let if_then: Vec<TxnOp> = vec![
                // change k1
                TxnOp::put(txn_key1.clone(), val1_new.clone()),
                // change k2
                TxnOp::put(txn_key2.clone(), b("new_v2")),
                // get k1
                TxnOp {
                    request: Some(txn_op::Request::Get(TxnGetRequest::new(txn_key1.clone()))),
                },
                // delete k1
                TxnOp {
                    request: Some(txn_op::Request::Delete(TxnDeleteRequest::new(
                        txn_key1.clone(),
                        None,
                    ))),
                },
                // get k1
                TxnOp {
                    request: Some(txn_op::Request::Get(TxnGetRequest::new(txn_key1.clone()))),
                },
            ];

            let txn = TxnRequest::new(condition, if_then);

            let resp = kv.transaction(txn).await?;

            let expected: Vec<TxnOpResponse> = vec![
                // change k1
                TxnOpResponse {
                    response: Some(txn_op_response::Response::Put(TxnPutResponse {
                        key: txn_key1.clone(),
                        prev_value: Some(pb::SeqV::new(4, val1.clone())),
                        current: Some(pb::SeqV::new(6, val1_new.clone())),
                    })),
                },
                // change k2
                TxnOpResponse {
                    response: Some(txn_op_response::Response::Put(TxnPutResponse {
                        key: txn_key2.clone(),
                        prev_value: Some(pb::SeqV::new(5, val2.clone())),
                        current: Some(pb::SeqV::new(7, b("new_v2").clone())),
                    })),
                },
                // get k1
                TxnOpResponse {
                    response: Some(txn_op_response::Response::Get(TxnGetResponse {
                        key: txn_key1.clone(),
                        value: Some(pb::SeqV::from(SeqV::new_with_meta(
                            6,
                            Some(KVMeta::default()),
                            val1_new.clone(),
                        ))),
                    })),
                },
                // delete k1
                TxnOpResponse {
                    response: Some(txn_op_response::Response::Delete(TxnDeleteResponse {
                        key: txn_key1.clone(),
                        success: true,
                        prev_value: Some(pb::SeqV::from(SeqV::new_with_meta(
                            6,
                            Some(KVMeta::default()),
                            val1_new.clone(),
                        ))),
                    })),
                },
                // get k1
                TxnOpResponse {
                    response: Some(txn_op_response::Response::Get(TxnGetResponse {
                        key: txn_key1.clone(),
                        value: None,
                    })),
                },
            ];

            self.check_transaction_responses(&resp, &expected, true);
        }

        // 4th case: get one key by value and set key transaction
        {
            let k1 = "txn_4_K1";

            kv.upsert_kv(UpsertKV::update(k1, b"v1")).await?;

            // Test eq value: success = false

            let txn = TxnRequest::new(vec![TxnCondition::eq_value(k1, b("v10"))], vec![
                TxnOp::put(k1, b("v2")),
                TxnOp::get(k1),
            ])
            .with_else(vec![TxnOp::get(k1)]);

            let resp = kv.transaction(txn).await?;

            let expected: Vec<TxnOpResponse> =
                vec![TxnOpResponse::get(k1, Some(SeqV::new(8, b("v1"))))];

            assert_eq!(resp.success, false);
            assert_eq!(
                normalize_txn_response(resp.responses),
                normalize_txn_response(expected)
            );

            // Test eq value: success = true

            let txn = TxnRequest::new(vec![TxnCondition::eq_value(k1, b("v1"))], vec![
                TxnOp::put(k1, b("v2")),
                TxnOp::get(k1),
            ]);

            let resp = kv.transaction(txn).await?;

            let expected: Vec<TxnOpResponse> = vec![
                TxnOpResponse::put(
                    k1,
                    Some(pb::SeqV::new(8, b("v1"))),
                    Some(pb::SeqV::new(9, b("v2"))),
                ),
                TxnOpResponse::get(k1, Some(SeqV::new(9, b("v2")))),
            ];

            assert_eq!(resp.success, true);
            assert_eq!(
                normalize_txn_response(resp.responses),
                normalize_txn_response(expected)
            );

            // Test less than value: success = false

            let txn = TxnRequest::new(
                vec![TxnCondition::match_value(k1, ConditionResult::Lt, b("v2"))],
                vec![TxnOp::put(k1, b("v3")), TxnOp::get(k1)],
            )
            .with_else(vec![TxnOp::get(k1)]);

            let resp = kv.transaction(txn).await?;

            let expected: Vec<TxnOpResponse> =
                vec![TxnOpResponse::get(k1, Some(SeqV::new(9, b("v2"))))];

            assert_eq!(resp.success, false);
            assert_eq!(
                normalize_txn_response(resp.responses),
                normalize_txn_response(expected)
            );

            // Test less than value: success = true

            let txn = TxnRequest::new(
                vec![TxnCondition::match_value(k1, ConditionResult::Lt, b("v3"))],
                vec![TxnOp::put(k1, b("v3")), TxnOp::get(k1)],
            )
            .with_else(vec![TxnOp::get(k1)]);

            let resp = kv.transaction(txn).await?;

            let expected: Vec<TxnOpResponse> = vec![
                TxnOpResponse::put(
                    k1,
                    Some(pb::SeqV::new(9, b("v2"))),
                    Some(pb::SeqV::new(10, b("v3"))),
                ),
                TxnOpResponse::get(k1, Some(SeqV::new(10, b("v3")))),
            ];

            assert_eq!(resp.success, true);
            assert_eq!(
                normalize_txn_response(resp.responses),
                normalize_txn_response(expected)
            );

            // Test less equal value: success = false

            let txn = TxnRequest::new(
                vec![TxnCondition::match_value(k1, ConditionResult::Le, b("v0"))],
                vec![TxnOp::put(k1, b("v4")), TxnOp::get(k1)],
            )
            .with_else(vec![TxnOp::get(k1)]);

            let resp = kv.transaction(txn).await?;

            let expected: Vec<TxnOpResponse> =
                vec![TxnOpResponse::get(k1, Some(SeqV::new(10, b("v3"))))];

            assert_eq!(resp.success, false);
            assert_eq!(
                normalize_txn_response(resp.responses),
                normalize_txn_response(expected)
            );

            // Test less equal value: success = true

            let txn = TxnRequest::new(
                vec![TxnCondition::match_value(k1, ConditionResult::Le, b("v3"))],
                vec![TxnOp::put(k1, b("v4")), TxnOp::get(k1)],
            )
            .with_else(vec![TxnOp::get(k1)]);

            let resp = kv.transaction(txn).await?;

            let expected: Vec<TxnOpResponse> = vec![
                TxnOpResponse::put(
                    k1,
                    Some(pb::SeqV::new(10, b("v3"))),
                    Some(pb::SeqV::new(11, b("v4"))),
                ),
                TxnOpResponse::get(k1, Some(SeqV::new(11, b("v4")))),
            ];

            assert_eq!(resp.success, true);
            assert_eq!(
                normalize_txn_response(resp.responses),
                normalize_txn_response(expected)
            );

            // Test greater than value: success = false

            let txn = TxnRequest::new(
                vec![TxnCondition::match_value(k1, ConditionResult::Gt, b("v5"))],
                vec![TxnOp::put(k1, b("v5")), TxnOp::get(k1)],
            )
            .with_else(vec![TxnOp::get(k1)]);

            let resp = kv.transaction(txn).await?;

            let expected: Vec<TxnOpResponse> =
                vec![TxnOpResponse::get(k1, Some(SeqV::new(11, b("v4"))))];

            assert_eq!(resp.success, false);
            assert_eq!(
                normalize_txn_response(resp.responses),
                normalize_txn_response(expected)
            );

            // Test greater than value: success = true

            let txn = TxnRequest::new(
                vec![TxnCondition::match_value(k1, ConditionResult::Gt, b("v3"))],
                vec![TxnOp::put(k1, b("v5")), TxnOp::get(k1)],
            )
            .with_else(vec![TxnOp::get(k1)]);

            let resp = kv.transaction(txn).await?;

            let expected: Vec<TxnOpResponse> = vec![
                TxnOpResponse::put(
                    k1,
                    Some(pb::SeqV::new(11, b("v4"))),
                    Some(pb::SeqV::new(12, b("v5"))),
                ),
                TxnOpResponse::get(k1, Some(SeqV::new(12, b("v5")))),
            ];

            assert_eq!(resp.success, true);
            assert_eq!(
                normalize_txn_response(resp.responses),
                normalize_txn_response(expected)
            );

            // Test greater equal value: success = false

            let txn = TxnRequest::new(
                vec![TxnCondition::match_value(k1, ConditionResult::Ge, b("v6"))],
                vec![TxnOp::put(k1, b("v6")), TxnOp::get(k1)],
            )
            .with_else(vec![TxnOp::get(k1)]);

            let resp = kv.transaction(txn).await?;

            let expected: Vec<TxnOpResponse> =
                vec![TxnOpResponse::get(k1, Some(SeqV::new(12, b("v5"))))];

            assert_eq!(resp.success, false);
            assert_eq!(
                normalize_txn_response(resp.responses),
                normalize_txn_response(expected)
            );

            // Test greater equal value: success = true

            let txn = TxnRequest::new(
                vec![TxnCondition::match_value(k1, ConditionResult::Ge, b("v5"))],
                vec![TxnOp::put(k1, b("v6")), TxnOp::get(k1)],
            )
            .with_else(vec![TxnOp::get(k1)]);

            let resp = kv.transaction(txn).await?;

            let expected: Vec<TxnOpResponse> = vec![
                TxnOpResponse::put(
                    k1,
                    Some(pb::SeqV::new(12, b("v5"))),
                    Some(pb::SeqV::new(13, b("v6"))),
                ),
                TxnOpResponse::get(k1, Some(SeqV::new(13, b("v6")))),
            ];

            assert_eq!(resp.success, true);
            assert_eq!(
                normalize_txn_response(resp.responses),
                normalize_txn_response(expected)
            );
        }
        Ok(())
    }

    #[allow(clippy::bool_assert_comparison)]
    pub async fn kv_transaction_proposed_at<KV: kvapi::KVApi>(
        &self,
        kv: &KV,
    ) -> anyhow::Result<()> {
        info!("--- kvapi::KVApiTestSuite::kv_transaction_proposed_at() start");

        let k1 = "txn_1_K1";
        let val1 = b("v1");

        // first insert k1 value
        kv.upsert_kv(UpsertKV::update(k1, &val1)).await?;

        // transaction by k1 condition
        let txn_key = k1.to_string();
        let condition = vec![TxnCondition {
            key: txn_key.clone(),
            expected: ConditionResult::Gt as i32,
            target: Some(txn_condition::Target::Seq(0)),
        }];

        let if_then: Vec<TxnOp> = vec![TxnOp::put(txn_key.clone(), b("new_v1"))];

        let txn = TxnRequest::new(condition, if_then);

        let mut resp = kv.transaction(txn).await?;

        assert!(resp.success);
        assert_eq!(resp.responses.len(), 1);
        let resp = resp.responses.pop().unwrap();

        let put_resp = resp.try_as_put().unwrap().clone();

        let prev = put_resp.prev_value.unwrap();
        let current = put_resp.current.unwrap();

        let prev_proposed_at = prev.meta.unwrap().proposed_at_ms.unwrap();
        assert!(prev_proposed_at > 0);

        let current_proposed_at = current.meta.unwrap().proposed_at_ms.unwrap();
        assert!(current_proposed_at >= prev_proposed_at);

        Ok(())
    }

    pub async fn kv_transaction_fetch_add_u64<KV: kvapi::KVApi>(
        &self,
        kv: &KV,
    ) -> anyhow::Result<()> {
        // - Add a record via transaction with ttl

        info!("--- {}", func_path!());

        info!("--- non-existent keys should be initialized to 0");
        {
            let txn = TxnRequest::new(vec![], vec![
                TxnOp::fetch_add_u64("k1", 2),
                TxnOp::fetch_add_u64("k2", 3),
            ]);

            let resp = kv.transaction(txn).await?;

            assert_eq!(
                resp.responses[0].try_as_fetch_increase_u64().unwrap(),
                &FetchIncreaseU64Response {
                    key: "k1".to_string(),
                    before_seq: 0,
                    before: 0,
                    after_seq: 1,
                    after: 2,
                }
            );
            assert_eq!(
                resp.responses[1].try_as_fetch_increase_u64().unwrap(),
                &FetchIncreaseU64Response {
                    key: "k2".to_string(),
                    before_seq: 0,
                    before: 0,
                    after_seq: 2,
                    after: 3,
                }
            );
        }

        info!("--- existing keys should be incremented");
        {
            let txn = TxnRequest::new(vec![], vec![
                TxnOp::fetch_add_u64("k1", 2),
                TxnOp::fetch_add_u64("k2", 3),
            ]);

            let resp = kv.transaction(txn).await?;

            assert_eq!(
                resp.responses[0].try_as_fetch_increase_u64().unwrap(),
                &FetchIncreaseU64Response {
                    key: "k1".to_string(),
                    before_seq: 1,
                    before: 2,
                    after_seq: 3,
                    after: 4,
                }
            );
            assert_eq!(
                resp.responses[1].try_as_fetch_increase_u64().unwrap(),
                &FetchIncreaseU64Response {
                    key: "k2".to_string(),
                    before_seq: 2,
                    before: 3,
                    after_seq: 4,
                    after: 6,
                }
            );
        }

        info!("--- underflow or overflow should not happen");
        {
            let txn = TxnRequest::new(vec![], vec![
                TxnOp::fetch_add_u64("k1", -10),
                TxnOp::fetch_add_u64("k2", i64::MAX),
                TxnOp::fetch_add_u64("k2", i64::MAX),
            ]);

            let resp = kv.transaction(txn).await?;

            assert_eq!(
                resp.responses[0].try_as_fetch_increase_u64().unwrap(),
                &FetchIncreaseU64Response {
                    key: "k1".to_string(),
                    before_seq: 3,
                    before: 4,
                    after_seq: 5,
                    after: 0,
                }
            );
            assert_eq!(
                resp.responses[1].try_as_fetch_increase_u64().unwrap(),
                &FetchIncreaseU64Response {
                    key: "k2".to_string(),
                    before_seq: 4,
                    before: 6,
                    after_seq: 6,
                    after: u64::MAX / 2 + 6,
                }
            );
            assert_eq!(
                resp.responses[2].try_as_fetch_increase_u64().unwrap(),
                &FetchIncreaseU64Response {
                    key: "k2".to_string(),
                    before_seq: 6,
                    before: u64::MAX / 2 + 6,
                    after_seq: 7,
                    after: u64::MAX,
                }
            );
        }

        Ok(())
    }

    /// Tests match_seq must match the record seq to take place the operation.
    pub async fn kv_transaction_fetch_add_u64_match_seq<KV: kvapi::KVApi>(
        &self,
        kv: &KV,
    ) -> anyhow::Result<()> {
        // - Add a record via transaction with ttl

        info!("--- {}", func_path!());

        info!("--- match_seq zero");
        {
            let txn = TxnRequest::new(vec![], vec![
                TxnOp::fetch_add_u64("k1", 2).match_seq(Some(0)),
                TxnOp::fetch_add_u64("k1", 3).match_seq(Some(0)),
                TxnOp::fetch_add_u64("k1", 4),
                TxnOp::fetch_add_u64("k2", 5),
            ]);

            let resp = kv.transaction(txn).await?;

            assert_eq!(
                resp.responses[0].try_as_fetch_increase_u64().unwrap(),
                &FetchIncreaseU64Response {
                    key: "k1".to_string(),
                    before_seq: 0,
                    before: 0,
                    after_seq: 1,
                    after: 2,
                }
            );
            assert_eq!(
                resp.responses[1].try_as_fetch_increase_u64().unwrap(),
                &FetchIncreaseU64Response {
                    key: "k1".to_string(),
                    before_seq: 1,
                    before: 2,
                    after_seq: 1,
                    after: 2,
                }
            );
            assert_eq!(
                resp.responses[2].try_as_fetch_increase_u64().unwrap(),
                &FetchIncreaseU64Response {
                    key: "k1".to_string(),
                    before_seq: 1,
                    before: 2,
                    after_seq: 2,
                    after: 6,
                }
            );
            assert_eq!(
                resp.responses[3].try_as_fetch_increase_u64().unwrap(),
                &FetchIncreaseU64Response {
                    key: "k2".to_string(),
                    before_seq: 0,
                    before: 0,
                    after_seq: 3,
                    after: 5,
                }
            );
        }

        info!("--- match_seq non zero");
        {
            let txn = TxnRequest::new(vec![], vec![
                TxnOp::fetch_add_u64("k1", 2).match_seq(Some(2)),
                TxnOp::fetch_add_u64("k1", 3).match_seq(Some(2)),
                TxnOp::fetch_add_u64("k1", 4),
            ]);

            let resp = kv.transaction(txn).await?;

            assert_eq!(
                resp.responses[0].try_as_fetch_increase_u64().unwrap(),
                &FetchIncreaseU64Response {
                    key: "k1".to_string(),
                    before_seq: 2,
                    before: 6,
                    after_seq: 4,
                    after: 8,
                }
            );
            assert_eq!(
                resp.responses[1].try_as_fetch_increase_u64().unwrap(),
                &FetchIncreaseU64Response {
                    key: "k1".to_string(),
                    before_seq: 4,
                    before: 8,
                    after_seq: 4,
                    after: 8,
                }
            );
            assert_eq!(
                resp.responses[2].try_as_fetch_increase_u64().unwrap(),
                &FetchIncreaseU64Response {
                    key: "k1".to_string(),
                    before_seq: 4,
                    before: 8,
                    after_seq: 5,
                    after: 12,
                }
            );
        }

        Ok(())
    }

    /// Tests `fetch_increase_u64` with non-zero `max_value`:
    /// `after = max(current, max_value).saturating_add(delta)`
    pub async fn kv_transaction_fetch_increase_u64_max_value<KV: kvapi::KVApi>(
        &self,
        kv: &KV,
    ) -> anyhow::Result<()> {
        info!("--- {}", func_path!());

        info!("--- non-existent key: max(0, max_value) + delta");
        {
            let txn = TxnRequest::new(vec![], vec![TxnOp::fetch_increase_u64("fi_k1", 10, 3)]);

            let resp = kv.transaction(txn).await?;

            assert_eq!(
                resp.responses[0].try_as_fetch_increase_u64().unwrap(),
                &FetchIncreaseU64Response {
                    key: "fi_k1".to_string(),
                    before_seq: 0,
                    before: 0,
                    after_seq: 1,
                    after: 13, // max(0, 10) + 3
                }
            );
        }

        info!("--- current < max_value: max lifts value before adding delta");
        {
            // fi_k1 is now 13, set max_value=100
            let txn = TxnRequest::new(vec![], vec![TxnOp::fetch_increase_u64("fi_k1", 100, 5)]);

            let resp = kv.transaction(txn).await?;

            assert_eq!(
                resp.responses[0].try_as_fetch_increase_u64().unwrap(),
                &FetchIncreaseU64Response {
                    key: "fi_k1".to_string(),
                    before_seq: 1,
                    before: 13,
                    after_seq: 2,
                    after: 105, // max(13, 100) + 5
                }
            );
        }

        info!("--- current > max_value: max_value has no effect");
        {
            // fi_k1 is now 105, set max_value=50
            let txn = TxnRequest::new(vec![], vec![TxnOp::fetch_increase_u64("fi_k1", 50, 2)]);

            let resp = kv.transaction(txn).await?;

            assert_eq!(
                resp.responses[0].try_as_fetch_increase_u64().unwrap(),
                &FetchIncreaseU64Response {
                    key: "fi_k1".to_string(),
                    before_seq: 2,
                    before: 105,
                    after_seq: 3,
                    after: 107, // max(105, 50) + 2
                }
            );
        }

        info!("--- fetch_max_u64: delta=0, just lifts to max_value");
        {
            // fi_k2 doesn't exist
            let txn = TxnRequest::new(vec![], vec![TxnOp::fetch_max_u64("fi_k2", 42)]);

            let resp = kv.transaction(txn).await?;

            assert_eq!(
                resp.responses[0].try_as_fetch_increase_u64().unwrap(),
                &FetchIncreaseU64Response {
                    key: "fi_k2".to_string(),
                    before_seq: 0,
                    before: 0,
                    after_seq: 4,
                    after: 42, // max(0, 42) + 0
                }
            );

            // fi_k2 is now 42, fetch_max with lower value: no change except seq
            let txn = TxnRequest::new(vec![], vec![TxnOp::fetch_max_u64("fi_k2", 10)]);

            let resp = kv.transaction(txn).await?;

            assert_eq!(
                resp.responses[0].try_as_fetch_increase_u64().unwrap(),
                &FetchIncreaseU64Response {
                    key: "fi_k2".to_string(),
                    before_seq: 4,
                    before: 42,
                    after_seq: 5,
                    after: 42, // max(42, 10) + 0
                }
            );
        }

        Ok(())
    }

    /// Tests `Ne` condition on `Seq` and `Value` targets.
    pub async fn kv_transaction_condition_ne<KV: kvapi::KVApi>(
        &self,
        kv: &KV,
    ) -> anyhow::Result<()> {
        info!("--- {}", func_path!());

        let k1 = "ne_cond_k1";

        kv.upsert_kv(UpsertKV::update(k1, b"v1")).await?;
        let seq = kv.get_kv(k1).await?.unwrap().seq;

        info!("--- Ne seq: condition met (actual seq != expected)");
        {
            let txn = TxnRequest::new(
                vec![TxnCondition::match_seq(k1, ConditionResult::Ne, seq + 1)],
                vec![TxnOp::get(k1)],
            )
            .with_else(vec![TxnOp::get(k1)]);

            let resp = kv.transaction(txn).await?;
            assert!(resp.success);
        }

        info!("--- Ne seq: condition not met (actual seq == expected)");
        {
            let txn = TxnRequest::new(
                vec![TxnCondition::match_seq(k1, ConditionResult::Ne, seq)],
                vec![TxnOp::get(k1)],
            )
            .with_else(vec![TxnOp::get(k1)]);

            let resp = kv.transaction(txn).await?;
            assert!(!resp.success);
        }

        info!("--- Ne seq on non-existent key: seq=0 != expected");
        {
            let txn = TxnRequest::new(
                vec![TxnCondition::match_seq(
                    "ne_nonexist",
                    ConditionResult::Ne,
                    1,
                )],
                vec![TxnOp::get(k1)],
            )
            .with_else(vec![TxnOp::get(k1)]);

            let resp = kv.transaction(txn).await?;
            assert!(resp.success, "non-existent key has seq=0, 0 != 1");
        }

        info!("--- Ne value: condition met (actual value != expected)");
        {
            let txn = TxnRequest::new(
                vec![TxnCondition::match_value(k1, ConditionResult::Ne, b("v2"))],
                vec![TxnOp::get(k1)],
            )
            .with_else(vec![TxnOp::get(k1)]);

            let resp = kv.transaction(txn).await?;
            assert!(resp.success);
        }

        info!("--- Ne value: condition not met (actual value == expected)");
        {
            let txn = TxnRequest::new(
                vec![TxnCondition::match_value(k1, ConditionResult::Ne, b("v1"))],
                vec![TxnOp::get(k1)],
            )
            .with_else(vec![TxnOp::get(k1)]);

            let resp = kv.transaction(txn).await?;
            assert!(!resp.success);
        }

        Ok(())
    }

    /// Tests match_seq must match the record seq to take place the operation.
    pub async fn kv_txn_put_sequential<KV: kvapi::KVApi>(&self, kv: &KV) -> anyhow::Result<()> {
        info!("--- {}", func_path!());

        let txn = TxnRequest::new(vec![], vec![
            TxnOp::put_sequential("k1/", "seq1", b("v1")),
            TxnOp::put_sequential("k2/", "seq1", b("v2")),
        ]);

        let resp = kv.transaction(txn).await?;

        assert_eq!(resp.responses.len(), 2);

        let normalized = normalize_txn_response(resp.responses);
        assert_eq!(normalized[0].try_as_put().unwrap(), &TxnPutResponse {
            key: "k1/000_000_000_000_000_000_000".to_string(),
            prev_value: None,
            current: Some(pb::SeqV::with_meta(2, None, b("v1").to_vec())),
        });
        assert_eq!(normalized[1].try_as_put().unwrap(), &TxnPutResponse {
            key: "k2/000_000_000_000_000_000_001".to_string(),
            prev_value: None,
            current: Some(pb::SeqV::with_meta(4, None, b("v2").to_vec())),
        });

        // insert again

        let txn = TxnRequest::new(vec![], vec![
            TxnOp::put_sequential("k1/", "seq1", b("v1")),
            TxnOp::put_sequential("k2/", "seq1", b("v2")),
        ]);

        let resp = kv.transaction(txn).await?;

        assert_eq!(resp.responses.len(), 2);

        let normalized = normalize_txn_response(resp.responses);
        assert_eq!(normalized[0].try_as_put().unwrap(), &TxnPutResponse {
            key: "k1/000_000_000_000_000_000_002".to_string(),
            prev_value: None,
            current: Some(pb::SeqV::with_meta(6, None, b("v1").to_vec())),
        });
        assert_eq!(normalized[1].try_as_put().unwrap(), &TxnPutResponse {
            key: "k2/000_000_000_000_000_000_003".to_string(),
            prev_value: None,
            current: Some(pb::SeqV::with_meta(8, None, b("v2").to_vec())),
        });

        Ok(())
    }

    pub async fn kv_txn_put_sequential_expire_and_ttl<KV: kvapi::KVApi>(
        &self,
        kv: &KV,
    ) -> anyhow::Result<()> {
        // - Add a record via transaction with ttl

        info!("--- {}", func_path!());

        let now_ms = since_epoch_millis();

        let txn = TxnRequest::new(vec![], vec![
            TxnOp::put_sequential("k1/", "seq1", b("v1")).with_expires_at_ms(Some(now_ms + 1000)),
            TxnOp::put_sequential("k2/", "seq1", b("v2"))
                .with_ttl(Some(Duration::from_millis(1000))),
        ]);

        let resp = kv.transaction(txn).await?;

        assert_eq!(resp.responses.len(), 2);

        let normalized = normalize_txn_response(resp.responses);
        assert_eq!(normalized[0].try_as_put().unwrap(), &TxnPutResponse {
            key: "k1/000_000_000_000_000_000_000".to_string(),
            prev_value: None,
            current: Some(pb::SeqV::with_meta(
                2,
                Some(KvMeta::new(Some(now_ms + 1000), None)),
                b("v1").to_vec()
            )),
        });

        let got = normalized[1].try_as_put().unwrap();
        assert_eq!(got.key, "k2/000_000_000_000_000_000_001".to_string());
        assert_eq!(got.prev_value, None);
        let current = got.current.clone().unwrap();
        assert_eq!(current.seq, 4);
        assert_eq!(current.data, b("v2"));
        assert!(current.meta.unwrap().close_to(
            &KvMeta::new(Some(now_ms + 1000), None),
            Duration::from_millis(1000)
        ));

        sleep(Duration::from_millis(2000)).await;

        let got = kv.get_kv("k1/000_000_000_000_000_000_000").await?;
        assert!(got.is_none(), "k1 should be expired");

        let got = kv.get_kv("k2/000_000_000_000_000_000_001").await?;
        assert!(got.is_none(), "k2 should be expired");

        Ok(())
    }

    pub async fn kv_transaction_with_ttl<KV: kvapi::KVApi>(&self, kv: &KV) -> anyhow::Result<()> {
        // - Add a record via transaction with ttl

        info!("--- {}", func_path!());

        let txn = TxnRequest::new(vec![], vec![TxnOp::put_with_ttl(
            "k1",
            b("v1"),
            Some(Duration::from_millis(2_000)),
        )]);

        let _resp = kv.transaction(txn).await?;

        info!("---get unexpired");
        {
            let res = kv.get_kv("k1").await?;
            assert!(res.is_some(), "got unexpired");
        }

        info!("---get expired");
        {
            tokio::time::sleep(Duration::from_millis(2_100)).await;
            let res = kv.get_kv("k1").await?;
            assert!(res.is_none(), "got expired");
        }

        Ok(())
    }

    /// Tests `TxnPutRequest.expire_at` via `TxnOp::put().with_expires_at_ms()`.
    pub async fn kv_transaction_put_expire_at<KV: kvapi::KVApi>(
        &self,
        kv: &KV,
    ) -> anyhow::Result<()> {
        info!("--- {}", func_path!());

        let now_ms = since_epoch_millis();

        info!("--- put with expire_at in the future");
        {
            let txn = TxnRequest::new(vec![], vec![
                TxnOp::put("ea_k1", b("v1")).with_expires_at_ms(Some(now_ms + 10_000)),
            ]);

            let resp = kv.transaction(txn).await?;
            assert!(resp.success);

            let res = kv.get_kv("ea_k1").await?;
            let meta = res.unwrap().meta.unwrap();
            assert_eq!(meta.get_expire_at_ms(), Some(now_ms + 10_000));
        }

        info!("--- put with expire_at in the past: key should be expired");
        {
            let txn = TxnRequest::new(vec![], vec![
                TxnOp::put("ea_k2", b("v2")).with_expires_at_ms(Some(now_ms - 1_000)),
            ]);

            let _resp = kv.transaction(txn).await?;

            let res = kv.get_kv("ea_k2").await?;
            assert!(res.is_none(), "key with past expire_at should be expired");
        }

        Ok(())
    }

    /// A transaction that checks the number of keys with given prefix.
    pub async fn kv_transaction_condition_keys_with_prefix<KV: kvapi::KVApi>(
        &self,
        kv: &KV,
    ) -> anyhow::Result<()> {
        let prefix = func_name!();

        let sample_keys_prefix = format!("{}/xxx", prefix);

        let sample = |suffix| format!("{}/{}", sample_keys_prefix, suffix);
        let positive = format!("{prefix}/positive");
        let negative = format!("{prefix}/negative");

        kv.upsert_kv(UpsertKV::update(sample("a"), &b("a"))).await?;
        kv.upsert_kv(UpsertKV::update(sample("b"), &b("b"))).await?;
        kv.upsert_kv(UpsertKV::update(sample("c"), &b("c"))).await?;

        use ConditionResult::*;

        // A transaction that set positive key if succeeded,
        // otherwise set the negative key.
        let txn = |op: ConditionResult, n: u64| {
            TxnRequest::new(
                vec![TxnCondition::match_keys_with_prefix(
                    &sample_keys_prefix,
                    op,
                    n,
                )],
                vec![TxnOp::put(&positive, b(format!("{op:?}")))],
            )
            .with_else(vec![TxnOp::put(&negative, b(format!("{op:?}")))])
        };

        for (op, n, expected) in [
            (Eq, 2, false),
            (Eq, 3, true),
            (Eq, 4, false),
            (Ne, 2, true),
            (Ne, 3, false),
            (Ne, 4, true),
            (Lt, 3, false),
            (Lt, 4, true),
            (Lt, 5, true),
            (Le, 2, false),
            (Le, 3, true),
            (Le, 4, true),
            (Gt, 2, true),
            (Gt, 3, false),
            (Gt, 4, false),
            (Ge, 2, true),
            (Ge, 3, true),
            (Ge, 4, false),
        ] {
            kv.upsert_kv(UpsertKV::update(&positive, &b(""))).await?;
            kv.upsert_kv(UpsertKV::update(&negative, &b(""))).await?;

            let resp = kv.transaction(txn(op, n)).await?;
            assert_eq!(
                resp.success, expected,
                "case: {op:?} {n}, expected: {expected}"
            );

            let expected_key = if expected { &positive } else { &negative };
            let got = kv.get_kv(expected_key).await?.unwrap().data;
            assert_eq!(
                got,
                b(format!("{op:?}")),
                "case: {op:?} {n}, expected: {expected}"
            );
        }

        Ok(())
    }

    pub async fn kv_transaction_complex_conditions<KV: kvapi::KVApi>(
        &self,
        kv: &KV,
    ) -> anyhow::Result<()> {
        let prefix = func_name!();

        let sample = |suffix: &str| format!("{}/{}", prefix, suffix);
        let result = format!("{prefix}/result");

        kv.upsert_kv(UpsertKV::update(sample("a"), &b("a"))).await?;
        kv.upsert_kv(UpsertKV::update(sample("b"), &b("b"))).await?;
        kv.upsert_kv(UpsertKV::update(sample("c"), &b("c"))).await?;

        // Build a simple equal-value condition
        let eq = |key: &str, val: &str| TxnCondition::eq_value(sample(key), b(val));

        let txn = |bools: Vec<Option<BooleanExpression>>, conditions: Vec<TxnCondition>| {
            let mut txn = TxnRequest::default();
            for (i, cond) in bools.into_iter().enumerate() {
                txn = txn.push_branch(cond, vec![pb::TxnOp::put(
                    &result,
                    b(format!("operation:{}", i)),
                )]);
            }

            txn.push_if_then(conditions, vec![pb::TxnOp::put(&result, b("then"))])
                .with_else(vec![pb::TxnOp::put(&result, b("else"))])
        };

        for (bools, condition, expected, index) in [
            (
                vec![],
                // empty condition is always true
                vec![],
                "then",
                None,
            ),
            (vec![], vec![eq("a", "a")], "then", None),
            (vec![], vec![eq("a", "b")], "else", None),
            (vec![], vec![eq("a", "a"), eq("b", "b")], "then", None),
            (vec![], vec![eq("a", "a"), eq("b", "c")], "else", None),
            (
                vec![
                    Some(eq("a", "a").and(eq("b", "b"))),
                    Some(eq("b", "b").or(eq("c", "c"))),
                ],
                vec![eq("a", "a")],
                "operation:0",
                Some(0),
            ),
            (
                vec![
                    Some(eq("a", "a").and(eq("b", "c"))),
                    Some(eq("b", "b").and(eq("c", "c"))),
                ],
                vec![eq("a", "a")],
                "operation:1",
                Some(1),
            ),
            (
                vec![
                    Some(eq("a", "a").and(eq("b", "c"))),
                    Some(eq("b", "b").and(eq("x", "x"))),
                ],
                vec![eq("a", "a")],
                "then",
                None,
            ),
            (
                vec![
                    Some(eq("a", "a").and(eq("b", "c"))),
                    Some(eq("b", "b").and(eq("x", "x"))),
                ],
                // empty condition is always true
                vec![],
                "then",
                None,
            ),
            (
                vec![
                    Some(eq("a", "a").and(eq("b", "c"))),
                    // None condition is always true
                    None,
                ],
                vec![eq("a", "a")],
                "operation:1",
                Some(1),
            ),
            (
                vec![Some(
                    eq("a", "a")
                        .or(eq("x", "x"))
                        .and(eq("b", "b").or(eq("y", "y"))),
                )],
                vec![eq("a", "b")],
                "operation:0",
                Some(0),
            ),
        ] {
            kv.upsert_kv(UpsertKV::update(&result, &b(""))).await?;

            let resp = kv
                .transaction(txn(bools.clone(), condition.clone()))
                .await?;

            let message = format!(
                "case: {} {}, expected: {expected}",
                bools
                    .into_iter()
                    .map(|b| b.display().to_string())
                    .collect::<Vec<_>>()
                    .display(),
                condition.display()
            );

            let want_success = expected != "else";

            assert_eq!(resp.success, want_success, "{}", message);
            assert_eq!(resp.execution_path, expected, "{}", message);
            assert_eq!(resp.executed_branch_index().unwrap(), index, "{}", message);

            let got = kv.get_kv(&result).await?.unwrap().data;
            assert_eq!(got, b(expected), "{}", message);
        }

        Ok(())
    }

    /// If `TxnDeleteRequest.match_seq` is not set,
    /// the delete operation will always be executed.
    pub async fn kv_transaction_delete_match_seq_none<KV: kvapi::KVApi>(
        &self,
        kv: &KV,
    ) -> anyhow::Result<()> {
        info!("--- {}", func_name!());
        let key = || "txn_1_K1".to_string();
        let val = || b("v1");

        kv.upsert_kv(UpsertKV::update(key(), &val())).await?;

        let txn = TxnRequest::new(vec![], vec![TxnOp::delete(key())]);

        let resp = kv.transaction(txn).await?;

        let expected = vec![TxnOpResponse::delete(
            key(),
            true,
            Some(pb::SeqV::from(SeqV::new(1, val()))),
        )];

        self.check_transaction_responses(&resp, &expected, true);

        let got = kv.get_kv(&key()).await?;
        assert_eq!(None, got, "successful delete");

        Ok(())
    }

    /// If `TxnDeleteRequest.match_seq` is Some,
    /// no delete because the current seq is not equal to `match_seq`.
    pub async fn kv_transaction_delete_match_seq_some_not_match<KV: kvapi::KVApi>(
        &self,
        kv: &KV,
    ) -> anyhow::Result<()> {
        info!("--- {}", func_name!());
        let key = || "txn_1_K1".to_string();
        let val = || b("v1");

        kv.upsert_kv(UpsertKV::update(key(), &val())).await?;

        let txn = TxnRequest::new(vec![], vec![TxnOp::delete_exact(key(), Some(100))]);

        let resp = kv.transaction(txn).await?;

        let expected = vec![TxnOpResponse::delete(
            key(),
            false,
            Some(pb::SeqV::from(SeqV::new(1, val()))),
        )];

        self.check_transaction_responses(&resp, &expected, true);

        let got = kv.get_kv(&key()).await?;
        assert_eq!(
            Some(SeqV::new(1, val())),
            got.without_proposed_at(),
            "not deleted due to non-matching seq"
        );

        Ok(())
    }

    /// If `TxnDeleteRequest.match_seq` is Some,
    /// delete because the current seq equal to `match_seq`.
    pub async fn kv_transaction_delete_match_seq_some_match<KV: kvapi::KVApi>(
        &self,
        kv: &KV,
    ) -> anyhow::Result<()> {
        info!("--- {}", func_name!());
        let key = || "txn_1_K1".to_string();
        let val = || b("v1");

        kv.upsert_kv(UpsertKV::update(key(), &val())).await?;

        let txn = TxnRequest::new(vec![], vec![TxnOp::delete_exact(key(), Some(1))]);

        let resp = kv.transaction(txn).await?;

        let expected = vec![TxnOpResponse::delete(
            key(),
            true,
            Some(pb::SeqV::from(SeqV::new(1, val()))),
        )];

        self.check_transaction_responses(&resp, &expected, true);

        let got = kv.get_kv(&key()).await?;
        assert_eq!(None, got, "successful delete");

        Ok(())
    }
}

/// Test that write and read should be forwarded to leader
impl TestSuite {
    pub async fn kv_write_read_across_nodes<KV: kvapi::KVApi>(
        &self,
        kv1: &KV,
        kv2: &KV,
    ) -> anyhow::Result<()> {
        let mut values = vec![];
        {
            kv1.upsert_kv(UpsertKV::update("t", b"t")).await?;

            for i in 0..9 {
                let key = format!("__users/{}", i);
                let val = format!("val_{}", i);
                values.push(val.clone());
                info!("--- Start upsert-kv: {}", key);
                kv1.upsert_kv(UpsertKV::update(&key, val.as_bytes()))
                    .await?;
                info!("--- Done upsert-kv: {}", key);
            }

            kv1.upsert_kv(UpsertKV::update("v", b"v")).await?;
        }

        info!("--- test get on other node");
        {
            let res = kv2.get_kv("t").await?;
            let res = res.unwrap();
            assert_eq!(b("t"), res.data);
        }

        info!("--- test mget on other node");
        {
            let res = kv2.mget_kv(&["u".to_string(), "v".to_string()]).await?;
            assert_eq!(
                vec![
                    None,
                    Some(SeqV {
                        seq: 11,
                        meta: None,
                        data: b("v")
                    })
                ],
                res.without_proposed_at()
            );
        }

        info!("--- test list on other node");
        {
            let res = kv2
                .list_kv_collect(ListOptions::unlimited("__users/"))
                .await?;
            assert_eq!(
                res.iter()
                    .map(|(_key, val)| val.data.clone())
                    .collect::<Vec<_>>(),
                values
                    .iter()
                    .map(|v| v.as_bytes().to_vec())
                    .collect::<Vec<_>>()
            );
        }
        Ok(())
    }
}

fn normalize_pb_meta(meta: &mut Option<pb::KvMeta>) {
    if let Some(m) = meta {
        m.proposed_at_ms = None;
    }
    if *meta == Some(Default::default()) {
        *meta = None;
    }
}

/// Convert Some(KvMeta{ expire: None }) to None to simplify the comparison.
/// Also erase proposed_at_ms for test comparisons.
fn normalize_txn_response(vs: Vec<TxnOpResponse>) -> Vec<TxnOpResponse> {
    vs.into_iter()
        .map(|mut v| {
            match &mut v.response {
                Some(Response::Get(TxnGetResponse {
                    value: Some(pb::SeqV { meta, .. }),
                    ..
                })) => normalize_pb_meta(meta),
                Some(Response::Put(TxnPutResponse {
                    prev_value: Some(pb::SeqV { meta, .. }),
                    ..
                })) => normalize_pb_meta(meta),
                Some(Response::Delete(TxnDeleteResponse {
                    prev_value: Some(pb::SeqV { meta, .. }),
                    ..
                })) => normalize_pb_meta(meta),
                _ => {}
            }

            if let Some(Response::Put(TxnPutResponse {
                current: Some(pb::SeqV { meta, .. }),
                ..
            })) = &mut v.response
            {
                normalize_pb_meta(meta);
            }

            v
        })
        .collect()
}

fn b(x: impl ToString) -> Vec<u8> {
    x.to_string().as_bytes().to_vec()
}

fn since_epoch_secs() -> u64 {
    since_epoch().as_secs()
}

fn since_epoch_millis() -> u64 {
    since_epoch().as_millis() as u64
}

fn since_epoch() -> Duration {
    SystemTime::now()
        .duration_since(SystemTime::UNIX_EPOCH)
        .unwrap()
}
