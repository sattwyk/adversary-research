use std::fs::File;
use std::io;
use std::io::IoSlice;
use std::io::Write;
use std::os::unix::fs::MetadataExt;
use std::panic::AssertUnwindSafe;
use std::sync::Arc;
use std::sync::Condvar;
use std::sync::Mutex;
use std::sync::mpsc::Receiver;
use std::sync::mpsc::RecvTimeoutError;
use std::thread::JoinHandle;
use std::time::Duration;
use std::time::Instant;

use log::debug;
use log::info;

use crate::Config;
use crate::WalTypes;
use crate::wal::atomic_flush_metrics::AtomicFlushMetrics;
use crate::wal::batch_metrics::BatchMetrics;
use crate::wal::callback::Callback;
use crate::wal::file_entry::FileEntry;
use crate::wal::file_persisted::ChunkPersisted;
use crate::wal::flush_request::FlushStat;
use crate::wal::flush_request::SeqRequest;
use crate::wal::flush_request::WorkerRequest;
use crate::wal::queued_bytes::QueuedBytes;
use crate::wal::queued_write::QueuedWrite;
use crate::wal::write_batch::WriteBatch;

#[derive(Debug)]
pub(crate) enum WorkerStatus {
    Running,
    Failed(io::Error),
}

#[derive(Debug)]
struct WorkerProgress {
    done_seq: u64,
    status: WorkerStatus,
}

/// Flow control shared by the WAL and its flush worker.
///
/// The WAL waits here for completion and failure reports, and for queued
/// write memory to be freed.
#[derive(Debug)]
pub(crate) struct WorkerState {
    progress: Mutex<WorkerProgress>,
    changed: Condvar,
    queued_bytes: QueuedBytes,
}

impl WorkerState {
    pub(crate) fn new(queue_max_bytes: usize) -> Self {
        Self {
            progress: Mutex::new(WorkerProgress {
                done_seq: 0,
                status: WorkerStatus::Running,
            }),
            changed: Condvar::new(),
            queued_bytes: QueuedBytes::new(queue_max_bytes),
        }
    }

    pub(crate) fn queued_bytes(&self) -> &QueuedBytes {
        &self.queued_bytes
    }

    pub(crate) fn done_seq(&self) -> u64 {
        self.progress.lock().unwrap().done_seq
    }

    pub(crate) fn complete(&self, seq: u64) {
        let mut progress = self.progress.lock().unwrap();
        progress.done_seq = progress.done_seq.max(seq);
        self.changed.notify_all();
    }

    pub(crate) fn fail(&self, err: io::Error) {
        let mut progress = self.progress.lock().unwrap();
        progress.status = WorkerStatus::Failed(err);
        self.changed.notify_all();
    }

    pub(crate) fn wait_for(&self, target_seq: u64) -> Result<(), io::Error> {
        let mut progress = self.progress.lock().unwrap();
        loop {
            if progress.done_seq >= target_seq {
                return Ok(());
            }

            status_error(&progress.status)?;
            progress = self.changed.wait(progress).unwrap();
        }
    }
}

fn status_error(status: &WorkerStatus) -> Result<(), io::Error> {
    match status {
        WorkerStatus::Running => Ok(()),
        WorkerStatus::Failed(err) => {
            Err(io::Error::new(err.kind(), err.to_string()))
        }
    }
}

pub(crate) struct FlushWorker<W>
where W: WalTypes
{
    rx: Receiver<SeqRequest<W>>,
    files: Vec<FileEntry<W>>,
    metrics: Arc<AtomicFlushMetrics>,
    config: Arc<Config>,
    worker_state: Arc<WorkerState>,
}

impl<W> FlushWorker<W>
where W: WalTypes
{
    /// When starting, there is at most one open chunk file that is not sync.
    pub(crate) fn spawn(self) -> JoinHandle<()> {
        std::thread::Builder::new()
            .name("chunked_wal_flush_worker".to_string())
            .spawn(move || {
                self.run();
            })
            .expect("Failed to start sync worker thread")
    }

    pub(crate) fn new(
        rx: Receiver<SeqRequest<W>>,
        file_entry: FileEntry<W>,
        worker_state: Arc<WorkerState>,
        metrics: Arc<AtomicFlushMetrics>,
        config: Arc<Config>,
    ) -> Self {
        Self {
            rx,
            files: vec![file_entry],
            metrics,
            config,
            worker_state,
        }
    }

    /// Runs the worker and records any failure in the shared worker state.
    ///
    /// User code runs on this thread through the write and chunk-persisted
    /// callbacks. Catching its panics keeps a panicking callback from
    /// unwinding the thread silently, which would leave every
    /// `wait_worker_idle` caller blocked forever.
    fn run(mut self) {
        let res =
            std::panic::catch_unwind(AssertUnwindSafe(|| self.run_inner()));

        // A stopped worker never frees queued write memory again. Release it
        // so a sender blocked on the byte limit wakes and sees the closed
        // channel instead of waiting forever.
        self.worker_state.queued_bytes().release_all();

        let err = match res {
            Ok(Ok(())) => return,
            Ok(Err(e)) => e,
            Err(payload) => io::Error::other(format!(
                "FlushWorker panicked: {}",
                panic_message(payload.as_ref())
            )),
        };

        log::error!("FlushWorker failed: {}", err);
        self.worker_state.fail(err);
    }

    fn run_inner(&mut self) -> Result<(), io::Error> {
        // Write requests should be batched to maximize throughput. One batch
        // serves every iteration so its write vector is allocated once.
        let mut batch = WriteBatch::new(self.config.flush_batch_max_items());

        loop {
            batch.reset();

            let req = self.rx.recv();
            let Ok(seq_req) = req else {
                log::info!("FlushWorker input channel closed, quit");
                return Ok(());
            };

            if !batch.push_seq_request(seq_req) {
                let Some(SeqRequest { seq, req, .. }) =
                    batch.last_non_flush.take()
                else {
                    unreachable!("non-write request must be stored");
                };
                self.handle_non_flush_request(req)?;
                self.worker_state.complete(seq);
                continue;
            }

            let group_wait = self.collect_write_batch(&mut batch);

            debug!("batched write: {}", batch.writes.len());

            let batch_bytes: usize =
                batch.writes.iter().map(|w| w.write.data.len()).sum();

            let sync_result = {
                // TODO: possible to use write_all_vectored()?

                let mut last_file: &File = &self.files.last().unwrap().f;
                let batch_start = Instant::now();
                let mut batch_metrics =
                    BatchMetrics::new(batch.writes.len(), group_wait);
                for w in &batch.writes {
                    batch_metrics.record_queued_write(batch_start, w);
                }

                let write_start = Instant::now();
                let write_res =
                    write_batch_vectored(&mut last_file, &batch.writes);
                batch_metrics.record_write_time(write_start);

                let need_sync = batch.writes.iter().any(|w| w.write.sync);

                let sync_result = match write_res {
                    Ok(()) if need_sync => {
                        let upto_offset =
                            batch.writes.last().unwrap().write.upto_offset;
                        let sync_start = Instant::now();
                        let res = self.sync_data_files(upto_offset);
                        batch_metrics.record_sync_time(sync_start);
                        if let Err(ref e) = res {
                            log::error!(
                                "Failed to flush upto offset {}: {}",
                                upto_offset,
                                e
                            );
                        }
                        res
                    }
                    Ok(()) => Ok(()),
                    Err(e) => Err(e),
                };

                batch_metrics.record_batch_time(batch_start);
                self.metrics.record_batch(batch_metrics);

                sync_result
            };

            let mut max_seq = batch.max_seq;
            let last_non_flush = batch.last_non_flush.take();

            for w in batch.writes.drain(..) {
                if let Some(cb) = w.write.callback {
                    match &sync_result {
                        Ok(()) => cb.send(Ok(())),
                        Err(e) => {
                            cb.send(Err(io::Error::new(
                                e.kind(),
                                e.to_string(),
                            )));
                        }
                    }
                }
            }

            self.worker_state.queued_bytes().release(batch_bytes);

            sync_result?;

            // Handle the last non-flush request
            if let Some(SeqRequest {
                seq: nf_seq,
                req: last,
                ..
            }) = last_non_flush
            {
                self.handle_non_flush_request(last)?;
                max_seq = max_seq.max(nf_seq);
            }

            self.worker_state.complete(max_seq);
        }
    }

    fn collect_write_batch(&self, batch: &mut WriteBatch<W>) -> Duration {
        let loop_started_at = Instant::now();
        let loop_deadline = loop_started_at + self.config.flush_batch_wait();

        while batch.last_non_flush.is_none()
            && batch.writes.len() < batch.max_size
        {
            let now = Instant::now();
            if loop_deadline <= now {
                break;
            }

            let remaining = loop_deadline - now;
            match self.rx.recv_timeout(remaining) {
                Ok(seq_req) => {
                    if !batch.push_seq_request(seq_req) {
                        break;
                    }
                }
                Err(
                    RecvTimeoutError::Timeout | RecvTimeoutError::Disconnected,
                ) => break,
            }
        }

        loop_started_at.elapsed()
    }

    fn handle_non_flush_request(
        &mut self,
        req: WorkerRequest<W>,
    ) -> Result<(), io::Error> {
        match req {
            WorkerRequest::AppendFile(file_entry) => {
                info!("FlushWorker: AppendFile: {}", file_entry);
                self.files.push(file_entry);
            }
            WorkerRequest::Write(_) => {
                unreachable!("Write request should be handled in run()");
            }
            WorkerRequest::GetFlushStat { tx } => {
                let stat = self
                    .files
                    .iter()
                    .map(|f| {
                        Ok(FlushStat {
                            starting_offset: f.starting_offset,
                            sync_id: f.sync_id,
                            ino: f.f.metadata()?.ino(),
                        })
                    })
                    .collect::<Result<Vec<_>, io::Error>>()?;
                let _ = tx.send(stat);
            }
            WorkerRequest::RemoveChunks { chunk_paths } => {
                info!("FlushWorker: RemoveChunks: {:?}", chunk_paths);
                let removed_any = !chunk_paths.is_empty();
                for path in chunk_paths {
                    std::fs::remove_file(path)?;
                }
                if removed_any {
                    // Commit the unlinks so a removed chunk cannot reappear
                    // after power loss.
                    self.config.sync_dir()?;
                }
            }
        }

        Ok(())
    }

    pub fn sync_data_files(&mut self, offset: u64) -> Result<(), io::Error> {
        let files = &mut self.files;

        if files.is_empty() {
            return Ok(());
        }

        // Append-only WAL flushes only need file data durability. Metadata
        // changes such as recovery truncation are synchronized at the call
        // site that performs the metadata update.
        while files.len() > 1 {
            let f = files.remove(0);
            f.f.sync_data()?;
        }

        let f = &mut files[0];
        f.f.sync_data()?;
        f.on_persisted.call(ChunkPersisted {
            starting_offset: f.starting_offset,
            synced_offset: offset,
        });
        f.sync_id = offset;

        Ok(())
    }
}

/// Renders a caught panic payload as text.
fn panic_message(payload: &(dyn std::any::Any + Send)) -> String {
    if let Some(message) = payload.downcast_ref::<&str>() {
        return (*message).to_string();
    }

    if let Some(message) = payload.downcast_ref::<String>() {
        return message.clone();
    }

    "unknown panic payload".to_string()
}

fn write_batch_vectored<W>(
    file: &mut &File,
    writes: &[QueuedWrite<W>],
) -> Result<(), io::Error>
where
    W: WalTypes,
{
    const MAX_VECTORED_WRITE_SLICES: usize = 1024;

    for chunk in writes.chunks(MAX_VECTORED_WRITE_SLICES) {
        let mut io_slices = chunk
            .iter()
            .filter(|w| !w.write.data.is_empty())
            .map(|w| IoSlice::new(&w.write.data))
            .collect::<Vec<_>>();

        if !io_slices.is_empty() {
            write_all_vectored(file, &mut io_slices)?;
        }
    }

    Ok(())
}

/// Writes every slice, resuming a partial write in place.
///
/// `IoSlice::advance_slices` trims the already-written prefix from the front
/// of `io_slices`, so a partial write does not rebuild the slice list.
fn write_all_vectored(
    file: &mut &File,
    io_slices: &mut [IoSlice<'_>],
) -> Result<(), io::Error> {
    let mut remaining = io_slices;

    while !remaining.is_empty() {
        let written = match file.write_vectored(remaining) {
            Ok(0) => {
                return Err(io::Error::new(
                    io::ErrorKind::WriteZero,
                    "failed to write whole buffer",
                ));
            }
            Ok(n) => n,
            Err(e) if e.kind() == io::ErrorKind::Interrupted => continue,
            Err(e) => return Err(e),
        };

        IoSlice::advance_slices(&mut remaining, written);
    }

    Ok(())
}

#[cfg(test)]
mod tests {
    use std::io;
    use std::sync::Arc;
    use std::sync::mpsc::Receiver;
    use std::sync::mpsc::SyncSender;
    use std::sync::mpsc::sync_channel;
    use std::time::Duration;
    use std::time::Instant;

    use crate::Config;
    use crate::WalTypes;
    use crate::wal::atomic_flush_metrics::AtomicFlushMetrics;
    use crate::wal::flush_request::SeqRequest;
    use crate::wal::flush_request::WorkerRequest;
    use crate::wal::flush_request::WriteRequest;
    use crate::wal::flush_worker::FlushWorker;
    use crate::wal::flush_worker::WorkerState;
    use crate::wal::write_batch::WriteBatch;

    #[derive(Debug, Default, Clone, PartialEq, Eq)]
    struct TestWal;

    impl WalTypes for TestWal {
        type Action = String;
        type Checkpoint = String;
        type Callback = SyncSender<Result<(), io::Error>>;
    }

    fn worker(
        rx: Receiver<SeqRequest<TestWal>>,
        flush_batch_wait: Duration,
    ) -> FlushWorker<TestWal> {
        let mut config = Config::new("no-such-dir");
        config.flush_batch_wait = Some(flush_batch_wait);
        config.flush_batch_max_items = Some(8);

        FlushWorker {
            rx,
            files: Vec::new(),
            metrics: Arc::new(AtomicFlushMetrics::default()),
            config: Arc::new(config),
            worker_state: Arc::new(WorkerState::new(1024)),
        }
    }

    fn write_request(seq: u64) -> SeqRequest<TestWal> {
        SeqRequest {
            seq,
            queued_at: Instant::now(),
            req: WorkerRequest::Write(WriteRequest {
                upto_offset: seq,
                data: vec![seq as u8],
                sync: false,
                callback: None,
            }),
        }
    }

    #[test]
    fn test_worker_state_waits_for_completion() -> Result<(), io::Error> {
        let state = WorkerState::new(1024);

        state.complete(3);

        assert_eq!(3, state.done_seq());
        state.wait_for(2)?;
        state.wait_for(3)?;
        Ok(())
    }

    #[test]
    fn test_worker_state_wait_returns_failure() {
        let state = WorkerState::new(1024);
        let err = io::Error::new(io::ErrorKind::PermissionDenied, "no write");

        state.fail(err);

        let got = state.wait_for(1).unwrap_err();
        assert_eq!(io::ErrorKind::PermissionDenied, got.kind());
        assert_eq!("no write", got.to_string());
    }

    #[test]
    fn test_sync_data_files_empty_file_list() -> Result<(), io::Error> {
        let (_tx, rx) = sync_channel(1);
        let mut worker = worker(rx, Duration::ZERO);

        worker.sync_data_files(10)?;

        assert!(worker.files.is_empty());
        Ok(())
    }

    #[test]
    fn test_collect_write_batch_stops_at_deadline() {
        let (_tx, rx) = sync_channel(1);
        let worker = worker(rx, Duration::ZERO);
        let mut batch = WriteBatch::new(8);
        assert!(batch.push_seq_request(write_request(1)));

        worker.collect_write_batch(&mut batch);

        assert_eq!(1, batch.writes.len());
        assert_eq!(1, batch.max_seq);
        assert!(batch.last_non_flush.is_none());
    }

    #[test]
    fn test_collect_write_batch_stops_at_non_write_request() {
        let (tx, rx) = sync_channel(1);
        tx.send(SeqRequest {
            seq: 2,
            queued_at: Instant::now(),
            req: WorkerRequest::RemoveChunks {
                chunk_paths: vec!["obsolete".to_string()],
            },
        })
        .unwrap();

        let worker = worker(rx, Duration::from_secs(1));
        let mut batch = WriteBatch::new(8);
        assert!(batch.push_seq_request(write_request(1)));

        worker.collect_write_batch(&mut batch);

        assert_eq!(1, batch.writes.len());
        assert_eq!(1, batch.max_seq);
        let last = batch.last_non_flush.unwrap();
        assert_eq!(2, last.seq);
        assert!(matches!(
            last.req,
            WorkerRequest::RemoveChunks { chunk_paths }
                if chunk_paths == vec!["obsolete".to_string()]
        ));
    }
}
